var express = require('express');
var router = express.Router();
const { check, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds);
const HTTPStatus = require("http-status");
const mongoose = require('mongoose');

module.exports = (app, wagner) => {
    let authMiddleware = wagner.get("auth");

    router.post('/add', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
        check('name').not().isEmpty().withMessage("name is required.")
    ], async (req, res, next) => {
        try{
            let errors = validationResult(req);
            if(!errors.isEmpty()){
                console.log(errors);
                let lasterr = errors.array().pop();
                lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
                return res.status(405).json({ success: '0', message: "failure", data: lasterr });
            }
            let conds = {name : (req.body.name).toLowerCase() };
            let retailer_data = await wagner.get('retailer_manager').find(conds);  
            if(retailer_data){
                res.status(409).json({ success: '1', message: "Retailer already exists.", data: '' });
            }else{
                let insert = await wagner.get('retailer_manager').insert(req.body);
                //let sendPasswordMail = await wagner.get('retailer_manager').sendLoginMail(req.body, pass);
                res.status(HTTPStatus.OK).json({ success: '1', message: "Retailer Added", data: "" }); 
            }
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.get('/list', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
        try{
          let sort = {'_id' : JSON.parse(req.query.sort)};
          let retailers = await wagner.get('retailer_manager').findAllPaginate({}, sort, req.query.pageNumber, req.query.recordsLimit);
          res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: retailers });            
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.post('/search', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
        check('searchParam').not().isEmpty().withMessage("searchParam is required.")
    ], async (req, res, next) => {
        try{
            let errors = validationResult(req);
            if(!errors.isEmpty()){
                console.log(errors);
                let lasterr = errors.array().pop();
                lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
                return res.status(405).json({ success: '0', message: "failure", data: lasterr });
            }
            let conds = { name: { $regex: '.*' + req.body.searchParam + '.*' }};
            let sort = {'_id' : JSON.parse(req.body.sort)};
            let retailer_data = await wagner.get('retailer_manager').findAllPaginate(conds, sort, req.body.pageNumber, req.body.recordsLimit);  
            res.status(HTTPStatus.OK).json({ success: '1', message: "Retailer Data", data: retailer_data });
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.post( "/update", authMiddleware["verifyAccessToken"].bind(authMiddleware), [
        check('retailer_id').not().isEmpty().withMessage("User Id is required.")
      ],async (req, res) => {
        try {
          let conds = { "_id": req.body.retailer_id };
          let request = req.body
          delete request.retailer_id;
          let userData = await wagner.get("retailer_manager").update(request, conds);
          res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
        } catch (e) {
          console.log(e);
          res.status(500).json({ success: "0", message: "failure", data: e });
        }   
      })

  return router;
}
