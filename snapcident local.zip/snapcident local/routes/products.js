var express = require('express');
var router = express.Router();
const { check, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds);
const HTTPStatus = require("http-status");
const mongoose = require('mongoose');
const axios = require('axios');
const parseString = require('xml2js').parseString;
const asyncLoop = require('node-async-loop');

module.exports = (app, wagner) => {

  router.get('/list', /*authMiddleware["verifyAccessToken"].bind(authMiddleware),*/  async (req, res, next) => {
    try{
      let sort = {'_id' : JSON.parse(req.query.sort)};
      let list = await wagner.get('product_manager').findAllPaginate({}, sort, req.query.pageNumber, req.query.recordsLimit);
      res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: list });
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.get('/categoryFilter', /*authMiddleware["verifyAccessToken"].bind(authMiddleware),*/  async (req, res, next) => {
    try{
      let sort = {'_id' : JSON.parse(req.query.sort)};
      let conds = {$or: [ 
        {'category.primary' : { $regex: '.*' + req.query.searchParam + '.*',$options:'i' }},
        {'category.secondary': { $regex: '.*' + req.query.searchParam + '.*',$options:'i' }}
      ]};
      let list = await wagner.get('product_manager').findAllPaginate(conds, sort, req.query.pageNumber, req.query.recordsLimit);
      res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: list });
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.get('/categoryInsert', /*authMiddleware["verifyAccessToken"].bind(authMiddleware),*/  async (req, res, next) => {
    try{
      // let data = [
      //   {"name" : "baby"},
      //   {"name" : "Movies, Books & Music"},
      //   {"name" : "Event Supplies"},
      //   {"name" : "Computing"},
      //   {"name" : "toys"},
      //   {"name" : "logos"},
      //   {"name" : "Tracking"},
      //   {"name" : "Musical Instruments"},
      //   {"name" : "Movies, Books and Music"},
      //   {"name" : "Food and Beverage"},
      //   {"name" : "Sunglasses"},
      //   {"name" : "Games and Toys"},
      //   {"name" : "mobile"},
      //   {"name" : "Designer"},
      //   {"name" : "Promotional"},
      //   {"name" : "Free Shipping"},
      //   {"name" : "Religious & Ceremonial"},
      //   {"name" : "Sports, Exercise and Outdoor Hobbies"},
      //   {"name" : "Automotive & Boats"},
      //   {"name" : "Appliances"},
      //   {"name" : "Sports & Fitness"},
      //   {"name" : "Office, Mailroom & School"},
      //   {"name" : "Food & Beverages"}
      // ]
      let data = [
        {"name" : "Accessories"},
        {"name" : "Apparel & Accessories"},
        {"name" : "Handbags"},
        {"name" : "Jewerly"},
        {"name" : "Luggage & Bags"},
        {"name" : "Men"},
        {"name" : "Women"},
        {"name" : "Fine jewellery"},
        {"name" : "Jewellery & Accessories"},
        {"name" : "Shoes"},        
      ]  
      let insert = await wagner.get('product_manager').insertCategory(data);
      res.status(HTTPStatus.OK).json({ success: '1', message: "Inserted.", data: '' });
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.get('/categoryList', /*authMiddleware["verifyAccessToken"].bind(authMiddleware),*/  async (req, res, next) => {
    try{
      let list = await wagner.get('product_manager').findAllCategory();
      res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: list });
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.get('/fetchProducts',  async (req, res, next) => {
    try{
      let config = {
        method: 'get',
        url: 'https://api.linksynergy.com/productsearch/1.0?pagenumber=1&cat=Fine%20jewellery',
        headers: { 
          'accept': 'application/xml', 
          'authorization': 'Bearer eHenXDCipaJIEyupV3HBy9RekJm3KOKg'
        }
      };        
      let apiRes = await axios(config);
      let apiParsedRes = await new Promise(async (resolve, reject)=>{
        parseString(apiRes.data, (err, result)=> {
          resolve(result);
        })
      })
      let flag = 1;
      let totalPages = parseInt(apiParsedRes.result.TotalPages)

      let pagesArray = [];
      for(var i=0; i<50; i++)
      pagesArray.push(i);
      
      asyncLoop(pagesArray, async(value, nextItration) => {     
        var config = {
          method: 'get',
          url: 'https://api.linksynergy.com/productsearch/1.0?pagenumber='+flag+'&cat=Fine%20jewellery',
          headers: { 
            'accept': 'application/xml', 
            'authorization': 'Bearer eHenXDCipaJIEyupV3HBy9RekJm3KOKg'
          }
        }; 

        axios(config).then( (response)=>{
          parseString(response.data, (err, result)=> {
            let count = 1;
            let arr = [];
            let apiResponse = result.result.item 
            asyncLoop(apiResponse, async(val, next) => {
              let data = {
                mid                  : val.mid[0],
                merchantname         : val.merchantname[0],
                linkid               : val.linkid[0],
                sku                  : val.sku[0],
                productname          : val.productname[0],
                category             : {
                  primary             : val.category[0].primary[0],
                  secondary           : val.category[0].secondary[0],
                },  
                price                : {
                  currency            : val.price[0].$.currency,
                  amount              : parseInt(val.price[0]._)
                },
                salePrice                : {
                  currency            : val.price[0].$.currency,
                  amount              : parseInt(val.price[0]._)
                },
                upccode              : val.mid[0], 
                description                : {
                  short            : val.description[0].short[0],
                  long              : val.description[0].long[0],
                },  
                keywords             : val.keywords[0],
                linkurl              : val.linkurl,    
                imageurl             : val.imageurl,
              }
              arr.push(data);
              count++;
              if(count == 20){
                let products = await wagner.get("product_manager").insert(arr);
                console.log("inserted")
                flag++;
                nextItration();
                if(flag == 51){
                  console.log("done");
                }  
              }else
              next();
            }) 
          });
        })
      })  
    }catch(e){
      console.log(e);
    }
  })    

  return router;
}  