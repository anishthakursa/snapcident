module.exports = (app, wagner, io, socket_array) => {
	app.get('/', (req, res, next)=> {
	  res.send("Snap-App Apis");
	});
	
	const users  = require('./users')(app, wagner, io, socket_array);
	const retailers  = require('./retailers')(app, wagner);
	const brands  = require('./brands')(app, wagner);
	const category  = require('./category')(app, wagner);
	const products  = require('./products')(app, wagner);	
	const advertisement  = require('./advertisement')(app, wagner);	

	app.use('/users', users);
	app.use('/retailers', retailers);
	app.use('/brands', brands);
	app.use('/category', category);
	app.use('/products', products);
	app.use('/advertisement', advertisement);
}