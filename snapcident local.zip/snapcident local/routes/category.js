var express = require('express');
var router = express.Router();
const { check, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds);
const HTTPStatus = require("http-status");
const mongoose = require('mongoose');

module.exports = (app, wagner) => {
    let authMiddleware = wagner.get("auth");

    router.post('/add', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
        check('name').not().isEmpty().withMessage("name is required.")
    ], async (req, res, next) => {
        try{
            let errors = validationResult(req);
            if(!errors.isEmpty()){
                console.log(errors);
                let lasterr = errors.array().pop();
                lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
                return res.status(405).json({ success: '0', message: "failure", data: lasterr });
            }
            let conds = {"name" : (req.body.name).toLowerCase()}
            let brand_data = await wagner.get('category_manager').find(conds);  
            if(brand_data){
                res.status(409).json({ success: '1', message: "Category Already exists.", data: '' });
            }else{
                let insert = await wagner.get('category_manager').insert(conds);
                res.status(HTTPStatus.OK).json({ success: '1', message: "Category Added", data: "" }); 
            }
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.get('/list',  async (req, res, next) => {
        try{
          let sort = {'_id' : JSON.parse(req.query.sort)};
          let users = await wagner.get('category_manager').findAllPaginate({}, sort, req.query.pageNumber, req.query.recordsLimit);
          res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: users });            
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.post('/likeUnlike', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
        check('category_id').not().isEmpty().withMessage("category_id is required."),
        check('status').not().isEmpty().withMessage("status is required.")
    ], async (req, res, next) => {
        try{
            let errors = validationResult(req);
            if(!errors.isEmpty()){
                console.log(errors);
                let lasterr = errors.array().pop();
                lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
                return res.status(405).json({ success: '0', message: "failure", data: lasterr });
            }
            req.body.user_id = req.user_id
            let likeUnlike = await wagner.get('category_manager').likeUnlike(req.body);
            res.status(HTTPStatus.OK).json({ success: '1', message: "Reaction Saved", data: "" });
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.get('/likedCategoryList',  authMiddleware["verifyAccessToken"].bind(authMiddleware), async (req, res, next) => {
        try{
            console.log(req.user_id);
            let users = await wagner.get('category_manager').findAllLikeCategory({user_id : req.user_id});
            res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: users });            
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    return router;
}    