var express = require('express');
var router = express.Router();
const { check, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds);
const HTTPStatus = require("http-status");
const mongoose = require('mongoose');

module.exports = (app, wagner) => {
    let authMiddleware = wagner.get("auth");

    router.post('/add', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
        check('name').not().isEmpty().withMessage("name is required."),
        check('description').not().isEmpty().withMessage("description is required."),
        check('image').not().isEmpty().withMessage("image is required."),
    ], async (req, res, next) => {
        try{
            let errors = validationResult(req);
            if(!errors.isEmpty()){
                console.log(errors);
                let lasterr = errors.array().pop();
                lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
                return res.status(405).json({ success: '0', message: "Enter valid data.", data: lasterr });
            }
            let conds = {"name" : (req.body.name).toLowerCase()}
            let advertisement_data = await wagner.get('advertisement_manager').find(conds);  
            if(advertisement_data){
                res.status(409).json({ success: '1', message: "Advertisement Already exists.", data: '' });
            }else{
                let insert = await wagner.get('advertisement_manager').insert(req.body);
                res.status(HTTPStatus.OK).json({ success: '1', message: "Advertisement Added successfully", data: "" }); 
            }
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.post('/update', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
        check('ad_id').not().isEmpty().withMessage("advertisement id is required."),
    ], async (req, res, next) => {
        try{
            //--------validate data----------
            let errors = validationResult(req);
            if(!errors.isEmpty()){
                console.log(errors);
                let lasterr = errors.array().pop();
                lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
                return res.status(405).json({ success: '0', message: "Enter valid data.", data: lasterr });
            }
             //--------check  data----------
            let conds_a = {"_id": req.body.ad_id}
            let conds = {"_id": { $ne:  req.body.ad_id},"name" : (req.body.name).toLowerCase()}
            let advertisement_data = await wagner.get('advertisement_manager').find(conds);  
            if(advertisement_data){
                res.status(409).json({ success: '1', message: "Advertisement Already exists.", data: '' });
            }else{
                let advertData = await wagner.get('advertisement_manager').find(conds_a);
                if(advertData){
                //--------update  data----------
                let insert = await wagner.get('advertisement_manager').update(req.body , conds_a);
                if(req.body.status!=undefined || req.body.status!=null){
                    if(req.body.status==0){
                    res.status(HTTPStatus.OK).json({ success: '1', message: "Advertisement deleted successfully", data: "" });
                    }else{
                        res.status(HTTPStatus.OK).json({ success: '1', message: "Advertisement updated successfully", data: "" });
                    }
                }else{
                    res.status(HTTPStatus.OK).json({ success: '1', message: "Advertisement updated successfully", data: "" });
                }
                }else{
                    res.status(403).json({ success: '0', message: "Data not found", data: "" });
                }
            }
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.get('/filter', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
        try{
          let sort = {'_id' : JSON.parse(req.query.sort)};
          let reqQuery = req.query;
          let jsonObj = {status:1};
         
          
          function strToObj(str){
              var obj      = {};
              if(str&&typeof str ==='string'){
                  var objStr = str.match(/\{(.)+\}/g);
                  eval("obj ="+objStr);
              }
              return obj
          }
          if(req.query.searchParam!=="undefined"){
            jsonObj.$or =  [ 
                {name: { $regex: '.*' + req.query.searchParam + '.*',$options:'i' } },
                {link: { $regex: '.*' + req.query.searchParam + '.*',$options:'i' } },
            ];
          }   
          let advertisement = await wagner.get('advertisement_manager').findAllPaginate(jsonObj, sort, req.query.pageNumber, req.query.recordsLimit);
          res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: advertisement });            
        }catch(e){
            console.log(e)
            res.status(500).json({ success: '0', message: "failure", data: e });
        } 
    });

    router.get('/getAdvertisementById', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
      try{
        let conds = {"_id": req.query.ad_id,"status":1};
        let advertisementData = await wagner.get('advertisement_manager').find(conds);
        var advertisement_list = "";
        if(advertisementData){
          advertisement_list = {
            "advertisement_data" : advertisementData,
          };
        }
        res.status(HTTPStatus.OK).json({ success: '1', message: "Data fetched succesfully.", data: advertisement_list});
      }catch(e){
          console.log(e)
          res.status(500).json({ success: '0', message: "failure", data: e });
      } 
    });

    router.get('/setAdvertisementStatus', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
      try{
        let conds = {"_id": req.query.ad_id};
        let status = req.query.status;
        let advertData = await wagner.get('advertisement_manager').find(conds);
        if(advertData){
        //--------update  data----------
        let request = {$set: {"status": status}};
        let update = await wagner.get('advertisement_manager').update(request , conds);
        if(status == 0){
          res.status(HTTPStatus.OK).json({ success: '1', message: "Advertisement deleted successfully", data: "" }); 

        }else{
          res.status(HTTPStatus.OK).json({ success: '1', message: "Advertisement activated successfully", data: "" }); 

        }
        }else{
            res.status(403).json({ success: '0', message: "Data not found", data: "" });
        }
      }catch(e){
          console.log(e)
          res.status(500).json({ success: '0', message: "failure", data: e });
      } 
    });

      router.get('/getAdvertisementListing', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
      try{
        let conds = {"status":1};
        let sort = {"_id":1};
        let advertisementData = await wagner.get('advertisement_manager').findAll(conds,sort);
        var advertisement_list = "";
        if(advertisementData){
          console.log(advertisementData.length);
          advertisement_list = {
            "advertisement_data" : advertisementData,
          };
        }
        res.status(HTTPStatus.OK).json({ success: '1', message: "Data fetched succesfully.", data: advertisement_list});
      }catch(e){
          console.log(e)
          res.status(500).json({ success: '0', message: "failure", data: e });
      } 
    });
       

  return router;
}
