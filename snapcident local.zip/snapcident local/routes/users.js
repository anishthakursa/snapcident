var express = require('express');
var router = express.Router();
const { check, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds);
const HTTPStatus = require("http-status");
const mongoose = require('mongoose');


module.exports = (app, wagner, io, socket_array) => {

  // let socket_array      = [];
  // io.on('connection', function(socket){
  //   try {
  //       console.log('socket', socket);
  //       if (socket.handshake && socket.handshake.query && socket.handshake.query.user_id) {
  //           let user_id = socket.handshake.query.user_id;
  //           for (let i = 0; i < socket_array.length; i++) {
  //               if ((socket_array[i].user_id == user_id && socket_array[i].domain == domain )|| socket_array[i].user_id === undefined) {
  //                   socket_array.splice(i, 1);
  //               }
  //           }

  //           let arr = {
  //             socket_id: socket.id,
  //             user_id: user_id
  //           };

  //           socket_array.push(arr);
  //       }
  //   } catch(err) {
  //       console.log(err);
  //   }
  // });

  let authMiddleware = wagner.get("auth");

  router.get('/', function(req, res, next) {
    res.send('respond with a resource');
  });

  router.post('/add', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
    check('email').exists().withMessage('email is required').isEmail().withMessage('email not valid'),
    check('firstname').not().isEmpty().withMessage("firstname is required."),
    check('lastname').not().isEmpty().withMessage("lastname is required."),
    check('phone_number').not().isEmpty().withMessage("phone_number is required."),
    check('role_id').not().isEmpty().withMessage("type is required."),
    check('active').not().isEmpty().withMessage("status is required.")
], async (req, res, next) => {
    try{
        let errors = validationResult(req);
        if(!errors.isEmpty()){
            console.log(errors);
            let lasterr = errors.array().pop();
            lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
             if(!req.body.active){
              return res.status(405).json({ success: '0', message: "Please choose status.", data: lasterr });
            }
            if(!req.body.role_id){
              return res.status(405).json({ success: '0', message: "Please choose type.", data: lasterr });
            }
            return res.status(405).json({ success: '0', message: "Enter valid data.", data: lasterr });
        }
        var notifcheck = {
          "event":"new_account",
        };
        let NotificationData = await wagner.get('user_manager').findNotification(notifcheck);
        let conds = {$or:[{ email : (req.body.email).toLowerCase() }, { phone_number : req.body.phone_number }]};
        let user_data = await wagner.get('user_manager').find(conds);  
        if(user_data){
          if(user_data.phone_number == req.body.phone_number && user_data.email!== req.body.email){
              res.status(409).json({ success: '1', message: "Phone Number already exists.", data: '' });
          }else if(user_data.email== req.body.email && user_data.phone_number !== req.body.phone_number){
              res.status(409).json({ success: '1', message: "Email already exists.", data: '' });
          }else{
            res.status(409).json({ success: '1', message: "Email and Phone Number already exists.", data: '' });
          }
        }else{
            let pass = "S"+(req.body.firstname)+"@123";
            req.body.password = await bcrypt.hashSync(pass, salt);
            let insert = await wagner.get('user_manager').insert(req.body);
            let sendPasswordMail = await wagner.get('retailer_manager').sendLoginMail(req.body, pass);
            if(NotificationData){
              if(NotificationData.active == 1){
                statusMailData = {
                  "name" : req.body.firstname+ " "+req.body.lastname,
                  "title"  :  NotificationData.options[0],
                  "email"   :  req.body.email,
                }
                let sendWelcomeAlertMail = await wagner.get('user_manager').sendWelcomeAlert(statusMailData);
              }
            }
            res.status(HTTPStatus.OK).json({ success: '1', message: "User Added", data: "" }); 
        }
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.post('/register', [
    check('email_phone').not().isEmpty().withMessage("Email Id or Phone Number is required."),
    check('password').matches(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~])[A-Za-z\d!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]{8,}$/).withMessage('Password must be atleast 8 characters and should contain at least one letter, one number and one special character')
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
          let lasterr = errors.array().pop();
          lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
          return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      let conds = {$or:[{ email : (req.body.email_phone).toLowerCase() }, { phone_number : req.body.email_phone }]};
      let userData = await wagner.get('user_manager').find(conds);
      if(userData){
        res.status(409).json({ success: '1', message: "Email or Phone Number already exists.", data: '' });
      }else{
        let encryptedPass = await bcrypt.hashSync(req.body.password, salt);
        let request;
        var otp = Math.floor(1000 + Math.random() * 9000);
        let regexEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

        if (req.body.email_phone.match(regexEmail)) {
          request = {
            "email" : req.body.email_phone,
            "password" : encryptedPass,
            "username" : req.body.username ? req.body.username : ""
          }
          let sendVerificationMail = await wagner.get('user_manager').sendOtpMail(request, otp);
        } else {
          request = {
            "phone_number" : (req.body.email_phone).toLowerCase(),
            "password" : encryptedPass,
            "username" : req.body.username ? req.body.username : ""
          }
          //let sendVerificationMsg = await wagner.get('SmsHelper').sendSms(['+919988941581'], "9872");
        }


        let insert = await wagner.get('user_manager').insert(request);
        request.user_id = insert._id
        let insertOtp = await wagner.get('user_manager').insertOtp({otp:otp, user_id:insert._id});
        let token = await wagner.get('auth')["generateShortAccessToken"](request,res);
        res.status(HTTPStatus.OK).json({ success: '1', message: "Verification Otp sent.", data: {"token":token, user_id : insert._id, userData : request, otp:otp }});
      }         
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });

  router.post('/login', [      
    check('email_phone').not().isEmpty().withMessage("Email Id or Phone Number is required."),
    check('password').not().isEmpty().withMessage("Password is required").bail(),
    check('device_type').not().isEmpty().withMessage("Device Type is required").bail()
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
          console.log(errors);
          let lasterr = errors.array().pop();
          lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
          return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      let conds = {$or:[{ email : (req.body.email_phone).toLowerCase() }, { phone_number : req.body.email_phone }]};
      let userData = await wagner.get('user_manager').find(conds);
      // create random number
       var otp = Math.floor(1000 + Math.random() * 9000);
      if(userData){
        if(userData.active == 0){
          return res.status(409).json({ success: '1', message: "Your account is suspended.", data: '' });
        }
        else if(userData.active == 2){
          return res.status(409).json({ success: '1', message: "Your account is archived.", data: '' });

        }
        else if(userData.role_id == 1 && req.body.device_type != 3){
          return res.status(403).json({ success: '0', message: "Mobile Access Denied.", data: '' });
        }
        else if(userData.role_id == 2 && req.body.device_type == 3){
          return res.status(403).json({ success: '0', message: "Web Access Denied.", data: '' });
        }
        else if(userData.role_id == 2 && userData.status == 0){
          requestotp = {
            "email" : userData.email,
            "name"  : userData.firstname+" "+userData.lastname,
          }
          let sendVerificationMail = await wagner.get('user_manager').sendOtpMail(requestotp, otp);
          return res.status(409).json({ success: '0', message: "User not verified.Otp is sent again.", data: otp });
        }
        else if(userData.active == 1){
          console.log(req.body.password+" abcd    "+userData.password);
          if( (bcrypt.compareSync( req.body.password, userData.password ) ) ){
            let jsonData = {
              '_id': userData._id,
              'username': userData.username ? userData.username : "",
              'email': userData.email ? userData.email : "",
              'phone_number': userData.phone_number ? userData.phone_number : "",
              // 'profile_image': userData.profile_image ? userData.profile_image : ""           
            }
            let jsonData1 = {
              '_id': userData._id,
              'username': userData.username ? userData.username : "",
              'email': userData.email ? userData.email : "",
              'phone_number': userData.phone_number ? userData.phone_number : "",
              'profile_image': userData.profile_image ? userData.profile_image : ""           
            }
            let token = await wagner.get('auth')["generateAccessToken"](jsonData,res);
            if(req.body.device_type!=3){
              let device_data = {
                user_id : mongoose.Types.ObjectId( userData._id),
                device_type : req.body.device_type,
                device_id   : req.body.device_id
              }
              let insertDeviceToken = await wagner.get('user_manager').insertDeviceToken(device_data);
            }

            if(jsonData1){
              res.status(HTTPStatus.OK).json({ success: '1', message: "User Data", data: {token: token, userData : jsonData1}}); 

            } 
                          
          }else{
            res.status(401).json({ success: '1', message: "In-correct login credentials.", data: '' });  
          }
        }else{
          res.status(409).json({ success: '1', message: "User not verified.", data: {user_id : userData._id} }); 
        }    
      }else{
        res.status(400).json({ success: '1', message: "No user found.", data: '' });  
      }        
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });  

  router.post('/adminLogin', [      
    check('email_phone').not().isEmpty().withMessage("Email Id or Phone Number is required."),
    check('password').not().isEmpty().withMessage("Password is required").bail()
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
          console.log(errors);
          let lasterr = errors.array().pop();
          lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
          return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      let conds = {$or:[{ email : (req.body.email_phone).toLowerCase() }, { phone_number : req.body.email_phone }], role_id:1};
      let userData = await wagner.get('user_manager').find(conds);
      if(userData){
          if( (bcrypt.compareSync( req.body.password, userData.password ) ) ){
            let jsonData = {
              '_id': userData._id,
              'username': userData.username ? userData.username : "",
              'email': userData.email ? userData.email : "",
              'phone_number': userData.phone_number ? userData.phone_number : ""             
            }
            let token = await wagner.get('auth')["generateAccessToken"](jsonData,res);
            
            res.status(HTTPStatus.OK).json({ success: '1', message: "User Data", data: {token: token, userData : jsonData}}); 
              
          }else{
            res.status(401).json({ success: '1', message: "In-correct login credentials.", data: '' });  
          }
    
      }else{
        res.status(400).json({ success: '1', message: "No user found.", data: '' });  
      }        
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });  

  router.post('/socialMediaLogin', [      
    check('social_media_id').not().isEmpty().withMessage("socialMediaId is required."),
    check('social_media_platform').not().isEmpty().withMessage("Social Media Platform is required."),
    check('device_type').not().isEmpty().withMessage("Device Type is required").bail()
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
          console.log(errors);
          let lasterr = errors.array().pop();
          lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
          return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      let conds = { social_media_id : req.body.social_media_id, social_media_platform : req.body.social_media_platform, status : 1 }
      let findUserData = await wagner.get('user_manager').find(conds);
      let userData = findUserData ? findUserData : await wagner.get('user_manager').insert(conds);
        let jsonData = {
          '_id': userData._id,
          'username': userData.username ? userData.username : "",
          'email': userData.email ? userData.email : "" ,
          'phone_number': userData.phone_number ? userData.phone_number : "",
          "social_media_id" : userData.social_media_id,
          "social_media_platform" : userData.social_media_platform            
        }
        let token = await wagner.get('auth')["generateAccessToken"](jsonData,res);
        if(req.body.device_type!=3){
          let device_data = {
            user_id : mongoose.Types.ObjectId( userData._id),
            device_type : req.body.device_type,
            device_id   : req.body.device_id
          }

          let insertDeviceToken = await wagner.get('user_manager').insertDeviceToken(device_data);
        }
        
        res.status(HTTPStatus.OK).json({ success: '1', message: "User Data", data: token}); 
     
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });
  
  router.post('/otpVerify', [      
    check('user_id').not().isEmpty().withMessage("User Id is required"),
    check('otp').not().isEmpty().withMessage("Otp is required").bail()
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
        console.log(errors);
        let lasterr = errors.array().pop();
        lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
        return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      let conds = {user_id : req.body.user_id, otp : req.body.otp};
      let otpFind = await wagner.get('user_manager').findOtp(conds);
      if(otpFind){
        var today = new Date();
        var diff = Math.abs(today - otpFind.createdAt);
        var minutes = Math.floor((diff/1000)/60);
        console.log(req.body.user_id);
        if(minutes<30){
          let verifyUser = await wagner.get('user_manager').update({"status" : 1},{"_id":req.body.user_id});
          console.log(verifyUser)
          res.status(HTTPStatus.OK).json({ success: '1', message: "User Verified", data: ""}); 
        }else{
          console.log("bye")
          res.status(409).json({ success: '1', message: "Otp Expired.", data: {user_id : req.body.user_id} }); 
        }
      }else{
        res.status(409).json({ success: '1', message: "Incorrect Otp.", data: {user_id : req.body.user_id} });     
      }  
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });    

  router.post('/resendOtp', [
    check('user_id').not().isEmpty().withMessage("User Id is required")
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
        let lasterr = errors.array().pop();
        lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
        return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      var otp = Math.floor(1000 + Math.random() * 9000);
      let conds = { "_id" : req.body.user_id}
      let userData = await wagner.get('user_manager').find(conds);

      if (userData && userData.email) {
        let deleteOtp = await wagner.get('user_manager').deleteOtp({user_id:userData._id});
        let insertOtp = await wagner.get('user_manager').insertOtp({otp:otp, user_id:userData._id});
        request = {
          "email" : userData.email
        }

        let sendVerificationMail = await wagner.get('user_manager').sendOtpMail(request, otp);
        res.status(HTTPStatus.OK).json({ success: '1', message: "OTP sent", data: ""}); 
      } else if(userData && userData.phone_number){
        let deleteOtp = await wagner.get('user_manager').deleteOtp({user_id:userData._id});
        let insertOtp = await wagner.get('user_manager').insertOtp({otp:otp, user_id:userData._id});
        res.status(409).json({ success: '1', message: "Cant send otp to mobile number.", data: otp });  
      // request = {
      //   "phone_number" : req.body.email_phone,
      //   "password" : encryptedPass,
      //   "username" : req.body.username ? req.body.username : ""
      // }
      //let sendVerificationMsg = await wagner.get('SmsHelper').sendSms(['+919988941581'], "9872");
      
      }else{
        res.status(409).json({ success: '1', message: "No email or mobile number attached to account.", data: {user_id : req.body.user_id} }); 
      } 
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });  
  
  router.post('/forgetPass', [
    check('email_phone').not().isEmpty().withMessage("Email Id or Phone Number is required.")
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
          let lasterr = errors.array().pop();
          lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
          return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      var otp = Math.floor(1000 + Math.random() * 9000);
      let conds = {$or:[{ email : (req.body.email_phone).toLowerCase() }, { phone_number : req.body.email_phone }]};
      let userData = await wagner.get('user_manager').find(conds);
      if(userData){
        let user_name = userData.firstname+" "+userData.lastname;
        if (userData.email) {
          let deleteOtp = await wagner.get('user_manager').deleteOtp({user_id:userData._id});
          let insertOtp = await wagner.get('user_manager').insertOtp({otp:otp, user_id:userData._id});
          request = {
            "email" : userData.email,
            "name"  : userData.firstname+" "+userData.lastname,
          }
          let sendVerificationMail = await wagner.get('user_manager').sendOtpMail(request, otp);
          
          res.status(HTTPStatus.OK).json({ success: '1', message: "OTP sent", data: {otp:otp , user_id:userData._id , email:userData.email , profile_image:userData.profile_image , name:user_name
          } }); 
        }else{
          let deleteOtp = await wagner.get('user_manager').deleteOtp({user_id:userData._id});
          let insertOtp = await wagner.get('user_manager').insertOtp({otp:otp, user_id:userData._id});
          res.status(409).json({ success: '1', message: "Cant send otp to mobile number.", data: {otp:otp , user_id:userData._id , email:userData.email, profile_image:userData.profile_image , name:user_name} });  
        }
      }else{
        res.status(400).json({ success: '1', message: "No user found.", data: '' });  
      }  
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });  

  router.post('/changePass', [
    check('user_id').not().isEmpty().withMessage("User Id is required."),
    check('password').not().isEmpty().withMessage("Password is required").bail(),
  ], async (req, res, next) => {
    try{
      let errors = validationResult(req);
      if(!errors.isEmpty()){
          let lasterr = errors.array().pop();
          lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
          return res.status(405).json({ success: '0', message: "failure", data: lasterr });
      }
      let encryptedPass = await bcrypt.hashSync(req.body.password, salt);
      let update = await wagner.get('user_manager').update({"password" : encryptedPass}, {"_id":req.body.user_id});
      res.status(HTTPStatus.OK).json({ success: '1', message: "Password Changed", data: ""}); 
    }catch(e){
      console.log(e)
      res.status(500).json({ success: '0', message: "failure", data: e });
    }
  });    

  router.get('/userList', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
    try{
      let sort = {'_id' : JSON.parse(req.query.sort)};
      let users = await wagner.get('user_manager').findAllPaginate({}, sort, req.query.pageNumber, req.query.recordsLimit);
      if(users){
        res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: users });            
      }else{
        res.status(405).json({ success: '0', message: "failure", data: "" });
      }
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.post( "/update", authMiddleware["verifyAccessToken"].bind(authMiddleware), [
    check('email').isEmail(),
    check('user_id').not().isEmpty().withMessage("User Id is required.")
  ],async (req, res, next) => {
    try {
      let errors = validationResult(req);
      if(!errors.isEmpty()){
        console.log("errir is"+errors);
        let lasterr = errors.array().pop();
        lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
        return res.status(405).json({ success: '0', message: "Enter valid data.", data: lasterr });
      }
      let conds = { "_id": req.body.user_id };
      let socketInfo = socket_array.find(x => x.user_id === req.body.user_id);
      var userresetpassword = "";
      let userDataNew = await wagner.get('user_manager').find(conds);
      var status_array = {0:"Suspended",1:"Active",2:"Archived"};
      var u_status = status_array[req.body.active];
      var passwordnotifcheck = {
        "event":"reset_password",
      };
      let PasswordNotificationData = await wagner.get('user_manager').findNotification(passwordnotifcheck);
      var notifcheck = {
            "event":"status_change",
            "user_status":u_status
      };
      let NotificationData = await wagner.get('user_manager').findNotification(notifcheck);
      let check;
      if(req.body.phone_number && req.body.email){
        check = {
          _id: { $ne:  req.body.user_id},
          $or:[
          { email : (req.body.email).toLowerCase() },
          { phone_number : req.body.phone_number }]
        }
      }
      let request = req.body
      delete request.user_id;
      if(req.body.password){
        userresetpassword = req.body.password;
        let encryptedPass = await bcrypt.hashSync(req.body.password, salt);
        request.password = encryptedPass;
      }else{
        req.body.password = userDataNew.password;
      }
      if(check){
        let userData = await wagner.get('user_manager').find(check);
        if(userData){
           if(userData.phone_number == req.body.phone_number && userData.email!== req.body.email){
              res.status(409).json({ success: '1', message: "Phone Number already exists.", data: '' });
          }else if(userData.email== req.body.email && userData.phone_number !== req.body.phone_number){
              res.status(409).json({ success: '1', message: "Email already exists.", data: '' });
          }
          else{
            res.status(409).json({ success: '1', message: "Email and Phone Number already exists.", data: '' });
          }
        }else{
          let userData = await wagner.get("user_manager").update(request, conds);
          if(socketInfo && request.active == 0) {
            io.to(socketInfo.socket_id).emit("Terminate_Session", socketInfo.user_id);
          }
          if(socketInfo && request.active == 2) {
          io.to(socketInfo.socket_id).emit("Terminate_Session", socketInfo.user_id);
          }
          if(userDataNew.email && req.body.email && (userDataNew.email !== req.body.email)){
            mailData = {
              "name" : userDataNew.firstname+ " "+userDataNew.lastname,
              "old_email" : userDataNew.email,
              "new_email"  : req.body.email,
            }
            let sendAlertMail = await wagner.get('user_manager').sendEmailAlert(mailData);
          }
          if(NotificationData && userDataNew.active !== req.body.active){
            if(NotificationData.active == 1){
              statusMailData = {
                "name" : req.body.firstname+ " "+req.body.lastname,
                "status" :   u_status,
                "title"  :  NotificationData.options[0],
                "email"   :  req.body.email,
              }
              let sendStatusAlertMail = await wagner.get('user_manager').sendStatusChangeAlert(statusMailData);
            }
          }
          if(PasswordNotificationData && userresetpassword){
              statusMailData = {
                "name" : req.body.firstname+ " "+req.body.lastname,
                "password" :  userresetpassword,
                "title"  :  PasswordNotificationData.options[0],
                "email"   :  req.body.email,
              }
              let sendPasswordAlertMail = await wagner.get('user_manager').sendPasswordChangeAlert(statusMailData);
          }
          res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
        }
      }else{
        let userData = await wagner.get("user_manager").update(request, conds);
        if(socketInfo && request.active == 0) {
          io.to(socketInfo.socket_id).emit("Terminate_Session", socketInfo.user_id);
        }
        if(socketInfo && request.active == 2) {
          io.to(socketInfo.socket_id).emit("Terminate_Session", socketInfo.user_id);
        }
        if(userDataNew.email && req.body.email && (userDataNew.email !== req.body.email)){
            mailData = {
              "name" : userDataNew.firstname+ " "+userDataNew.lastname,
              "old_email" : userDataNew.email,
              "new_email"  : req.body.email,
            }
            let sendAlertMail = await wagner.get('user_manager').sendEmailAlert(mailData);
        }
        if(NotificationData && userDataNew.active !== req.body.active){
          if(NotificationData.active == 1){
            statusMailData = {
              "name" : req.body.firstname+ " "+req.body.lastname,
              "status" :   u_status,
              "title"  :  NotificationData.options[0],
              "email"   :  req.body.email,
            }
            let sendStatusAlertMail = await wagner.get('user_manager').sendStatusChangeAlert(statusMailData);
          }
        }
        if(PasswordNotificationData && userresetpassword != ""){
          if(PasswordNotificationData.active == 1){
            statusMailData = {
              "name" : req.body.firstname+ " "+req.body.lastname,
              "password" :  userresetpassword,
              "title"  :  NotificationData.options[0],
              "email"   :  req.body.email,
            }
            let sendPasswordAlertMail = await wagner.get('user_manager').sendPasswordChangeAlert(statusMailData);
          }
        }
        res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
      }  
        
      // }else if(req.body.phone_number){
      //   let userData = await wagner.get('user_manager').find(
      //     {phone_number : req.body.phone_number,
      //     _id: { $ne:  req.body.user_id}           
      //   });
      //   if(userData){
      //     res.status(409).json({ success: '1', message: "Phone Number already exists.", data: '' });
      //   }else{
      //     let userData = await wagner.get("user_manager").update(request, conds);
      //     res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
      //   }
      // }else if(req.body.email){
      //   let userData = await wagner.get('user_manager').find(
      //     {email : req.body.email,
      //     _id: { $ne:  req.body.user_id}           
      //   });
      //   if(userData){
      //     res.status(409).json({ success: '1', message: "Email already exists.", data: '' });
      //   }else{
      //     let userData = await wagner.get("user_manager").update(request, conds);
      //     res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
      //   }
      // }else{
      //   let userData = await wagner.get("user_manager").update(request, conds);
      //   res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
      // }

    } catch (e) {
      console.log(e);
      res.status(500).json({ success: "0", message: "failure", data: e });
    }   
  })  

  router.post('/search', authMiddleware["verifyAccessToken"].bind(authMiddleware), [
    check('searchParam').not().isEmpty().withMessage("searchParam is required.")
], async (req, res, next) => {
    try{
        let errors = validationResult(req);
        if(!errors.isEmpty()){
            console.log(errors);
            let lasterr = errors.array().pop();
            lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
            return res.status(405).json({ success: '0', message: "failure", data: lasterr });
        }
        let conds = {$or: [ 
          {email: { $regex: '.*' + req.body.searchParam + '.*',$options:'i' }},
          {firstname: { $regex: '.*' + req.body.searchParam + '.*',$options:'i' }},
          {lastname: { $regex: '.*' + req.body.searchParam + '.*',$options:'i' }},
          {username: { $regex: '.*' + req.body.searchParam + '.*',$options:'i' }},
        ]};
        let sort = {'_id' : JSON.parse(req.body.sort)};

        let user_data = await wagner.get('user_manager').findAllPaginate(conds, sort, req.body.pageNumber, req.body.recordsLimit);  
        res.status(HTTPStatus.OK).json({ success: '1', message: "User Data", data: user_data });
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.get('/filter', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
    try{
      let sort = {'_id' : JSON.parse(req.query.sort)};
      let reqQuery = req.query;
      let jsonObj      = await strToObj(reqQuery.filter);
      
      function strToObj(str){
          var obj      = {};
          if(str&&typeof str ==='string'){
              var objStr = str.match(/\{(.)+\}/g);
              eval("obj ="+objStr);
          }
          return obj
      }
         //counting number of words 
      search_string = req.query.searchParam;
      word_split = search_string.trim().split(/\s+/);
      words_count =   word_split.length;
      if(req.query.searchParam!=="undefined"){
        if(words_count == 2){
          first_word =  word_split[0];
          second_word =  word_split[1];
          jsonObj.$and =  [
            {firstname: { $regex: '.*' +  first_word + '.*',$options:'i' }},
            {lastname: { $regex: '.*' +  second_word + '.*',$options:'i' }},
          ]
          
        }else{
          jsonObj.$or =  [ 
            {email: { $regex: '^' + req.query.searchParam + '$',$options:'i' }},
            {firstname: { $regex: '.*' + req.query.searchParam + '.*',$options:'i' }},
            {lastname: { $regex: '.*' + req.query.searchParam + '.*',$options:'i' }},
            {username: { $regex: '.*' + req.query.searchParam + '.*',$options:'i' }}
          ]   
        }
      }   
      let users = await wagner.get('user_manager').findAllPaginate(jsonObj, sort, req.query.pageNumber, req.query.recordsLimit);
      res.status(HTTPStatus.OK).json({ success: '1', message: "Data.", data: users });            
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });
   
  router.post('/addNotification', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
    try{
      let add = await wagner.get('user_manager').addNotification(req.body);
      res.status(HTTPStatus.OK).json({ success: '1', message: "Added.", data: '' });
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.get('/listNotification', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
    try{
      let list = await wagner.get('user_manager').listNotification({});
      res.status(HTTPStatus.OK).json({ success: '1', message: "Added.", data: list });
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.post( "/updateNotification", authMiddleware["verifyAccessToken"].bind(authMiddleware), [
    check('notification_id').not().isEmpty().withMessage("notification_id is required.")
  ],async (req, res) => {
    try {
      let conds = { "_id": req.body.notification_id };
      let request = req.body
      delete request.notification_id;
      let userData = await wagner.get("user_manager").updateNotification(request, conds);
      res.status(HTTPStatus.OK).json({ success: "1", message: "Template updated succesfully.", data: "" });
    } catch (e) {
      console.log(e);
      res.status(500).json({ success: "0", message: "failure", data: e });
    }   
  })

  router.get('/getDashboardCount', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
    try{
      let conds = { "active": {$in: [1, 2 , 0]},"status": {$in: [1 , 0]}};
      let userData = await wagner.get('user_manager').findAll(conds);
      let record_list = {
        "user_count" : userData.length,
    };
      res.status(HTTPStatus.OK).json({ success: '1', message: "Data fetched succesfully.", data: record_list });
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.get('/getLoginUserStatus', authMiddleware["verifyAccessToken"].bind(authMiddleware),  async (req, res, next) => {
    try{
       //get user_id from auth token for mobile and query id for admin
      let authData = await wagner.get('user_manager').getAuthUserData(req);
      let authUserId = authData._id;
      let user_id = req.query.user_id ? req.query.user_id : authUserId;

      let conds = {"_id": user_id};
      let userData = await wagner.get('user_manager').find(conds);
      var user_list = "";
      if(userData){
        userData.firstname = userData.firstname ? userData.firstname : "";
        userData.lastname = userData.lastname ? userData.lastname : "";
        userData.phone_number = userData.phone_number ? userData.phone_number : "";
        userData.preferences = userData.preferences ? userData.preferences : "";
        
        user_list = {
          "user_data" : userData,
        };
      }
      res.status(HTTPStatus.OK).json({ success: '1', message: "Data fetched succesfully.", data: user_list});
    }catch(e){
        console.log(e)
        res.status(500).json({ success: '0', message: "failure", data: e });
    } 
  });

  router.post( "/setUserProfile", authMiddleware["verifyAccessToken"].bind(authMiddleware), [
  ],async (req, res, next) => {
    //------------set profile of mobile user-------------
    try {
      let errors = validationResult(req);
      if(!errors.isEmpty()){
        console.log("errir is"+errors);
        let lasterr = errors.array().pop();
        lasterr.message = lasterr.msg + ": " + lasterr.param.replace("_"," ");
        return res.status(405).json({ success: '0', message: "Enter valid data.", data: lasterr });
      }
      let authData = await wagner.get('user_manager').getAuthUserData(req);
      let authUserId = authData._id;
      let conds = { "_id": authUserId };
      let check;
      if(req.body.phone_number && req.body.email){
        check = {
          _id: { $ne:  authUserId},
          $or:[
          { email : (req.body.email).toLowerCase() },
          { phone_number : req.body.phone_number }]
        }
      }
      let request = req.body
      if(check){
        let userData = await wagner.get('user_manager').find(check);
        if(userData){
           if(userData.phone_number == req.body.phone_number && userData.email!== req.body.email){
              res.status(409).json({ success: '1', message: "Phone Number already exists.", data: '' });
          }else if(userData.email== req.body.email && userData.phone_number !== req.body.phone_number){
              res.status(409).json({ success: '1', message: "Email already exists.", data: '' });
          }
          else{
            res.status(409).json({ success: '1', message: "Email and Phone Number already exists.", data: '' });
          }
        }else{
          let userData = await wagner.get("user_manager").update(request, conds);
          res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
        }
      }else{
        let userData = await wagner.get("user_manager").update(request, conds);
        res.status(HTTPStatus.OK).json({ success: "1", message: "Updated succesfully.", data: "" });
      }  
    } catch (e) {
      console.log(e);
      res.status(500).json({ success: "0", message: "failure", data: e });
    }   
  });

  
  return router;
}

