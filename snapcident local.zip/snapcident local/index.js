const express = require("express");
const app = express();
const path = require("path");
const mongoose = require("mongoose");
const cors = require("cors");
const fs = require("fs");
const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
const swaggerDefinition = require("./swaggerDefinition");
require("dotenv-flow").config();
// const cookieParser= require('cookie-parser');

mongoose.connect(
  "mongodb://seasiaconnect:CTUZkwB94$2YzP@10.8.14.92:29083/seasiaconnect",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  },
  function (error) {
    if (error) {
      console.log(error);
    } else {
      console.log("Connect TO Mongo Cloud");
    }
  }
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//Routes
// TODO: We should have one file for all the routes.
const adminRoute = require("./routes/admin");
const clientRoute = require("./routes/clients");
const userRoute = require("./routes/users");
const projectRoute = require("./routes/projects");
const mobileRoute = require("./routes/mobiles");
const dashboardRoute = require("./routes/dashboard");
const milestoneRoute = require("./routes/milestone");

app.use(express.static("public"));
app.use( "/public/uploads/documents",express.static(__dirname + "/public/uploads/documents")
);
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "hbs");


// Extended: https://swagger.io/specification/#infoObject
let swaggerOptions = {
  swaggerDefinition: swaggerDefinition,
  apis: ["routes.js"],
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);

app.use(cors());

//Router Middleware
app.use(adminRoute);
app.use(clientRoute);
app.use(userRoute);
app.use(projectRoute);
app.use(mobileRoute);
app.use(dashboardRoute);
app.use(milestoneRoute);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

const server = app.listen(5034, () => {
  console.log(`Listening on port ${5034}`);
});
