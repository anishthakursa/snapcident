"use strict"

const mongoose  = require('mongoose'),
      Schema    = mongoose.Schema;

let AdvertisementSchema = new Schema({
  name                : {type: String, required: true},
  description         : {type: String, required: true},
  link                : {type: String, required: false},
  image               : {type: String, required: true},
  status              : {type: Number, required: true, default: 1}, 
},{ timestamps : true });

module.exports = mongoose.model('Advertisement', AdvertisementSchema);

