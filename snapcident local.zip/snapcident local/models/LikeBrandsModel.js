"use strict"

const mongoose  = require('mongoose'),
    Schema    = mongoose.Schema;

let LikeBrandsSchema = new Schema({
    user_id              : {type: String, required: true},
    brand_id             : {type: String, required: true}
},{ timestamps : true });

module.exports = mongoose.model('LikeBrands', LikeBrandsSchema);