"use strict"

const mongoose  = require('mongoose'),
    Schema    = mongoose.Schema;

let LikeCategorySchema = new Schema({
    user_id              : {type: String, required: true},
    category_id          : {type: String, required: true}
},{ timestamps : true });

module.exports = mongoose.model('LikeCategory', LikeCategorySchema);