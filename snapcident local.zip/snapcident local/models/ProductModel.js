
"use strict"

const mongoose  = require('mongoose'),
      Schema    = mongoose.Schema;

let ProductSchema = new Schema({
    mid                  : {type: String, required: false},
    merchantname         : {type: String, required: false},
    linkid               : {type: String, required: false},
    sku                  : {type: String, required: false},
    productname          : {type: String, required: false},
    category             : {
        primary             : { type: String, required: false },
        secondary           : { type: String, required: false },
    },  
    price                : {
        currency            : { type: String, required: false },
        amount              : { type: mongoose.Decimal128, required: false },
    },
    salePrice                : {
        currency            : { type: String, required: false },
        amount              : { type: mongoose.Decimal128, required: false },
    },
    upccode              : {type: String, required: false}, 
    description                : {
        short            : { type: String, required: false },
        long              : { type: String, required: false },
    },  
    keywords             : { type: String, required: false },
    linkurl              : [{ type: String, required: false }],    
    imageurl             : [{ type: String, required: false }], 
    active               : {type: Number, required: true, default: true}
},{ timestamps : true });

module.exports = mongoose.model('Product', ProductSchema);