"use strict"

const mongoose  = require('mongoose'),
      Schema    = mongoose.Schema;

let RetailerSchema = new Schema({
  referral_id          : {type: String, required: false},
  name                 : {type: String, required: true},
  analytics            : {type: String, required: false},
  active               : {type: Number, required: true, default: true}
},{ timestamps : true });

module.exports = mongoose.model('Retailer', RetailerSchema);

