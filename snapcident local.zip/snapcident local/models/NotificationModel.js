"use strict"

const mongoose  = require('mongoose'),
    Schema    = mongoose.Schema;

let NotificationSchema = new Schema({
    statement            : {type: String, required: true},
    options              : [{type: String, required: true}],
    active               : {type: Number, required: true, default: true},
    for_role_id          : {type: Number, required: true},
    event                : {type: String, required: false},
    user_status          : {type: String, required: false},

},{ timestamps : true });

module.exports = mongoose.model('Notification', NotificationSchema);