class brand_manager {

    constructor(wagner) {
    	this.Brands = wagner.get("Brands");
		this.LikeBrands = wagner.get("LikeBrands")
		this.DeviceId = wagner.get("DeviceId");
		this.MailHelper     = wagner.get('MailHelper')
    }

    find(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Brands  = await this.Brands.findOne(req);
		        resolve(Brands)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}

	insert(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Brands  = await this.Brands.create(req);
		        resolve(Brands)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

    async findAllPaginate(conds, sort, pageNumber, numberRecord){
	    return new Promise(async (resolve, reject)=>{
            try{
                let pipeLine = [
                    {
                        $match :  conds
                    },
                    {$sort: sort},
                    {
                        $facet : {
                            page: [{$count: "count"}],
                            Brands: [
                                
                                {$skip: pageNumber ? parseInt(numberRecord) * (pageNumber - 1):0 },
                                {$limit: parseInt(numberRecord)},
                            ]
                        }
                    },
                    {
                        $project: {
                            count: {$arrayElemAt: ["$page.count", 0]},
                            listing: "$Brands"
                        }
                    }
                ];
                let brands  = await this.Brands.aggregate(pipeLine);
                resolve({brands:brands[0].listing, page:Math.ceil(brands[0].count / parseInt(numberRecord))})
            } catch(error){
              console.log(error)  
              reject(error);
            }
        }) 
    }

    likeUnlike(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
                if(req.status == 1){  
		            let LikeBrands  = await this.LikeBrands.create(req);
		            resolve(LikeBrands)
                }else{
                    let UnlikeBrands  = await this.LikeBrands.deleteMany({user_id : req.user_id});
                    resolve(UnlikeBrands)
                }    
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

    findAllLikeBrands(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Brands  = await this.LikeBrands.find(req);
		        resolve(Brands)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}
}

module.exports  = brand_manager;    