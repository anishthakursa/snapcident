const bcrypt          = require('bcryptjs');
const config          = require('config');
let jwt         = require('jsonwebtoken');
const token_config  = config.get('JWT');
//const account_confirmation = require("../email_templates/account-confirmation.html")

class user_manager {

    constructor(wagner) {
    	this.User = wagner.get("User");
		this.Otp = wagner.get("Otp")
		this.DeviceId = wagner.get("DeviceId");
		this.MailHelper     = wagner.get('MailHelper')
		this.Notification =  wagner.get('Notification')
    }

	find(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let user  = await this.User.findOne(req);
		        resolve(user)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}

	insert(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let user  = await this.User.create(req);
		        resolve(user)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

	insertOtp(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Otp  = await this.Otp.create(req);
		        resolve(Otp)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

	deleteOtp(conds){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Otp  = await this.Otp.deleteMany(conds);
		        resolve(Otp)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

	insertDeviceToken(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let device_id  = await this.DeviceId.create(req);
		        resolve(device_id)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}
  
    update( conds, request){
	    return new Promise(async (resolve, reject)=>{
	      	try{
				  console.log("hiii");
				  console.log(conds)
				  console.log(request)
		        let user  = await this.User.findByIdAndUpdate(
		        	request,
					conds		        	
		        );
		        resolve(user)
	      	} catch(error){
	        	console.log(error);
	        	reject(error);
	        }
	    })
	}

	sendOtpMail(req,otp){
    	return new Promise(async (resolve, reject)=>{
		    try{
	          const mailOptions = {
	            from: config.get('email.MAIL_USERNAME'),
	            to: req.email,
	            subject: 'Verification Otp.',
	            //html: '<b>HI</b><br> <p>Greetings for the day.</p><br> <p>OTP '+otp+'</p> <br>Regards.<br> <p>Team '+config.get('APP_NAME')+'.</p>'
				html : '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Account Confirmation</title></head><body style="padding-top:10px; font-family: "DM Sans", sans-serif; margin:0;"><style>h1, h2, h3, h4, h5, h6, p{margin: 0;padding: 0;}.hello-sec{width: 600px;}.pp{padding: 0 10%;}@media screen and (max-width: 480px) {.hello-sec{width: 360PX;}.pp{padding: 0 5%;}}</style><table class="hello-sec" align="center"  cellspacing="0" cellpadding="0"><tr><td><table class="hello-sec" align="center" style="padding: 23px 0px; background: #FFFFFF; border-bottom: 1px solid #E0E0E0;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%;"><tr><td style="width: 100%; text-align: center;"><a href="#"><img src="./images/logo.png" width="190" /></a></td></tr></table></td></tr></table><table class="hello-sec" style="padding: 30px 0px 10px; background: #FBF8F5;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%; background: #FBF8F5;"><tr><td><h4 style="font-weight: 700;  font-size: 22px; line-height: 150%; color: #252323; text-align: center; font-family: "DM Sans", sans-serif;">Snapcident Account Confirmation</h4></td></tr></table><table class="hello-sec pp"    style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%; padding: 60px 0px 28px"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Hello '+req.name+',</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Welcome to Snapcident. We are thrilled to have you with us.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Use the code below to confirm your account:</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">'+otp+'</p></td></tr></table><table class="hello-sec pp" align="center" style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%;"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">You can reach out to us at: help@snapcident.com. For any further queries</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> related to your profile. We look forward to hearing from you.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">-- Team Snapcident</p></td></tr></table></td></tr><table class="hello-sec" align="center" style="background: #424242; height: 80px; margin-top: 60px;" cellspacing="0" cellpadding="0"><tr><td><p style="font-family: "DM Sans", sans-serif; font-weight: 500; line-height: 28px;font-size: 14px; color: #fff; text-align: center;">© Snapcident 2022</p></td></tr></table></table></body></html>'
	          };
			  
	          const sendMailfunc = await this.MailHelper.sendMailfunction(mailOptions);
	          resolve(sendMailfunc);

		    }catch(e){
		        console.log(e);
		        reject(e);
		    }
    	})
  	}

	forgetPassword(req){
    	return new Promise(async (resolve, reject)=>{
		    try{
	          const mailOptions = {
	            from: config.get('MAIL_USERNAME'),
	            to: req.email,
	            subject: 'Reset Password Link.',
	            html: '<b>HI</b><br> <p>Greetings for the day.</p><br> <p>Please click Reset Password to reset your password.</p>  <p><a href='+config.get('app_route')+'users/resetPassword/'+ req.id+' <button>Reset Password</button></a></p> <br>Regards.<br> <p>Team '+config.get('site_name')+'.</p>'
	          };
	          const sendMailfunc = await this.Mail.sendMail(mailOptions);
	          resolve(sendMailfunc);

		    }catch(e){
		        console.log(e);
		        reject(e);
		    }
    	})
  	}

	findOtp(req){
		return new Promise(async (resolve, reject)=>{
			try{
			  let user  = await this.Otp.findOne(req);
			  resolve(user)
			} catch(error){
			  reject(error);
		  	}
	  	})
	}  

	async findAllPaginate(conds, sort, pageNumber, numberRecord){
	    return new Promise(async (resolve, reject)=>{
            try{

                let pipeLine = [
                    {
                        $match :  conds
                    },
                    {$sort: sort},
                    {
                        $facet : {
                            page: [{$count: "count"}],
                            User: [
                                
                                {$skip: pageNumber ? parseInt(numberRecord) * (pageNumber - 1):0 },
                                {$limit: parseInt(numberRecord)},
                            ]
                        }
                    },
                    {
                        $project: {
                            count: {$arrayElemAt: ["$page.count", 0]},
                            listing: "$User"
                        }
                    }
                ];
                let user  = await this.User.aggregate(pipeLine);
                resolve({user:user[0].listing, page:Math.ceil(user[0].count / parseInt(numberRecord)), count:user[0].count})
            } catch(error){
              console.log(error)  
              reject(error);
            }
        }) 
    }

	findAll(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let users  = await this.User.find(req);
		        resolve(users)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}

	addNotification(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Notification  = await this.Notification.create(req);
		        resolve(Notification)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

	listNotification(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let notificationUser   = await this.Notification.find({for_role_id : 2});
				let notificationAdmin  = await this.Notification.find({for_role_id : 1});
		        resolve({notificationUser : notificationUser, notificationAdmin:notificationAdmin})
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}

	findNotification(req){
		return new Promise(async (resolve, reject)=>{
			try{
			  let notificationUser   = await this.Notification.findOne(req);
			  resolve(notificationUser)
			} catch(error){
			  reject(error);
		  }
	  })
	}

	updateNotification( conds, request){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let notification = await this.Notification.findByIdAndUpdate(
		        	request,
					conds		        	
		        );
		        resolve(notification)
	      	} catch(error){
	        	console.log(error);
	        	reject(error);
	        }
	    })
	}

	sendEmailAlert(req){
    	return new Promise(async (resolve, reject)=>{
		    try{
	          const mailOptions = {
	            from: config.get('email.MAIL_USERNAME'),
	            to: req.new_email,
	            cc : req.old_email,
	            subject: 'Email updated.',
	            //html: '<b>HI</b><br> <p>Greetings for the day.</p><br> <p>OTP '+otp+'</p> <br>Regards.<br> <p>Team '+config.get('APP_NAME')+'.</p>'
				html : '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Account Confirmation</title></head><body style="padding-top:10px; font-family: "DM Sans", sans-serif; margin:0;"><style>h1, h2, h3, h4, h5, h6, p{margin: 0;padding: 0;}.hello-sec{width: 600px;}.pp{padding: 0 10%;}@media screen and (max-width: 480px) {.hello-sec{width: 360PX;}.pp{padding: 0 5%;}}</style><table class="hello-sec" align="center"  cellspacing="0" cellpadding="0"><tr><td><table class="hello-sec" align="center" style="padding: 23px 0px; background: #FFFFFF; border-bottom: 1px solid #E0E0E0;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%;"><tr><td style="width: 100%; text-align: center;"><a href="#"><img src="./images/logo.png" width="190" /></a></td></tr></table></td></tr></table><table class="hello-sec" style="padding: 30px 0px 10px; background: #FBF8F5;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%; background: #FBF8F5;"><tr><td><h4 style="font-weight: 700;  font-size: 22px; line-height: 150%; color: #252323; text-align: center; font-family: "DM Sans", sans-serif;">Snapcident Account Confirmation</h4></td></tr></table><table class="hello-sec pp"    style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%; padding: 60px 0px 28px"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> Hello '+req.name+',</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Welcome to Snapcident. We are thrilled to have you with us.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Your email has been updated.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">previous email : '+req.old_email+'</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">new email : '+req.new_email+'</p></td></tr></table><table class="hello-sec pp" align="center" style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%;"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">You can reach out to us at: help@snapcident.com. For any further queries</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> related to your profile. We look forward to hearing from you.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">-- Team Snapcident</p></td></tr></table></td></tr><table class="hello-sec" align="center" style="background: #424242; height: 80px; margin-top: 60px;" cellspacing="0" cellpadding="0"><tr><td><p style="font-family: "DM Sans", sans-serif; font-weight: 500; line-height: 28px;font-size: 14px; color: #fff; text-align: center;">© Snapcident 2022</p></td></tr></table></table></body></html>'
	          };
			  
	          const sendMailfunc = await this.MailHelper.sendMailfunction(mailOptions);
	          resolve(sendMailfunc);

		    }catch(e){
		        console.log(e);
		        reject(e);
		    }
    	})
  	}

	sendStatusChangeAlert(req){
		return new Promise(async (resolve, reject)=>{
		    try{
	          const mailOptions = {
	            from: config.get('email.MAIL_USERNAME'),
	            to: req.email,
	            subject: req.title,
				html : '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Account Confirmation</title></head><body style="padding-top:10px; font-family: "DM Sans", sans-serif; margin:0;"><style>h1, h2, h3, h4, h5, h6, p{margin: 0;padding: 0;}.hello-sec{width: 600px;}.pp{padding: 0 10%;}@media screen and (max-width: 480px) {.hello-sec{width: 360PX;}.pp{padding: 0 5%;}}</style><table class="hello-sec" align="center"  cellspacing="0" cellpadding="0"><tr><td><table class="hello-sec" align="center" style="padding: 23px 0px; background: #FFFFFF; border-bottom: 1px solid #E0E0E0;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%;"><tr><td style="width: 100%; text-align: center;"><a href="#"><img src="./images/logo.png" width="190" /></a></td></tr></table></td></tr></table><table class="hello-sec" style="padding: 30px 0px 10px; background: #FBF8F5;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%; background: #FBF8F5;"><tr><td><h4 style="font-weight: 700;  font-size: 22px; line-height: 150%; color: #252323; text-align: center; font-family: "DM Sans", sans-serif;">'+req.title+'</h4></td></tr></table><table class="hello-sec pp"    style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%; padding: 60px 0px 28px"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> Hello '+req.name+',</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Welcome to Snapcident. We are thrilled to have you with us.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Your account status has been updated.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Current Status : '+req.status+'</p></td></tr></table><table class="hello-sec pp" align="center" style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%;"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">You can reach out to us at: help@snapcident.com. For any further queries</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> related to your profile. We look forward to hearing from you.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">-- Team Snapcident</p></td></tr></table></td></tr><table class="hello-sec" align="center" style="background: #424242; height: 80px; margin-top: 60px;" cellspacing="0" cellpadding="0"><tr><td><p style="font-family: "DM Sans", sans-serif; font-weight: 500; line-height: 28px;font-size: 14px; color: #fff; text-align: center;">© Snapcident 2022</p></td></tr></table></table></body></html>'
	          };
	          const sendMailfunc = await this.MailHelper.sendMailfunction(mailOptions);
	          resolve(sendMailfunc);
		    }catch(e){
		        console.log(e);
		        reject(e);
		    }
    	})
	}

	sendWelcomeAlert(req){
		return new Promise(async (resolve, reject)=>{
		    try{
	          const mailOptions = {
	            from: config.get('email.MAIL_USERNAME'),
	            to: req.email,
	            subject: "Welcome to Snapcident",
				html : '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Account Confirmation</title></head><body style="padding-top:10px; font-family: "DM Sans", sans-serif; margin:0;"><style>h1, h2, h3, h4, h5, h6, p{margin: 0;padding: 0;}.hello-sec{width: 600px;}.pp{padding: 0 10%;}@media screen and (max-width: 480px) {.hello-sec{width: 360PX;}.pp{padding: 0 5%;}}</style><table class="hello-sec" align="center"  cellspacing="0" cellpadding="0"><tr><td><table class="hello-sec" align="center" style="padding: 23px 0px; background: #FFFFFF; border-bottom: 1px solid #E0E0E0;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%;"><tr><td style="width: 100%; text-align: center;"><a href="#"><img src="./images/logo.png" width="190" /></a></td></tr></table></td></tr></table><table class="hello-sec" style="padding: 30px 0px 10px; background: #FBF8F5;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%; background: #FBF8F5;"><tr><td><h4 style="font-weight: 700;  font-size: 22px; line-height: 150%; color: #252323; text-align: center; font-family: "DM Sans", sans-serif;">Welcome to Snapcident</h4></td></tr></table><table class="hello-sec pp"    style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%; padding: 60px 0px 28px"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> Hello '+req.name+',</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Welcome to Snapcident. We are thrilled to have you with us.</p></td></tr></table><table class="hello-sec pp" align="center" style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%;"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">You can reach out to us at: help@snapcident.com. For any further queries</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> related to your profile. We look forward to hearing from you.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">-- Team Snapcident</p></td></tr></table></td></tr><table class="hello-sec" align="center" style="background: #424242; height: 80px; margin-top: 60px;" cellspacing="0" cellpadding="0"><tr><td><p style="font-family: "DM Sans", sans-serif; font-weight: 500; line-height: 28px;font-size: 14px; color: #fff; text-align: center;">© Snapcident 2022</p></td></tr></table></table></body></html>'
	          };
	          const sendMailfunc = await this.MailHelper.sendMailfunction(mailOptions);
	          resolve(sendMailfunc);
		    }catch(e){
		        console.log(e);
		        reject(e);
		    }
    	})
	}

	sendPasswordChangeAlert(req){
		return new Promise(async (resolve, reject)=>{
		    try{
	          const mailOptions = {
	            from: config.get('email.MAIL_USERNAME'),
	            to: req.email,
	            subject: req.title,
				html : '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Account Confirmation</title></head><body style="padding-top:10px; font-family: "DM Sans", sans-serif; margin:0;"><style>h1, h2, h3, h4, h5, h6, p{margin: 0;padding: 0;}.hello-sec{width: 600px;}.pp{padding: 0 10%;}@media screen and (max-width: 480px) {.hello-sec{width: 360PX;}.pp{padding: 0 5%;}}</style><table class="hello-sec" align="center"  cellspacing="0" cellpadding="0"><tr><td><table class="hello-sec" align="center" style="padding: 23px 0px; background: #FFFFFF; border-bottom: 1px solid #E0E0E0;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%;"><tr><td style="width: 100%; text-align: center;"><a href="#"><img src="./images/logo.png" width="190" /></a></td></tr></table></td></tr></table><table class="hello-sec" style="padding: 30px 0px 10px; background: #FBF8F5;" cellspacing="0" cellpadding="0" ><tr><td><table style="width: 100%; background: #FBF8F5;"><tr><td><h4 style="font-weight: 700;  font-size: 22px; line-height: 150%; color: #252323; text-align: center; font-family: "DM Sans", sans-serif;">'+req.title+'</h4></td></tr></table><table class="hello-sec pp"    style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%; padding: 60px 0px 28px"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> Hello '+req.name+',</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Welcome to Snapcident. We are thrilled to have you with us.</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">Your account password has been reset.</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">New password : '+req.password+'</p></td></tr></table><table class="hello-sec pp" align="center" style=" background: #FBF8F5;" cellspacing="0" cellpadding="0"><tr><td style="width: 100%;"><p style="font-weight: 400; line-height: 20px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">You can reach out to us at: help@snapcident.com. For any further queries</p><p style="font-weight: 400; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;"> related to your profile. We look forward to hearing from you.</p><p style="font-weight: 400;     margin-top: 18px; line-height: 21px; font-size: 14px; color: #252323; font-family: "DM Sans", sans-serif;">-- Team Snapcident</p></td></tr></table></td></tr><table class="hello-sec" align="center" style="background: #424242; height: 80px; margin-top: 60px;" cellspacing="0" cellpadding="0"><tr><td><p style="font-family: "DM Sans", sans-serif; font-weight: 500; line-height: 28px;font-size: 14px; color: #fff; text-align: center;">© Snapcident 2022</p></td></tr></table></table></body></html>'
	          };
	          const sendMailfunc = await this.MailHelper.sendMailfunction(mailOptions);
	          resolve(sendMailfunc);
		    }catch(e){
		        console.log(e);
		        reject(e);
		    }
    	})
	}

	getAuthUserData(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
				const usertoken = req.headers.authorization;
				const token = usertoken.split(' ');
				const decoded = jwt.verify(token[1], token_config.SECRET);
		        resolve(decoded);
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}
}

module.exports  = user_manager;