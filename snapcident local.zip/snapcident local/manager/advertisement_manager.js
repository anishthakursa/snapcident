class advertisement_manager {

    constructor(wagner) {
        this.Advertisement = wagner.get("Advertisement");
        this.MailHelper     = wagner.get('MailHelper')
    }

    find(req){
        return new Promise(async (resolve, reject)=>{
            try{
                let advertisement  = await this.Advertisement.findOne(req);
                resolve(advertisement)
            } catch(error){
                reject(error);
            }
        })
    }

    insert(req){
        return new Promise(async (resolve, reject)=>{
            try{
                let advertisement  = await this.Advertisement.create(req);
                resolve(advertisement)
            } catch(error){
                reject(error);
            }
        })
    }

    update( conds, request){
        return new Promise(async (resolve, reject)=>{
            try{
                let advertisement  = await this.Advertisement.findByIdAndUpdate(
                    request,
                    conds                   
                );
                resolve(advertisement)
            } catch(error){
                console.log(error);
                reject(error);
            }
        })
    }

     findAll(req,sort){
        return new Promise(async (resolve, reject)=>{
            try{
                let  advertisement = await this.Advertisement.find(req).sort(sort);
                resolve(advertisement)
            } catch(error){
                reject(error);
            }
        })
    }

    async findAllPaginate(conds, sort, pageNumber, numberRecord){
        return new Promise(async (resolve, reject)=>{
            try{
                let pipeLine = [
                    {
                        $match :  conds
                    },
                    {$sort: sort},
                    {
                        $facet : {
                            page: [{$count: "count"}],
                            Advertisement: [
                                
                                {$skip: pageNumber ? parseInt(numberRecord) * (pageNumber - 1):0 },
                                {$limit: parseInt(numberRecord)},
                            ]
                        }
                    },
                    {
                        $project: {
                            count: {$arrayElemAt: ["$page.count", 0]},
                            listing: "$Advertisement"
                        }
                    }
                ];
                let advertisement  = await this.Advertisement.aggregate(pipeLine);
                resolve({
                    advertisement:advertisement[0].listing, page:Math.ceil(advertisement[0].count / parseInt(numberRecord)), count : advertisement[0].count
                })
            } catch(error){
              console.log(error)  
              reject(error);
            }
        }) 
    }

   
}

module.exports  = advertisement_manager;    