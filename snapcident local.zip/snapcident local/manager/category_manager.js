class category_manager {

    constructor(wagner) {
    	this.Category = wagner.get("Category");
        this.LikeCategory = wagner.get("LikeCategory");
    }

    find(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Category  = await this.Category.findOne(req);
		        resolve(Category)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}

	insert(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Category  = await this.Category.create(req);
		        resolve(Category)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

    async findAllPaginate(conds, sort, pageNumber, numberRecord){
	    return new Promise(async (resolve, reject)=>{
            try{
                let pipeLine = [
                    {
                        $match :  conds
                    },
                    {$sort: sort},
                    {
                        $facet : {
                            page: [{$count: "count"}],
                            Category: [
                                
                                {$skip: pageNumber ? parseInt(numberRecord) * (pageNumber - 1):0 },
                                {$limit: parseInt(numberRecord)},
                            ]
                        }
                    },
                    {
                        $project: {
                            count: {$arrayElemAt: ["$page.count", 0]},
                            listing: "$Category"
                        }
                    }
                ];
                let category  = await this.Category.aggregate(pipeLine);
                resolve({category:category[0].listing, page:Math.ceil(category[0].count / parseInt(numberRecord))})
            } catch(error){
              console.log(error)  
              reject(error);
            }
        }) 
    }

    likeUnlike(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
                if(req.status == 1){  
		            let LikeCategory = await this.LikeCategory.create(req);
		            resolve(LikeCategory)
                }else{
                    let UnlikeCategory  = await this.LikeCategory.deleteMany({user_id : req.user_id});
                    resolve(UnlikeCategory)
                }    
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

    findAllLikeCategory(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let Category  = await this.LikeCategory.find(req);
		        resolve(Category)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}
}

module.exports  = category_manager;    