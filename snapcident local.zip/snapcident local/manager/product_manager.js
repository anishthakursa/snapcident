const bcrypt          = require('bcryptjs');
const config          = require('config')

class product_manager {
    constructor(wagner) {
    	this.Retailer = wagner.get("Retailer")
        this.Product = wagner.get("Product")
        this.Category = wagner.get("Category")
    }

    insert(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let product  = await this.Product.create(req);
		        resolve(product)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

    findOne(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let product  = await this.Product.findOne(req);
		        resolve(product)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}
 
	async findAllPaginate(conds, sort, pageNumber, numberRecord){
	    return new Promise(async (resolve, reject)=>{
            try{
                let pipeLine = [
                    {
                        $match :  conds
                    },
                    {$sort: sort},
                    {
                        $facet : {
                            page: [{$count: "count"}],
                            Product: [
                                
                                {$skip: pageNumber ? parseInt(numberRecord) * (pageNumber - 1):0 },
                                {$limit: parseInt(numberRecord)},
                            ]
                        }
                    },
                    {
                        $project: {
                            count: {$arrayElemAt: ["$page.count", 0]},
                            listing: "$Product"
                        }
                    }
                ];

                let products  = await this.Product.aggregate(pipeLine);
                resolve({products:products[0].listing, page:Math.ceil(products[0].count / parseInt(numberRecord)), count : products[0].count})
            } catch(error){
              console.log(error)  
              reject(error);
            }
        }) 
    } 
	
	update( conds, request){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let retailer  = await this.Retailer.findByIdAndUpdate(
		        	request,
					conds		        	
		        );
		        resolve(retailer)
	      	} catch(error){
	        	console.log(error);
	        	reject(error);
	        }
	    })
	}

    insertCategory(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let category  = await this.Category.create(req);
		        resolve(category)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

    findAllCategory(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let category  = await this.Category.find(req);
		        resolve(category)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}
}

module.exports  = product_manager;