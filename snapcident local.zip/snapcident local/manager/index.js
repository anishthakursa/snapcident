module.exports = function(wagner) {
   	wagner.factory('user_manager', function() {
    	var user_manager = require('./user_manager');
    	return new user_manager(wagner);
  	});

	wagner.factory('retailer_manager', function() {
    	var retailer_manager = require('./retailer_manager');
    	return new retailer_manager(wagner);
  	});
	  
	wagner.factory('brand_manager', function() {
    	var brand_manager = require('./brand_manager');
    	return new brand_manager(wagner);
  	});	  

	wagner.factory('category_manager', function() {
    	var category_manager = require('./category_manager');
    	return new category_manager(wagner);
  	});	 

  	wagner.factory('advertisement_manager', function() {
    	var advertisement_manager = require('./advertisement_manager');
    	return new advertisement_manager(wagner);
  	});	 

	  wagner.factory('product_manager', function() {
    	var product_manager = require('./product_manager');
    	return new product_manager(wagner);
  	});	
	
}

