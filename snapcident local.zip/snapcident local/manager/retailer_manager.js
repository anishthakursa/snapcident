const bcrypt          = require('bcryptjs');
const config          = require('config')

class retailer_manager {
    constructor(wagner) {
    	this.Retailer = wagner.get("Retailer")
        this.MailHelper     = wagner.get('MailHelper')
    }

    insert(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let retailer  = await this.Retailer.create(req);
		        resolve(retailer)
	      	} catch(error){
	      		reject(error);
	        }
	    })
	}

    find(req){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let retailer  = await this.Retailer.findOne(req);
		        resolve(retailer)
	      	} catch(error){
	        	reject(error);
	        }
	    })
	}

    sendLoginMail(req,pass){
    	return new Promise(async (resolve, reject)=>{
		    try{
	          const mailOptions = {
	            from: config.get('email.MAIL_USERNAME'),
	            to: req.email,
	            subject: 'Login details.',
	            html: '<b>HI</b><br> <p>Greetings for the day.</p><br> <p>Login Id '+req.email+'</p> <p>Password '+pass+'</p> <br>Regards.<br> <p>Team '+config.get('APP_NAME')+'.</p>'
	          };
			  
	          const sendMailfunc = await this.MailHelper.sendMailfunction(mailOptions);
	          resolve(sendMailfunc);

		    }catch(e){
		        console.log(e);
		        reject(e);
		    }
    	})
  	}
 
	async findAllPaginate(conds, sort, pageNumber, numberRecord){
	    return new Promise(async (resolve, reject)=>{
            try{

                let pipeLine = [
                    {
                        $match :  conds
                    },
                    {$sort: sort},
                    {
                        $facet : {
                            page: [{$count: "count"}],
                            User: [
                                
                                {$skip: pageNumber ? parseInt(numberRecord) * (pageNumber - 1):0 },
                                {$limit: parseInt(numberRecord)},
                            ]
                        }
                    },
                    {
                        $project: {
                            count: {$arrayElemAt: ["$page.count", 0]},
                            listing: "$User"
                        }
                    }
                ];
                let user  = await this.Retailer.aggregate(pipeLine);
                resolve({user:user[0].listing, page:Math.ceil(user[0].count / parseInt(numberRecord)), count : user[0].count})
            } catch(error){
              console.log(error)  
              reject(error);
            }
        }) 
    } 
	
	update( conds, request){
	    return new Promise(async (resolve, reject)=>{
	      	try{
		        let retailer  = await this.Retailer.findByIdAndUpdate(
		        	request,
					conds		        	
		        );
		        resolve(retailer)
	      	} catch(error){
	        	console.log(error);
	        	reject(error);
	        }
	    })
	}
}

module.exports  = retailer_manager;