const Project = require("../models/Project");

async function projectResult(project_id,milestone_id) {
    try {
      return await Project.findOne({ _id: project_id },{ 
        milestones: { $elemMatch: { _id: milestone_id } } })
        .populate("client_id")
        .populate("client_advocate_id")
        .populate("account_manager_id").exec();
    }catch(err){
      console.log(err)
    }
  }

  module.exports = projectResult;