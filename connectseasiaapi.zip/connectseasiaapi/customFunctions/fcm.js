var FCM = require('fcm-node');
var serverKey = 'AAAAxZkI5ZI:APA91bF6z75iqABQI7HM3FaXYp5KmbtLlVNrxtqfOw9WBH7HWkxHAKNpEjgWRdHL6zahYQmguXKwntDgF4s3UZ1TeSrFe8XmjJo8Hqf2IJ2dNvbsZfYde95jRuh7uPUeoIA6xr3n2eh0'; //put your server key here
var fcm = new FCM(serverKey);

function Notification(registrationToken, title, body ){
    var message = { 
        registration_ids: registrationToken,
        // to : 'dQxqt_tUHkD6njaJ1ga1uo:APA91bGBnSBH2orICkT-wvktPchhSg2bSGGpL2zdQZhHiY2WHz7OhEs7di_vyQWQcCj_nBHpbULXh0XxusXy5Swtn1UFUp7Ekb704AWmVi6PFCj5rOdQw7gZD_sROb7UpVknHuCv9io9',
        // collapse_key: 'your_collapse_key',
        // content_available : true,
        notification: {
            title: title, 
            body: body  
        },
        
        // data: {  //you can send only notification or only data(or include both)
        //     my_key: 'my value',
        //     my_another_key: 'my another value'
        // }
    };

    console.log(message);
    
    fcm.send(message, function(err, response){
        if (err) {
            console.log("Something has gone wrong!" + err);
        } else {
            console.log(registrationToken);
            console.log("Successfully sent with response: ", response);
        }
    });
}
module.exports = Notification;
