function deviceToken(project) {
    //Getting device Token from Project DB
    const clientToken = project.client_id.device_token;
    const clientAdvocateToken = project.client_advocate_id.device_token;
    const accountManagerToken = project.account_manager_id.device_token;
    //Moving Into Array
    var registrationToken = [];
    registrationToken.push(clientToken, clientAdvocateToken, accountManagerToken);
    return registrationToken;
  }

  module.exports = deviceToken;