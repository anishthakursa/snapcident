const nodemailer = require("nodemailer");
const hbs = require("nodemailer-express-handlebars");
const path = require("path");
const { google } = require("googleapis");

const OAuth2 = google.auth.OAuth2;

function sendMailer(to, subject, template, context) {
  try {
    const createTransporter = async () => {
      const oauth2Client = new OAuth2(
        process.env.OAUTH_CLIENTID,
        process.env.OAUTH_CLIENT_SECRET,
        "https://developers.google.com/oauthplayground"
      );
      oauth2Client.setCredentials({
        refresh_token: process.env.OAUTH_REFRESH_TOKEN,
      });

      const accessToken = await new Promise((resolve, reject) => {
        oauth2Client.getAccessToken((err, token) => {
          if (err) {
            console.log(err);
            reject("Failed to create access token :(");
          }
          resolve(token);
        });
      });
      console.log(accessToken);
      let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          type: "OAuth2",
          user: process.env.MAIL_USERNAME,
          accessToken,
          clientId: process.env.OAUTH_CLIENTID,
          clientSecret: process.env.OAUTH_CLIENT_SECRET,
          refreshToken: process.env.OAUTH_REFRESH_TOKEN,
        },
      });

      // Step 2, configuring template
      transporter.use(
        "compile",
        hbs({
          viewEngine: {
            extName: ".handlebars",
            partialsDir: path.resolve(__dirname, "../views"),
            defaultLayout: false,
          },
          viewPath: path.resolve(__dirname, "../views"),
          extName: ".handlebars",
        })
      );

      return transporter;
    };

    const sendEmail = async (emailOptions) => {
      let emailTransporter = await createTransporter();
      await emailTransporter.sendMail(emailOptions);
    };

    sendEmail({
      from: process.env.MAIL_USERNAME,
      to: to,
      subject: subject,
      template: template,
      context: context,
    })
      .then((data) => {
        console.log("Email Sent Sucessfully");
      })
      .catch((err) => {
        console.log("Error: ", err);
      });
  } catch (err) {
    console.log("Mail Failed", err);
  }
}

module.exports = sendMailer;
