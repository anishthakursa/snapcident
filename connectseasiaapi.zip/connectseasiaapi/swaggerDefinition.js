const swaggerDefinition = {
  openapi: "3.0.0",
  info: {
    title: "Seasia Connect - APIs",
    description: "These are seasia connect APIs.",
    contact: {
      name: "Seasia Infotech",
    },
    version: "1.0.0",
  },
  tags: [
    {
      name: "Admin",
    },
  ],
  paths: {
    "/api/v1/login": {
      post: {
        tags: ["Admin"],
        description: "Admin login",
        operationId: "adminLogin",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["email", "password"],
                properties: {
                  email: {
                    type: "string",
                    description: "Email Address of the Admin",
                  },
                  password: {
                    type: "string",
                    description: "Password of the Admin",
                  },
                },
              },
            },
          },
        },
        responses: {
          200: {
            description: "Success",
          },
          401: {
            description: "Error",
          },
        },
      },
    },
  },
  components: {
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
      },
    },
  },
  security: [
    {
      bearerAuth: [],
    },
  ],
};

module.exports = swaggerDefinition;
