const mongoose = require("mongoose");
const Schema = mongoose.Schema

const activitySchema = new Schema({
    activityType: { type: String, required: true }, //ex: Milestone_Added
    createdById: { type: Schema.Types.ObjectId},
    modelNameOfcreatedById:{
            type: Schema.Types.String, required: true
        },
        activityTitle : { 
            type : String
        },
    // projectId: { type: Schema.Types.ObjectId, ref: "projects"},
    milestoneId: { type: Schema.Types.ObjectId, ref: "projects"} 
    // , seen : {}
}, { timestamps: true })

module.exports = mongoose.model('Activity', activitySchema)