const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Client = mongoose.Schema(
  {
    first_name: {
      type: String,
      required: [true, "Please provide First name"],
    },
    last_name: {
      type: String,
      required: [true, "Please provide Last Name"],
    },
    email_id: {
      type: String,
      required: [true, "Please provide Email"],
    },
    password: {
      type: String,
    },
    password_status: {
      type: String,
    },
    mobile_no: {
      type: String,
    },
    skype_id: {
      type: String,
    },
    other_contact: {
      type: String,
    },
    address_l1: {
      type: String,
    },
    address_l2: {
      type: String,
    },
    country: {
      type: String,
      required: [true, "Please provide country"],
    },
    state: {
      type: String,
      required: [true, "Please provide State"],
    },
    city: {
      type: String,
      required: [true, "Please provide City"],
    },
    pincode: {
      type: String,
      required: [true, "Please provide Pincode"],
    },
    delete_client: {
      type: String,
      default: "N",
    },
    device_token: {
            type: String
          },
          device_type: {
            type: String
          }

    //Tokens for FCM
    // device_tokens: [
    //   {
    //     device_token: {
    //       type: String,
    //     },

    //     device_type: {
    //       type: String,
    //     },
    //   },
    // ],
  },
  {
    timestamps: true,
  }
);

Client.methods.generateAuthToken = async function () {
  const client = this;
  const token = jwt.sign(
    { _id: client._id, email_id: client.email_id },
    "saha_token_2055",
    { expiresIn: "1d" }
  );
  return token;
};

Client.statics.findByCredential = async (email, password) => {
  const client = await clients.findOne({ email_id: email });

  if (!client) {
    throw new Error("AAA");
  }

  const isMatch = await bcrypt.compare(password, client.password);
  if (!isMatch) {
    throw new Error("AAA");
  }

  return client;
};

const clients = mongoose.model("clients", Client);
module.exports = clients;
