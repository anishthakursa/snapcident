const mongoose= require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const Admin=mongoose.Schema({
   
    email:{
        type:String,
        required:[true,'Please provide Email'],
       
    },
    password:{
        type:String,
        required:[true,'Please provide password']
    }
    

   
});


Admin.methods.generateAuthToken = async function () {
    const admin =this;
    const token = await jwt.sign({_id:admin._id,email:admin.email},'saha_token_2055',{ expiresIn: '1d'})
   // user.tokens=user.tokens.concat({token:token});
   // await user.save();
    return token;
}

Admin.statics.findByCredential= async (email,password)=>{
    
    const admin = await admins.findOne({email})
   

         if (!admin) {
             console.log('no admin');
             throw new Error('AAA')
         }
         
         const isMatch = await bcrypt.compare(password,admin.password);
         if(!isMatch){
             console.log('no pass');
             throw new Error('AAA')
         }

         return admin;

    
}


const admins= mongoose.model('admins',Admin);
module.exports=admins;