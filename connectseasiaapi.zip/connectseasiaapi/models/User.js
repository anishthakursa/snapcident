const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = mongoose.Schema(
  {
    first_name: {
      type: String,
      required: [true, "Please provide First name"],
    },
    last_name: {
      type: String,
      required: [true, "Please provide Last Name"],
    },
    employee_id: {
      type: String,
      unique: true,
      required: [true, "Please provide Employee ID"],
    },
    email_id: {
      type: String,
      required: [true, "Please provide Email"],
    },
    password: {
      type: String,
    },
    password_status: {
      type: String,
    },
    skype_id: {
      type: String,
    },
    mobile_no: {
      type: String,
      required: [true, "Please provide Mobile No"],
    },
    other_contact: {
      type: String,
    },
    designation: {
      type: String,
      required: [true, "Please provide Designation"],
    },
    report_to_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "users",
    },
    delete_user: {
      type: String,
      default: "N",
    },
    device_token: {
      type: String
    },
    device_type: {
      type: String
    }
  },
  {
    timestamps: true,
    // toObject: { virtuals: true },
    // toJSON: { virtuals: true }
  }
);

User.methods.generateAuthToken = async function () {
  const user = this;
  const token = jwt.sign(
    { _id: user._id, email_id: user.email_id },
    "saha_token_2055",
    { expiresIn: "1d" }
  );
  return token;
};

User.statics.findByCredential = async (email, password) => {
  const user = await users.findOne({ email_id: email });

  if (!user) {
    throw new Error("AAA");
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    throw new Error("AAA");
  }

  return user;
};

const users = mongoose.model("users", User);
module.exports = users;
