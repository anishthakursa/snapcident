const express = require('express');
const bodyParser = require('body-parser');
country_codes=['91-', 'UK-44-', 'SZ-268-22']
phone="91-12345678901111";
Stripe = require('stripe');

var SalesTax = require("sales-tax");
var nodemailer = require('nodemailer');
config = require('config');

 var stripe=Stripe("sk_test_51IpRSZSIveowwQcHpkqN1PmKtO10jHDqANeDNJwCJMijbewqQYUP0htj2Zhu0Xdi8YSjxjV0ASLEEplN8JgeMjxd00pJC4aqkA")


 const accounts =  stripe.accounts.list({
   limit: 3,
 }).then(data=>{//console.log(">>>>",data)
});


// const charge =  stripe.charges.create({
//   amount: 1500,
//   currency: "inr",
//   source: "acct_1K3dUNSAlv8QV8OI"
// }).then(data=>{console.log("data",data)}).catch(err=>{console.log("err",err)});

async function abc(){

  const refund = await stripe.refunds.create({
    payment_intent: "pi_3K3wodSIveowwQcH1yn4jWdx",
    amount:500,
    reverse_transfer: true,
    // refund_application_fee: true,


  })




console.log(refund)


// const transfer =  await stripe.transfers.create({
//     amount: 7000,
//     currency: 'inr',
//     destination: 'acct_1K3dUNSAlv8QV8OI',
//     transfer_group: '{ORDER10}',
//   });


  //console.log(transfer)
}

abc();
// Create a Transfer to the connected account (later):
// const transfer =  stripe.transfers.create({
//   amount: 7000,
//   currency: 'inr',
//   destination: 'acct_1K3dUNSAlv8QV8OI',
//   transfer_group: '{ORDER10}',
// });

// Create a second Transfer to another connected account (later):
// const secondTransfer =  stripe.transfers.create({
//   amount: 2000,
//   currency: 'inr',
//   destination: 'acct_1K3dUNSAlv8QV8OI',
//   transfer_group: '{ORDER10}',
// });



// const paymentIntent =  stripe.paymentIntents.create({
//   amount: 5000,
//   currency: "INR",
//   metadata: {
//         order_id: '6735',
//       },
//       customer:"cus_JeQKqCDJnEJRHy",
//       application_fee_amount: 1000,
//       transfer_data: {
//         destination: 'acct_1K3dUNSAlv8QV8OI',
//       },
//   payment_method_types: ['card'],
//    payment_method: "pm_1J17VZSIveowwQcHGDyzZq5v",


// }).then(data=>{
 






//   const paymentIntent =  stripe.paymentIntents.confirm(
//     data.id,
//     {payment_method: 'pm_1J17VZSIveowwQcHGDyzZq5v'}
//   );




// }).catch(err=>{console.log("Error",err)});




// const paymentIntent =  stripe.paymentIntents.create({
//   payment_method_types: ['card'],
//   amount: 1000,
//   currency: 'inr',
//   // automatic_payment_methods: {
//   //   enabled: true,
//   // },
//   payment_method: "pm_1IdYbD2eZvKYlo2CbVMyipoM",
//   metadata: {
//     order_id: '6735',
//   },
//   application_fee_amount: 123,
//   transfer_data: {
//     destination: 'acct_1K3dUNSAlv8QV8OI',
//   },
// }).then(data=>{console.log("data",data)}).catch(err=>{console.log(err)});





//var autoassignment1 = require('./controllers/api/orders.controller')


//  setTimeout(function(){
//   // initiateAutoAssignment(cOrderData.dataValues.id,cOrderData.dataValues.companyId)
  //autoassignment1.updateUserType("0176c99c-dfc6-4ada-b5dd-5bf316de2a71","89624900-a974-4849-9048-c32d6bed220a")
// }, (3*1000));

//Noide Mailer
transporter = nodemailer.createTransport({
  service: 'SendGrid',
  auth: {
      user: 'apikey', 
      pass: config.EMAIL_KEY
  }
});


var mailOptions = {
  from: "sales@cerebruminfotech.com",
  to: ["erraghavgoyal94@gmail.com"],
  subject: "Testing",
  html:`<div style="padding: 40px 10px;">
  <p>Hi '. ucwords(strtolower($name)).',</p><br>
  <p>Thank you for contacting Cerebrum and showing your interest in our products. We have successfully received your request and will get back to you soon. </p>
  <p>Mean while, you can go through <a href="'">Our Blog</a> section to explore more on our technology innovations.</p></br>
  <p>Warm Regards,</p>
  <p>Cerebrum Customer Support</p>
  <p>For instant contact:</p>
  <p>Phone:  <a href="tel: +1 (240) 241-68-94" class="crbm-phone-footer"> +1 (240) 241-68-94</a></p>
  <p>Email:<a href="mailto:sales@cerebruminfotech.com"> sales@cerebruminfotech.com </a> | </p>
</div>`
};
var countryTelData = require('country-telephone-data')
var countries=countryTelData.allCountries







let obj = countries.find(o => o.dialCode === '91');

console.log(obj)


if(obj)
{
var cc = require('iso-country-currency');
console.log(">>>",cc.getAllInfoByISO(obj.iso2))

}


// transporter.sendMail(mailOptions, function(error, info){

//   if(info)
//   {
//     console.log("MAil SENd>>>>>>>>>>>>")
//   }
//   if (error) {
//       console.log(error);
//       } 
//   });


// var validator = require('gstin-validator');
//   validator.isValidGSTNumber('12AAACI1681G1Z0');
//   validator.ValidateGSTIN('47AAACI1681G1Z0');
//   validator.getGSTINInfo('12AAACI1681G1Z0');
//   validator.validateSignedInvoice('SignedInvoiceString');
//   validator.validateEInvoiceSignedQR('SignedQROfEInvoice');


// SalesTax.validateTaxNumber("IN", "03AABCU9603R1ZX")
//   .then((isValid) => {
// console.log("VALID............",isValid)  });



// SalesTax.getSalesTax("IN", null, "03AABCU9603R1ZX")
//   .then((tax) => {

//     console.log(tax)
//     // This customer is VAT-exempt (as it is a business)
//     /* tax ===
//       {
//         type     : "vat",
//         rate     : 0.00,
//         area     : "worldwide",
//         exchange : "business",

//         charge   : {
//           direct  : false,
//           reverse : true
//         },

//         details  : []
//       }
//      */
//   });

// var stripe=Stripe("sk_test_51IpRSZSIveowwQcHpkqN1PmKtO10jHDqANeDNJwCJMijbewqQYUP0htj2Zhu0Xdi8YSjxjV0ASLEEplN8JgeMjxd00pJC4aqkA")

// function isInRange(value, range) {
//   return value >= range[0] && value <= range[1];
// }
// var range = ['05:00 PM','11:00 PM'];
// ['04:59 AM','08:30 PM','10:15 PM'].forEach(function(time) {
//   console.log(time + ' is ' + (isInRange(time, range)? ' ':'not ') + 'in range');
// });

// var stringTest=""

// console.log(">>>>>>>>>>>>>>>>>>", (/^\s*$/.test(stringTest)))


// //Pay to your user

// // const transfer = await stripe.transfers.create({
// //     amount: 1000,
// //     currency: "usd",
// //     destination: "{{CONNECTED_STRIPE_ACCOUNT_ID}}",
// //   });



// // const account =  stripe.accounts.create({
// //     type: 'express',
// //   }).then(async response=>{
// //     console.log(response)

// //   });


// const token =  stripe.tokens.create({
//     bank_account: {
//       country: 'IN',
//       currency: 'INR',
//       account_holder_name: "Saira",
//       account_holder_type: 'individual',
//       account_number: "000123456789",
//       routing_number: "091000022",

//     },
//   }).then(async response=>
    

//     {

// console.log("===========>",response)






// const accountLinks = await stripe.accounts.createExternalAccount(
//     'acct_1IqHHbSBj2aot01Z',

//     {external_account: response.id}
//   ).then(acRes=>{
//     console.log("................",acRes)


//   }).catch(ero=>{
//     console.log("................",ero)


//   });



//     }).catch(err=>console.log(err.message));