const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
 db = require('./db/db');
 var nodemailer = require('nodemailer');
 const fs = require('fs');
 pointInPolygon = require('point-in-polygon');


  https = require("https");
  var priPath = path.join('/var/www/html/SSL/groceriesking.key');
  var certPath = path.join('/var/www/html/SSL/groceriesking.crt');
  console.log("===cert pth==", priPath,certPath)
   const privateKey = fs.readFileSync(priPath, 'utf8'); //privkey.pem
   const certificate = fs.readFileSync(certPath, 'utf8'); //cert.pem
   const options = {
     key: privateKey,
     cert: certificate
   };
  const server = https.createServer(options, app);




//const server = require('http').createServer(app);
config = require('config');
 Stripe = require('stripe');

 io = require('socket.io')(server);
const socket = require('./socket')(io);
var cookieParser  = require('cookie-parser');
var flash         = require('connect-flash');
 tc = require("time-slots-generator");

 middleware         = require("./middleware/auth");

checkAuth         = middleware.userAuth
mainAuth          = middleware.mainAuth
adminAuth         = middleware.adminAuth
superAuth         = middleware.superAuth
actionActivity         = middleware.actionActivity

restAuth          = middleware.restAuth
 webpush = require("web-push");
 sequelize = require('sequelize')
 adminRole =1
const routes = require('./routes/routes');
const checkConn = require('./helpers/checkConn');
const fileUpload = require('express-fileupload');
commonMethods=require('./controllers/api/common/common')
appstrings=require('./language/strings.json')['en']
const cors = require('cors');
const session     = require('express-session');
adminpath="/api/company/"
adminfilepath="admin/"

superadminpath="/api/admin/"
superadminfilepath="super/"


mainpath="/api/main/"
mainfilepath="mainAdmin/"



//Noide Mailer
transporter = nodemailer.createTransport({
  service: 'SendGrid',
  auth: {
      user: 'apikey', 
      pass: config.EMAIL_KEY
  }
});




//Email Integartions 
      var SibApiV3Sdk = require('sib-api-v3-sdk');
    var defaultClient = SibApiV3Sdk.ApiClient.instance;
    var apiKey = defaultClient.authentications['api-key'];
    apiKey.apiKey = config.EMAIL_KEY;
     apiInstance = new SibApiV3Sdk.TransactionalEmailsApi();
     sendSmtpEmail = new SibApiV3Sdk.SendSmtpEmail





CURRENCY="Rs"
responseHelper = require("./helpers/responseHelper");
common = require('./helpers/common');

const port = config.PORT || 9066;


app.use(cookieParser());
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(flash());

var dt = new Date().getTime();
var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
  var r = (dt + Math.random()*16)%16 | 0;
  dt = Math.floor(dt/16);
  return (c=='x' ? r :(r&0x3|0x8)).toString(16);
});

app.use(session(
  { secret: config.APP_NAME,
    resave: true,
    saveUninitialized: true,name: uuid}));

app.use((req, res, next) => {
  if (req.session) {
    res.locals.successMessage = req.flash("successMessage");
    res.locals.errorMessage = req.flash("errorMessage");
    res.locals.messages = req.session.messages;
    res.locals.userData = req.session.userData;
    res.locals.userData1 = req.session.userData1;
    res.locals.userDataMain = req.session.userDataMain;

    //res.locals.userId = req.session.userId;
    req.session.messages = {};

  }
  next();
});


//for webpush



app.use(cors());
/*
Increase Upload File Size
*/
app.use(bodyParser.json({
  limit: '50mb'
}));
app.use(fileUpload({ limit: '50mb' }));
app.use(bodyParser.urlencoded({
  extended: true,
  limit: '50mb'
}));

//for service worker
app.get("/worker", (req, res) => {
  res.sendFile(path.resolve(__dirname, "public", "worker.js"));
});
app.use('/api', routes);
/*
Serve Static Folder
*/
app.use('/', express.static(path.join(__dirname, '/public')));
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
 
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));


app.use('', async(req, res) => {

    var params=req.query
    var features=[]
    var compData={}
    var companyId=""
    var dataDoc={}
    var faqs=[]
    var tags=[]
    
   
    
     dataDoc=await DOCUMENT.findOne({where:{companyId:config.STATIC_ADMIN_ID}})
     
     compData=await COMPANY.findOne({where:{id:config.STATIC_ADMIN_ID}})
    
    
     faqs=await FAQ.findAll({where:{companyId:config.STATIC_ADMIN_ID,status:1}})
     tags=await TAGS.findAll({where:{companyId:config.STATIC_ADMIN_ID,status:1}})
    
    
    
    
     features=await FEATURES.findAll({where:{companyId:config.STATIC_ADMIN_ID}})
     
    
    var dataSend={}
    dataSend.dataDoc=dataDoc
    dataSend.compData=compData
    
    dataSend.features=features
    dataSend.companyId=config.STATIC_ADMIN_ID
    dataSend.faq=faqs
    dataSend.tags=tags
    
    
    
    return res.render('terms.ejs',{data:dataSend})
    
});



// app.get('/test',thisFunction)

app.get('*', function(req, res) {
  return res.render('admin/partials/norecord.ejs');
});




/*
Check Db connection
*/
const healthCheck = async () => {
  await checkConn.checkDbConnection();
};

/*
Start Server
*/
server.listen(port, async () => {
  await healthCheck();

  console.log(`Listening on port ${port}`);
});





//commonMethods.cretaeMainCategory();
commonMethods.generateOrderStatus();
commonMethods.generateRoles();
// commonMethods.generateUserRoles();

//commonMethods.sendRefundEmail("04620631-3698-467a-8c38-edc7acb22d05","sairaansari.12j@gmail.com")

//const vapidKeys = webpush.generateVAPIDKeys();
webpush.setVapidDetails(
  'mail:cereKart@ydomain.org',
  config.VAPID_PUBLIC_KEY,
  config.VAPID_PRIVATE_KEY
);

db.query("SET GLOBAL sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''))");


// var autoassignment = require('./controllers/dashboard/autoassign')

//Tedting 
