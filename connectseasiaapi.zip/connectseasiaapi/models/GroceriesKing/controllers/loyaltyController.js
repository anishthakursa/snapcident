const model = require("../models/index");
const sequelize = model.sequelize;
const helpers = require("../helpers");
const { Op } = require('sequelize');

module.exports = {
    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// Convert Points to Token   /////////////////////
    //////////////////////////////////////////////////////////////////////////////// 
        
    convertPoints: async function(req, res) {
        try {
            var userdetails = await userDetail.findOne({
                where :{
                    userId: req.id
                }
            })
            //let user = await getBalance(req.id)
            //var document= await DOCUMENT.findOne({where:{ companyId:req.parentCompany }})
            let conversionRate = 2;
            var lpBalance      = parseInt(userdetails.dataValues.lPoints)
            var walletValue    = conversionRate*(lpBalance)
            var maximumValue   = 50;
            if(lpBalance>=maximumValue)
            {
                var wallet={}
                wallet.wallet = walletValue
                var walletBalance=userdetails.dataValues.rememberToken
                walletBalance=parseFloat(walletBalance)+parseFloat(walletValue)
                if(parseInt(walletValue)>0)
                {  
                    await userDetail.update( {rememberToken: walletBalance,lPoints:0},{ where: { userId: req.id} })
                    await userTokenHistory.create({
                        senderId: req.id,
                        receiverId: req.id,
                        token : walletValue,
                        type: "Redeem from loyalty points",
                        tokenBalance: walletBalance,
                        status: 1,
                        createdAt: Math.floor(new Date().getTime() / 1000)

                    });
                }
                return helpers.jsonResponse(res,true,{},appstrings.success, 200, 200);
            }
            else{
                return helpers.jsonResponse(res,false,{},appstrings.invalid_balance, 404, 404);
            }
            
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    ////////////////////////////////////////////////////////////////
    ///////////////////////// Points History ///////////////////////
    ////////////////////////////////////////////////////////////////
    pointsHistory: async function(req, res){
        try {
            var userdetails = await userDetail.findOne({
                where :{
                    userId: req.id
                }
            })
           // var document= await DOCUMENT.findOne({where:{ companyId:req.parentCompany }})
            var lpTransactions = await ponitsHistory.findAll({
                attributes: ['userId','points','paytype','purpose','description','createdAt',['createdAt' , 'earnedOn']],
                                       where:{ 
                        userId: req.id,
                       points:{
                        [Op.not]:[0,0.0,0.00]
                        }
                    },
                    include:[
                    {
                        model:userDetail, 
                        required:false,
                        attributes: ['fName','lName','image'], 
                    },
                ],
                order:[['createdAt','DESC']]
            });


            // var  walletTransactions = await USERWALLET.findAll({
            //     where:{ userId: req.id,
            //     amount:{[Op.not]:[0,0.0,0.00]},

            //     },
            //     attributes: ['userId','amount','paytype','purpose','createdAt'],
            //     include:[{
            //     required:false,
            //     model:ORDERS,attributes: ['id','orderNo'],
            //     include:[{
            //     model:COMPANY,attributes: ['companyName',['logo1','brandlogo']],
            //     }]
            //     },

            //     ],
            //     order:[['createdAt','DESC']]

            // })

            var resultset             = {};
            resultset.walletBalance   = parseFloat( userdetails.dataValues.rememberToken ).toFixed(2);
            resultset.lpMaximumWallet = 50;
            resultset.lPBalance       = userdetails.dataValues.lPoints;
            resultset.lpHistory       = lpTransactions;
            resultset.walletHistory   = [];

            if(lpTransactions.length > 0)
            {
                return helpers.jsonResponse(res,true,resultset,appstrings.success, 200, 200);
            }else{
                return helpers.jsonResponse(res,false,resultset,appstrings.success, 200, 200);
            }
            
            
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    }
};
