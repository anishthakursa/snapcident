
const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model = require("../models/index");
const jwt            = require('jsonwebtoken');
const helpers = require("../helpers");
const hashPassword   = require('../helpers/hashPassword');
const responseHelper = require("../helpers/responseHelper");
const common         = require('../helpers/common');
const moment   = require('moment');

COUPAN.hasOne(SHORTLISTEDCOUPONS,{foreignKey:'coupanId',sourceKey:'id'})
SHORTLISTEDCOUPONS.belongsTo(COUPAN,{foreignKey:'coupanId',targetKey:'id'})

module.exports = {

  /**
  *@role Get Coupon List
  *@Method GET
  */
  list: async (req, res, next) => {
    try {
      const data    = req.body;
      var newDate = moment(new Date()).format("YYYY-MM-DD");
	var userData = await teacherSubject.findOne({
        where: {
          teacherId: data.userId
       }
      })
      var shortlistedCouponData = await SHORTLISTEDCOUPONS.findAll({
        where :{
            userId : data.userId,
    	    status : 1
          },
          include: [{
            model: COUPAN,
            where: {
              validupto: {
                      [Op.gte] : newDate
                    },
                    subjectId : userData.subjectId, 
            },
      }]
    });
      console.log(shortlistedCouponData ,"/n")
      // var orderData = await COUPAN.findAll({
      //   attributes: ['id','name','code','discount','description','icon','thumbnail','minimumAmount','validupto'],
      //   order: [
      //     ['createdAt', 'DESC'],  
      //   ],
      //   where :{
      //     validupto: {
      //       [Op.gte] : newDate
      //     },
      //     companyId: req.parentCompany,
		  //     status:1
      //   }
      // });
      return helpers.jsonResponse(
        res,
        true,
        shortlistedCouponData,
        "Success",
        200,
        200
      );
    } catch (e) {
      console.log(e)
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

    /**
  *@role Get Coupon List
  *@Method GET
  */
  listForProfessionals: async (req, res, next) => {
    try {
      const data = req.body;
      var orderData = '';
      var newDate = moment(new Date()).format("YYYY-MM-DD");
      var userData = await teacherSubject.findOne({
        where: {
          teacherId: data.userId
       }
      })
      if(userData){
      var orderData = await COUPAN.findAll({
        attributes: ['id','name','code','discount','description','icon','thumbnail','minimumAmount','validupto'],
        order: [
          ['createdAt', 'DESC'],  
        ],
        where :{
          validupto: {
            [Op.gte] : newDate ,
          },
          subjectId : userData.subjectId,
          companyId: req.parentCompany,
		      status:1
        },
        include: [{
          model: SHORTLISTEDCOUPONS,
	where:{userId:data.userId}, required:false
       }],
       group:['id']
      });
      return helpers.jsonResponse(
        res,
        true,
        orderData,
        "Success",
        200,
        200
      );     
    }

    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },


  /*
  *@role Apply Coupon
  *@Method POST
  */
  applyCoupon: async (req, res, next) => {
    try{
      const data    = req.body;
      //Get Coupan Details
      const coupanDetails = await COUPAN.findOne({
       attributes: ['id','code','discount','type','minimumAmount'],
        where: {
          code: data.couponCode
        }
      });
      if(coupanDetails)
      {

        //
        // const userCoupon = await userCoupons.findOne({
        //   where: {
        //     couponId: coupanDetails.dataValues.id,
        //     userId: data.userId,
        //     applied: {
        //       [Op.gte]: '2' 
        //     }
        //   }
        // })

        // if(userCoupon)
        // {
        //   return res.json({
        //     code: 302,
        //     message: 'Sorry! You have already applied two times this coupon.'
        //   })
        // }

        // const checkCoupon = await userCoupons.findOne({
        //   where: {
        //     couponId: coupanDetails.dataValues.id,
        //     userId: data.userId
        //   }
        // })
        // if(checkCoupon)
        // {

        //   if(checkCoupon.dataValues.applied == '1')
        //   {
        //      if(parseInt(data.bookingcount) >= '2')
        //      {
        //         return res.json({
        //           code: 302,
        //           message: 'Sorry! This coupon is valid only two times bookings. You have already applied one time.'
        //         })
        //      }
        //   }
        //   const userUpdate = await userCoupons.update({
        //     applied: sequelize.literal('applied + ' + data.bookingcount)
        //   }, {
        //     where: {
        //       couponId: coupanDetails.dataValues.id,
        //       userId: data.userId
        //     }
        //   })
        // }
        // else
        // {
        //   const usr = await userCoupons.create({
        //     couponId: coupanDetails.dataValues.id,
        //     userId: data.userId,
        //     applied: data.bookingcount
        //   });
        // }

        var minimumAmount=coupanDetails.dataValues.minimumAmount?coupanDetails.dataValues.minimumAmount:0
        var totalPrice=data.credit?data.credit:0
        if(minimumAmount && parseFloat(totalPrice)<parseFloat(minimumAmount))
        {
          return responseHelper.post(res, appstrings.minimum_limit,null,400);
  
        }






        var price = parseInt(data.credit);
         let discount_price   = parseFloat((coupanDetails.dataValues.discount*price)/100);
        //let discount_price = (price/100)*per;        // Get Percentage Amount
        var payableAmount  = price - discount_price;  //Payable Amount
        //payableAmount  = payableAmount;

        var coupanDetailsnew = {};
        coupanDetailsnew.totalCredit     = price;
        coupanDetailsnew.payableCredit   = payableAmount;
        coupanDetailsnew.discountCredit  = discount_price;
        coupanDetailsnew.couponId        = coupanDetails.dataValues.id;
        coupanDetailsnew.couponCode        = data.couponCode;
        return helpers.jsonResponse(
          res,
          true,
          coupanDetailsnew,
          "Coupon applied successfully",
          200,
          200
        );
      }
      else
      {
        return helpers.jsonResponse(
          res,
          true,
          {},
          "Invalid Coupon",
          400,
          400
        );
       
      }
    }
    catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },


  /*
  *@role Remove Coupon
  *@Method POST
  */
  removeCoupan: async (req, res, next) => {
    try{
      const data    = req.body;
      //Get Coupan Details
      const coupanDetails = await COUPAN.findOne({
       attributes: ['id','code','discount'],
        where: {
          code: data.couponCode
        }
      });
      if(coupanDetails)
      {
        // const userUpdate = await userCoupons.update({
        //   applied: '0'
        // }, {
        //   where: {
        //     couponId: coupanDetails.dataValues.id,
        //     userId: req.id
        //   }
        // })
         return helpers.jsonResponse(
          res,
          true,
          {},
          "Coupon removed successfully",
          200,
          200
        );
      }
      else
      {
        return helpers.jsonResponse(
          res,
          true,
          {},
          "Invalid Coupon",
          400,
          400
        );
      }
    }
    catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  shortlistCoupons : async(req, res, next) => {
    try{
      const data  = req.body;
      var checkshortlistedCoupon =  await SHORTLISTEDCOUPONS.findOne({
        where: {
          userId: data.userId,
          coupanId: data.coupanId,
        },
      });

      if(!checkshortlistedCoupon){
        await SHORTLISTEDCOUPONS.create({
          userId: data.userId,
          coupanId: data.coupanId,
          status : data.status
        });
      }else{
        if(checkshortlistedCoupon.dataValues.status == data.status){

          return helpers.jsonResponse(res, false, {}, "Coupan shortlisted Already", '', 400,400);
        }else{

          await SHORTLISTEDCOUPONS.update({
              status : data.status
          },
          {
            where: 
            { 
              userId: data.userId,
              coupanId: data.coupanId,
            }
          });
          return helpers.jsonResponse(
            res,
            true,
            {},
            "Coupon updated successfully",
            200,
            200
          );
        }
      }
      return helpers.jsonResponse(
        res,
        true,
        {},
        "Coupon shortlisted successfully",
        200,
        200
      );
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  }
        
};

