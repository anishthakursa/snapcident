const config              = require('config');
const sequelize           = require('sequelize');
const Op                  = require('sequelize').Op;
const model               = require("../../models/index");
const jwt                 = require('jsonwebtoken');
const helpers             = require("../../helpers");
const hashPassword        = require('../../helpers/hashPassword');
const responseHelper      = require("../../helpers/responseHelper");
const common              = require('../../helpers/common');
const moment              = require('moment');
const users               = model.users;
const DOCUMENT            = model.documents;
const teacherSubject      = model.teacherSubjects;
const subject             = model.subjects;
const bookingNotification = model.bookingNotifications;
const bookingDetail       = model.bookingDetails;
const userTokenistory     = model.usertokenhistory;
const userDetail          = model.userDetail;
const Setting             = model.settings;
const adminCreditHistory  = model.adminCreditHistory;
const subjectDetail       = model.subjects;
const Bookings			  = model.bookings
const subCategory		  = model.subCategories

Bookings.belongsTo(subject,{foreignKey: 'subjectId',targetKey: 'id'})
Bookings.belongsTo(subCategory,{foreignKey: 'subCategoryId',targetKey: 'id'})
Bookings.belongsTo(users,{foreignKey: 'userId',targetKey: 'id'})
Bookings.belongsTo(userDetail,{foreignKey: 'userId',targetKey: 'userId'})

bookingNotification.belongsTo(subCategory,{foreignKey: 'subCategoryId',targetKey: 'id'})
// Bookings.belongsTo(subCategory,{foreignKey: 'subCategoryId',targetKey: 'id'})
subject.hasOne(teacherSubject,{foreignKey: 'subjectId',sourceKey: 'id'})
// teacherSubject.hasOne(subject,{foreignKey: 'subjectId',targetKey: 'id'});
users.hasOne(teacherSubject,{foreignKey: 'teacherId',sourceKey: 'id'});
teacherSubject.belongsTo(subject,{foreignKey: 'subjectId'});

teacherSubject.belongsTo(users, {foreignKey: 'teacherId',targetKey: 'id'})
adminCreditHistory.belongsTo(users,{foreignKey: 'professionalId'});
adminCreditHistory.belongsTo(subjectDetail,{foreignKey: 'categoryId'});
module.exports = {
	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Student list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	sList: async (req, res) => {
	    try {
	    	let SessionData = req.session.userData;
	    	const userList =  await users.findAll({
	    		where: {
	    			role: '1',
	    			companyId:SessionData.id
	    		},
	    		include: [
					{
	    			model: userDetail,
	    			attributes: ['fName','lName','phoneNo','status']
					}
				],
				order:[['createdAt','DESC']]
	    	});
			return res.render('pages/admin/user/list',{userList,moment,count:userList.length});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},



  content: async (req, res) => {
	    try {
	    	let type = req.query.type;
	    	let companyId = req.query.companyId;


	    	const data =  await Setting.findOne({
	    		where: {
	    			companyId:companyId
	    		}
	    		
	    	});
			return res.render('pages/content.ejs',{data,type});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},



  	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Teacher list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	tList: async (req, res) => {
	    try {
	    	let SessionData = req.session.userData;
	    	const userList =  await users.findAll({
	    		where: {
	    			role: '2',
	    			companyId:SessionData.id
	    		},
	    		include: [{
	    			model: userDetail,
	    			attributes: ['fName','lName','phoneNo','status']
	    		}],
				order:[['createdAt','DESC']]
	    	});
			const sub = await subject.findAll({
                attributes: ['id', 'name'],
                where: {
					status: 1, /// only active,
					companyId:SessionData.id
                }
            });
			return res.render('pages/admin/teacher/list',{userList,moment,sub,count:userList.length});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return responseHelper.error(res, 'Error', e);
	    }
  	},
	getProfessionals:async(req,res)=>{
		try {
			var page = 1
			var limit = 10
			var role = 1
			var params = req.body
			var search= ""
			var status = 2
			var category = ''
			let where
			if(params.status)  status= parseInt(params.status)==2? [0,1]:[parseInt(params.status)]
			// if(status==2){ status=[0,1] }else{ status = [status]}

			if (params.page) page = params.page
			if (params.limit) limit = parseInt(params.limit)
			if (params.role) role = parseInt(params.role)
			if (params.search) search = params.search
			if ( params.category ) category = params.category
			// console.log('-->',params.category)
			var offset = (page - 1) * limit
			let SessionData = req.session.userData;
			if(parseInt(params.role)==2){
				if(category!='' || search !=''){
					where = {
						[Op.or]: [
						sequelize.where( sequelize.fn("concat", sequelize.col("fName"),' ',sequelize.col("lName")), {[Op.like]: `%${search}%` }), 
							{ '$userDetail.fName$': { [Op.like]: `%${search}%` } },
							{ '$userDetail.lName$': { [Op.like]: `%${search}%` } },
							{ email : { [Op.like]: `%${search}%` } },
						],
						'$teacherSubject.subjectId$': { [Op.like]: `%${category}%` } ,
					
						role:role
						}
				}else{
					where={ role:role,	'$userDetail.status$':{[Op.in]:status}   }
				}
			}else{
				
				 where = {
					[Op.or]: [
					  sequelize.where( sequelize.fn("concat", sequelize.col("fName"),' ',sequelize.col("lName")), {[Op.like]: `%${search}%` }), 
					  { '$userDetail.fName$': { [Op.like]: `%${search}%` } },
					  { '$userDetail.lName$': { [Op.like]: `%${search}%` } },
					  { email : { [Op.like]: `%${search}%` } },
					],
					// '$teacherSubject.subjectId$': { [Op.like]: `%${category}%` } ,
					// [Op.or]:[{'$userDetail.status$':status}],
					
					 role: role,
					'$userDetail.status$':status 
				  }
			}
			
			where.companyId = SessionData.id

	    	const userList =  await users.findAndCountAll({
				where: where,
				nest:true,
				raw:true,
	    		include: [
					{
						model:teacherSubject,
						include:{ model:subject },
						required:false
					},
					{
	    			model: userDetail,
	    			attributes: ['fName','lName','phoneNo','status','image']
				},
			], 
			order:[['createdAt','DESC']], 
				offset: offset, limit: limit,
			});
		

			return helpers.jsonResponse(res,true,userList, appstrings.usr_list_fetched,200,200);
		}catch(e){
			return responseHelper.error(res, e.message, 400);
		}
	},
	getStatusUpdate:async(req,res)=>{
	try{
		let SessionData = req.session.userData;
		let companyId = SessionData.id;
		
		var params=req.body
		let status = parseInt( params.status )
		const userData = await userDetail.findOne({
			attributes:['id'],
			where: {
				userId: params.id,
				// companyId: companyId,
			}
		});
		if(userData)
		{
			const updatedResponse = await userDetail.update({
					status: !status,
				},
				{
				where : {
					userId: params.id 
				}
			});
			if(updatedResponse)
			return helpers.jsonResponse(res,true,updatedResponse,"User Updated successfully",200,200);
			else
			return responseHelper.error(res, e.message, 400);
		}
	}catch(e){
		return responseHelper.error(res, e.message, 400);
	}
	},
  	tFilterList: async(req, res)=>{
		try {
			let SessionData = req.session.userData;
        const data = req.body;
        var status = data.status;
        var search = data.search;
        const MainArray = [];

        var where = {
          	status: ['0','1','2']
        }

        if(search != "")
        {
        	where.fName = {
                [Op.like]: `%${search}%`
            };
        }

        if(status == '')
        {
            var restDetails =  await users.findAll({
	    		where: {
	    			role: '2',
	    			companyId:SessionData.id
	    		},
	    		include: [{
	    			model: userDetail,
	    			attributes: ['fName','lName','status'],
	    			required: true,
	    			where: where
	    		}]
	    	});
        }else{

            var restDetails = await users.findAll({
	            attributes: ['id','email','createdAt'],
	            where: {
	                role : '2',
	                companyId:SessionData.id
	            },
	            include: [
	                {
                        model: teacherSubject,
                        required: true,
                        attributes: [],
                        where: { 
                          subjectId: status
                        }
                    },
	                {
	                    model: userDetail,
	                    attributes: ['fName','lName','dob','status','uniqueId'],
	                    required: true,
	                    where: where
	                }
	            ]
          	});
        }
        return helpers.jsonResponse(res,true,restDetails,"List fetch successfully",200,200);
  		} catch (e) {
    		console.log(e)
    		return responseHelper.error(res, e.message, 400);
  		}
	},
  	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Change User Status //////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	changeStatus:  async (req, res) => {
		try
		{
			let SessionData = req.session.userData;
			let companyId = SessionData.id;
			var params=req.body
			const userData = await userDetail.findOne({
				attributes:['id'],
				where: {
					userId: params.id 
				}
			});
			if(userData)
			{
				const updatedResponse = await userDetail.update({
						status: params.status,
					},
					{
					where : {
						userId: params.id 
					}
				});

				if(params.status == '1')
				{
					const userDataDetails = await users.findOne({
						attributes:['email'],
						where: {
							id: params.id 
						}
					});

					if(userDataDetails.dataValues.role == '2')
					{
						if(params.priority != "")
						{
							await userDetail.update({
									priority: "",
								},
								{
								where : {
									priority: params.priority
								}
							});

							await userDetail.update({
									priority: params.priority,
								},
								{
								where : {
									userId: params.id
								}
							});
						}
					}
					//Send Mail
                    var htmldata =
                    '<p>Hi ' + userData.dataValues.fName + '</p>' +
                    '<p>Your account has been approved successfully. </p>' +
                    '<p>Now, you have add schedule and start sessions.</p>' +
                    '<p>Thanks,</p>' +
                    '<p>Team Cere Consult</p>' +
                    '<p>--------</p>' +
                    '<p>This is an automated email. Please do not reply to it.</p>' +
                    '<p>In case of any help, kindly reach us at - please reach us at info@Cereconsult.com" for any help" etc.</p>';
                    var subject = "Cere Consult Approval Confirmation!";
                    common.sendMail(userDataDetails.dataValues.email,htmldata,companyId,subject);
                    
				}

				if(updatedResponse)
				{
					return res.json({
			            code: 200,
			            message: "Status Change Successfully."
		          	});
				}
				else{
					return helpers.jsonResponse(
		                res,
		                true,
		                {},
		                "Something went Wrong",
		                400,
		                400
		            );
				}
			}
			else
			{
				return helpers.jsonResponse(
	                res,
	                true,
	                {},
	                "Sorry! Unable to Change Status",
	                204,
	                204
	            );
			}
		}
		catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get User Profile ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	viewProfile: async (req, res) => {
	    try {
			const id = req.params.id;
			const companyId = req.parentCompany
			const bookings = await Bookings.findAll({where:{userId:id},
			
			include:[
				{
					model:subject,
					attributes:['name','id'],
					where:{isDeleted:0},
					null:true,
					raw:true,
					nest:true,
					include:[{
						model:teacherSubject,
						attributes:['id'],
						include:[{model:users, include:{model: userDetail,attributes: ['fName','lName']}}]
					}]
				},
				// {
				// 	include:{model:subCategory,attributes:['name']}
				// }
			]
			})
			
	    	const userList =  await users.findOne({
	    		where: {
	    			id: id
	    		},
	    		include: [{
	    			model: userDetail,
	    			attributes: ['fName','image','lName','status','address','phoneNo','education','rememberToken','dob','uniqueId']
	    		}]
	    	});
	    	return res.render('pages/admin/user/view',{userList,bookings,moment});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return responseHelper.error(res, 'Error', e);
	    }
  	},
	  //user bookings

	viewBookings:async(req,res)=>{
		try{
			let body = req.body
			var page = 1
			var limit = 10
			var role = 1
			let status = [9]
			let where
			// 	userId:id,
			// 	status:status
			// }
			
			

			if (body.page) page = body.page
			if (body.limit) limit = parseInt(body.limit)
			// if (params.role) role = parseInt(params.role)
			if(body.status) status = parseInt(body.status)
			
			var offset = (page - 1) * limit

			let id = req.body.userId
			// let status = req.query.status
			if (body.search && body.search != "") {	
				where={
						[Op.or]: [
								sequelize.where( sequelize.fn("concat", sequelize.col("subject.teacherSubject.user.userDetail.fName"),' ', sequelize.col("subject.teacherSubject.user.userDetail.lName")), {[Op.like]: `%${body.search}%` }), 
								{ '$subject.teacherSubject.user.userDetail.fName$': { [Op.like]: `%${body.search}%` } },
								{ '$subject.teacherSubject.user.userDetail.lName$': { [Op.like]: `%${body.search}%` } },
						], 
					userId:id,
				}
			  }else{
				where={
					userId:id,
				}
			}
			if(status==9){ where.status=[0,1,2] }else{ where.status = [status]}

			const bookings = await Bookings.findAndCountAll({
				where:where,
				include:[
					{
						model:subject,
						attributes:['name','id'],
						where:{isDeleted:0},
						null:true,
						raw:true,
						nest:true,
						include:[{
							model:teacherSubject,
							attributes:['id'],
							include:[{
								model:users, 
								include:{model: userDetail,
								attributes: ['fName','lName']}}]
						}]
					},
					// {
					// 	include:{model:subCategory,attributes:['name']}
					// }
				],
				offset: offset, limit: limit,
				})
				return helpers.jsonResponse(res,true,bookings,appstrings.bookings_fetched_successfully,200,200);
		}catch(e){
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},  
  	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Teacher Profile ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	viewteacherProfile: async (req, res) => {
	    try {
	    	const id = req.params.id;
	    	const userList =  await users.findOne({
	    		where: {
	    			id: id
	    		},
	    		include: [{
	    			model: userDetail,
	    		}]
	    	});
	    	const userdocuments =  await DOCUMENT.findAll({
	    		where: {
	    			userId: id
	    		}
	    	});
	    	var teachers = await teacherSubject.findAll({
                where :{
                    teacherId: id,
                    status: '1'
                },
                include: [{
                	model: subject,
                	attributes: ['name']
                }]
            })
	    	
	    	return res.render('pages/admin/teacher/view',{userList,moment,userdocuments,teachers});
	    } catch (e) {
	    
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Student list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	setting: async (req, res) => {
	    try {
	    	let SessionData = req.session.userData;
	    	const userList =  await Setting.findOne({
	    		where:{
	    			companyId:SessionData.id
	    		}
	    	});
			return res.render('pages/admin/setting',{userList});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Student list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	  	postSetting: async (req, res) => {
	    try {
	    	const params = req.body;
	    	let SessionData = req.session.userData;
	    	const userList =  await Setting.findOne({
	    		where:{
	    			companyId:SessionData.id
	    		}
	    	});
	    	if(userList){
	    		const updatedResponse = await Setting.update({
					terms: params.terms,
					privacy: params.privacy,
					aboutus:params.aboutus,
					termsLink:params.termsLink,
					privacyLink:params.privacyLink,
					aboutusLink:params.aboutusLink,
                   commission: params.commission,
				},
				{
				where : {
					id: userList.dataValues.id
				}
			});
	    	}else{
	    		const updatedResponse = await Setting.create({
					terms: params.terms,
					privacy: params.privacy,
					commission: params.commission,
					aboutus:params.aboutus,
					termsLink:params.termsLink,
					privacyLink:params.privacyLink,
					aboutusLink:params.aboutusLink,
					companyId:SessionData.id
				});
	    	}
	    	

	    	
			return res.json({
	            code: 200,
	            message: "Setting updated Successfully."
          	});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////
    /////////////////////////Create Channel//////////////////
    //////////////////////////////////////////////////////////////////
    getRequestlist:  async function (req, res) {
        try {
            const id = req.params.id;
            const usr = await bookingNotification.findAll({
                attributes: ['bookId','teacherId','description','status'],
                where: {
                    teacherId: id
                },
                include: [
			{
			  attributes:['name'],
			  model:subCategory	
			},
			{
                    model: bookingDetail,
                    attributes: ['id','studentId','bookingDate','timeSlot'],
                    include: [{
                        model: userDetail,
			attributes: ['fName','lName','phoneNo'],
			include:{model:user}
                    }]
                }]
            });
            return res.render('pages/admin/teacher/request',{usr});
            
            
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
	
	getBookinglist:  async function (req, res) {
        	try {
			const id = req.params.id;
			const usr = await Bookings.findAll({
				 attributes: ['bookingDate','timeSlot','status'],
				where: {
                		    teacherId: id
				},
				include:[
				{
					attributes:['name'],
					model:subCategory
				},
				{
					model:users,
					
				},	
				{
					model: userDetail,
				}],
				order:[['bookingDate','Desc']]
			})
			
            return res.render('pages/admin/teacher/bookings',{usr});
             
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
    //////////////////////////////////////////////////////////////////
    /////////////////////////Token History Teacher//////////////////
    //////////////////////////////////////////////////////////////////
    teacherTokenHistory:  async function (req, res) {
        const data = req.params;
        //Check User Token
        var datat = await userTokenHistory.findAll({
            attributes: ['senderId','receiverId','token','tokenBalance','status','type','createdAt'],
            where :{
                senderId: data.id,
                status: '1'
            },
            order: [
                ['id', 'DESC']
            ], 
        })
        var mainArray  = [];
        for (var i = 0; i < datat.length; i++) {
            var array = {};
            var token = datat[i].token;
            var tokenBalance = datat[i].tokenBalance;
            var status = datat[i].status;
            var userdetails = await userDetail.findOne({
                where :{
                    userId: datat[i].receiverId
                }
            })
            var type = "Credit from " + userdetails.dataValues.fName + ' ' +userdetails.dataValues.lName;
            array.token        = token;
            array.tokenBalance = tokenBalance;
            array.type         = type;
            var theDate = new Date( datat[i].createdAt * 1000);
            var dateString = theDate.toGMTString();
            //alert(dateString );
            array.createdAt    = dateString; 
            mainArray.push(array);
        }
        return res.render('pages/admin/teacher/credit',{mainArray});
    },

    timeslots:async function (req, res) {
    	try {
    		let SessionData = req.session.userData;
		    const findData = await Setting.findOne({
		    	where:{
		    		companyId: SessionData.id
		    	}
		    });
		    if(findData){
		      if(findData.dataValues.timeslots != ""){
		         var inst = JSON.parse(findData.dataValues.timeslots);
		      }else{
		        var inst = [];
		      }
		     
		    }else{
		      var inst = [];
		    }
		    return res.render('pages/admin/timeslot.ejs',{inst});
	  	} catch (e) {
		    return responseHelper.error(res, e.message, 400);
	  	}
    },

    addTimeslot: async function(req, res) {
    	try {
		    const data = req.body;
		    let SessionData = req.session.userData;
		    const findData =  await Setting.findOne({
		    	where:{
		    		companyId: SessionData.id
		    	}
		    });
		    if(findData){
		      var inst = data.tip;
		      var mainArray = [];
		      if(Array.isArray(inst))
		      {
		      	for (var i = 0; i < inst.length; i++) {
		        var array         = {};
		        if(inst[i] != ""){
		          var heading       = parseInt(inst[i]);
		          mainArray.push(heading);
		        }
		      }
		      }else{
		      	if(inst != ""){
		          var heading       = parseInt(inst);
		          mainArray.push(heading);
		        }
		      }
		      
		      
		      //Update Instruction
		      const users = await Setting.update({
		        timeslots: JSON.stringify(mainArray)
		      },
		      {
		        where: {
		          id: findData.dataValues.id
		        }
		      });
		    }else{
		      const timeslots = data.tip;
		      var mainArray = [];
		      if(Array.isArray(timeslots))
		      {
		      	for (var i = 0; i < timeslots.length; i++) {
		        var array         = {};
		        if(timeslots[i] != ""){
		          var heading       = parseInt(timeslots[i]);
		          mainArray.push(heading);
		        }
		      }
		      }else{
		      	if(timeslots != ""){
		          var heading       = parseInt(timeslots);
		          mainArray.push(heading);
		        }
		      }
		      var mainArray = [];
		      for (var i = 0; i < timeslots.length; i++) {
		        var array         = {};
		        if(timeslots[i] != ""){
		          var heading       = parseInt(timeslots[i]);
		          mainArray.push(heading);
		        }
		      }
		      //Update Instruction
		      const users = await Setting.create({
		        timeslots: JSON.stringify(mainArray),
		        companyId: SessionData.id
		      });
		    }
		    return res.json({
	            code: 200,
	            message: "Setting updated Successfully."
          	});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
    },
    /*************** Credit History *****************/
	creditHistory: async (req, res, next) => {
	    try
	    {
			const companyId = req.session.userData.id;
			const subjects = await subject.findAll({
				where: {
					companyId: companyId
				},
			})
	      	const cls = await adminCreditHistory.findAll({
	      		attributes: ['credit','commission','payableCredit','creditBalance','status',"creditDate"],
	      		where: {
	      			companyId: companyId
	      		},
	      		include: [{
	      			model: users,
	      			include: [{
	      				model: userDetail
	      			}]
	      		},
	      		{
	      			model: subjectDetail,
	      			attributes: ['name']
	      		}],
	      		order: [
		            ['id', 'DESC'],
		        ],
	      	});
	      	return res.render('pages/admin/credit.ejs',{cls,subjects:subjects});
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},
	//////============================= NOtification Setting ===============================//////
  	notificationSetting: async (req, res) => {
	    try {
	       if(req.session.userData){
	       	const data = await NOTIFICATIONKEY.findOne({
	       		where: {
	       			companyId: req.id
	       		}
	       	})
	       	return res.render('pages/admin/notification/setting',{data});
	      }
	      return res.render('pages/admin/login');
	    } catch (e) {
	      console.log('Error => ', e);
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},
	creditHistoryRecords: async (req, res, next) => {
	    try
	    {
			const params = req.body
			var page = 1
			var limit = 10
			var role = 1
			let status = [2]
			let subject=[]
			// if (params.search && params.search != "") {	
			//   }
			var fromDate1=params.fromDates
			var toDate1=params.toDates

			

			if(params.subject) subject = params.subject
			if (params.page) page = params.page
			if (params.limit) limit = parseInt(params.limit)
			if (params.role) role = parseInt(params.role)
			if(params.status) status = parseInt(params.status)
			if(status==2){ status=[0,1] }else{ status = [status]}
			var offset = (page - 1) * limit
			
			const companyId = req.session.userData.id;
			let where = {
				[Op.or]: [
					sequelize.where( sequelize.fn("concat", sequelize.col("user.userDetail.fName"),' ', sequelize.col("user.userDetail.lName")), {[Op.like]: `%${params.search}%` }), 
					{ '$user.userDetail.fName$': { [Op.like]: `%${params.search}%` } },
					{ '$user.userDetail.lName$': { [Op.like]: `%${params.search}%` } },
					{ '$user.email$': { [Op.like]: `%${params.search}%` } },
				], 				
				companyId: companyId,
				status:status,
				
			  }
			  if(subject.length){
				  where.categoryId = subject
			  }
			  if(fromDate1&&toDate1){
				//where.creditDate= { [Op.gte]: new Date(fromDate1),[Op.lte]: new Date(toDate1)}
where.creditDate= { [Op.gte]: (new Date(fromDate1)).toISOString().split('T')[0],[Op.lte]: (new Date(toDate1)).toISOString().split('T')[0]}
			  }
	      	const cls = await adminCreditHistory.findAndCountAll({
	      		attributes: ['credit','commission','payableCredit','creditBalance','status','creditDate'],
	      		where: where,
	      		include: [{
	      			model: users,
	      			include: [{
	      				model: userDetail
	      			}]
	      		},
	      		{
	      			model: subjectDetail,
	      			attributes: ['name']
	      		}],
	      		order: [
		            ['id', 'DESC'],
				],
				offset: offset, limit: limit,
			  });
			  return helpers.jsonResponse(res,true,cls,appstrings.credit_fetchd_success,200,200);
	      
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},
	userUpdate:async function(req,res){
		try{
		
		let params =  req.body
		let fName = params.firstName
		let lName = params.lastName
		// console.log('params.teacherId',params.teacherId)
		// let email = params.email
		let education = params.education
		let address = params.address
		let rememberToken = params.rememberToken ? params.rememberToken: o
		let arrestedDetails = params.arrestedDetails
		let chargedDetails = params.chargedDetails
		let charged = params.charged?params.charged:0
		let arrested = params.arrested?params.arrested:0
		let priority = params.priority
			let Params = {
				fName :fName,
				lName: lName,
				education: education,
				address: address,
				rememberToken: rememberToken,
				phoneNo: params.phoneNo
			}

		if(params.isTeacher){
			Params.arrestedDetails = arrestedDetails
			Params.chargedDetails = chargedDetails
			Params.charged = charged
			Params.arrested = arrested
			Params.priority = params.priority
		}else{
		
			Params.uniqueId = params.uniqueId
			Params.dob	= params.dob
		}

		const updatedResponse = await userDetail.update(Params,
		{
			where : {
				userId: params.userId
			}
		});
		if(updatedResponse){
			return helpers.jsonResponse(res,true,params,"Details have been saved successfully!",200,200);
		}else{
			return responseHelper.error(res, "something went wrong", 200,200);
		}
	} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, 400, 400);
	 }
	}
}