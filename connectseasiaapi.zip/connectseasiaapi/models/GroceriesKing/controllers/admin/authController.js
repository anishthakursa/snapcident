
const jwt = require("jsonwebtoken");
const sequelize = require('sequelize');
const moment = require('moment');

userDetail.belongsTo(USER,{foreignKey:'userId'})
adminCreditHistory.belongsTo(USER,{foreignKey: 'professionalId'});
adminCreditHistory.belongsTo(subject,{foreignKey: 'categoryId'});
var  months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
module.exports = {

  //////============================= Login Function ===============================//////
  login: async (req, res) => {
    try {
       if(req.session.userData){
         return res.redirect('/admin/dashboard');
      }
      return res.render('pages/admin/login');
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  ///////////////////////// Admin Post Login /////////////////////////////
  postLogin: async (req, res) => {
    try {
      const data = req.body;
      const user = await COMPANY.findOne({
         where: {
           email: data.email
         }
       });
	  
      if (user) {
        const getUser = user.toJSON();

      const match = true
        // compare pwd
        if (!match) {
          return helpers.jsonResponse(res, false, {}, appstrings.invalid_password, 400, 400);
        }
        getUser.credit       = getUser.rememberToken;
        req.session.userData = getUser;
		    req.session.email    = getUser.email;
        req.session.roleType = "Admin";
        req.session.userData.roleType ="Administrator"
        const credentials = {
          id: getUser.id,
          email: getUser.email,
          exp: Math.floor(Date.now() / 1000) + 8640000*2,
        };
      
        const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });
        const refreshToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });
        getUser.authToken = authToken;
        getUser.refreshToken = refreshToken;
        return helpers.jsonResponse(res, true, {}, appstrings.login_success, 200, 200);
      }
      return helpers.jsonResponse(res, false, {}, appstrings.invalid_cred, 400, 400);
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
  getCategoryRenuve: async(req,res) => {
    try {
      const MainArray = [];
      const companyId = req.session.userData.id;
      //Avg Renve
      var featured = await subject.findAll({
        attributes: ['id','name','image'],
        where:{
          companyId: companyId
        }
      });
      for (var i = 0; i < featured.length; i++) 
      {
        var array = {};
        var id = featured[i].id;
         //Total Revnue
         var name = featured[i].name;
        array.label = name;
         
        var totalRevenue = await TeacherBooking.findOne({
          attributes: [
            [sequelize.fn('sum', sequelize.col('credit')), 'totalAmount'],
          ],
          where: {
            subjectId: id
          }
        });
        if(totalRevenue.dataValues.totalAmount == null)
        {
          console.log("0")
        }else{
          array.data = totalRevenue.dataValues.totalAmount;
          MainArray.push(array);
        }
      }
      return helpers.jsonResponse(
        res,
        true,
        MainArray,
        appstrings.success,
        200,
        200
      );
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

   getYearlyRevenue: async(req,res) => {
    try {
      const params = req.body;
      const companyId = req.session.userData.id;
       var year = params.year;
      var fromDate = moment().startOf('year');
      var fromDateMonth = new Date(fromDate);
      var fromMonth = (fromDateMonth.getMonth()+ 1) < 10 ? '0' + (fromDateMonth.getMonth()+1) : (fromDateMonth.getMonth()+1);

      const MainArray = [];
      //Avg Renve
      var featured = await subject.findAll({
        attributes: ['id','name','image'],
        where:{
          companyId: companyId
        }
      });
      for (var i = 0; i < featured.length; i++) 
      {
        var array = {};
        var id = featured[i].id;
         //Total Revnue
        var name = featured[i].name;
        array.name = name;
         
        var newArray = [];
        var year = params.year;
       
        // console.log(JSON.parse(JSON.stringify(creditHistory)))

        for(var j=1;j<=12;j++){
          var totalYearlyRevenue = await adminCreditHistory.findOne({
            attributes: [
              [ sequelize.fn('MONTH', sequelize.col('creditDate')), 'data'],
              [sequelize.fn('sum', sequelize.col('commission')), 'total_amount'],

            ],
            where: {
              [Op.and]: [
                sequelize.where(sequelize.fn('YEAR', sequelize.col('creditDate')), year),
                sequelize.where(sequelize.fn('MONTH', sequelize.col('creditDate')), j),
                {categoryId: id},
              ]
            }
          });
          if(totalYearlyRevenue.dataValues.total_amount == null)
          {
            newArray.push(0);
          }else{
            newArray.push(parseInt(totalYearlyRevenue.dataValues.total_amount));
          }
        }
        array.data = newArray;
        MainArray.push(array);
      }
     
       // console.log(MainArray);
      return helpers.jsonResponse(
        res,
        true,
        MainArray,
        appstrings.success,
        200,
        200
      );
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
  getCreditHistory:async(req,res)=>{
try{
  let year = req.params.year
        let creditHistory = await adminCreditHistory.findAll({
          // companyId:
        include:[{
          model: USER,attributes:['id','email'],
          include:{model:userDetail,attributes:['fName','lName']}
        },
        {model:USER,as:'customer', include:{model:userDetail,attributes:['fName','lName']}},
        {
          model:subject,
          attributes:['id','name']
        }
      ],
      where: {
        [Op.and]: [
          sequelize.where(sequelize.fn('YEAR', sequelize.col('creditDate')), year),
        ]
      }
        })
         // console.log(MainArray);
         return helpers.jsonResponse(
          res,
          true,
          creditHistory,
          appstrings.credit_history_success,
          200,
          200
        );
      } catch (e) {
        console.log('Error => ', e);
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
      }
  },
  getTeacherYearlyRevenue: async(req,res) => {
    try {
      let result = []
      const params = req.body;
    
       var year = params.year;
       var professionalId = params.teacherId
       console.log(' calculating year-->',year)
      var fromDate = moment().startOf('year');
      var fromDateMonth = new Date(fromDate);
      var fromMonth = (fromDateMonth.getMonth()+ 1) < 10 ? '0' + (fromDateMonth.getMonth()+1) : (fromDateMonth.getMonth()+1);

      const MainArray = [];
      const MainArray1 = [];
        var array = {};
        let array1 = { name: "Bookings" ,type: 'spline'}
        let array2 = { name:"Months" }
        let array2Data = []
        // var id = featured[i].id;
        var id = professionalId
         //Total Revnue
        // var name = featured[i].name;
        array.name = "Credit Earned";
        var newArray = [];
        let bookingsdata = []
        var year = params.year;
        // console.log('  -> ')
        // console.log(JSON.parse(JSON.stringify(totalbookings)))
        for(var j=1;j<=12;j++){
          var totalbookings = await bookings.findOne({
            attributes: [
              [ sequelize.fn('MONTH', sequelize.col('bookingDate')), 'data' ],
              [ sequelize.fn('count', sequelize.col('id')), 'total_bookings' ],
            ],
            where: {
              [Op.and]: [
                sequelize.where(sequelize.fn('YEAR', sequelize.col('bookingDate')), year),
                sequelize.where(sequelize.fn('MONTH', sequelize.col('bookingDate')), j),
                { teacherId: professionalId },
              ]
            },
         
          })
          if(totalbookings.dataValues.total_bookings == null)
          {
            bookingsdata.push(0);
          }else{
            bookingsdata.push(parseInt(totalbookings.dataValues.total_bookings));
          } 
          var totalYearlyRevenue = await adminCreditHistory.findOne({
            attributes: [
              [ sequelize.fn('MONTH', sequelize.col('creditDate')), 'data'],
              [sequelize.fn('sum', sequelize.col('commission')), 'total_amount'],

            ],
            where: {
              [Op.and]: [
                sequelize.where(sequelize.fn('YEAR', sequelize.col('creditDate')), year),
                sequelize.where(sequelize.fn('MONTH', sequelize.col('creditDate')), j),
                {professionalId: professionalId},
              ]
            }
          });
          if(totalYearlyRevenue.dataValues.total_amount == null)
          {
            newArray.push(0);
          }else{
            newArray.push(parseInt(totalYearlyRevenue.dataValues.total_amount));
          }
          array2Data.push({
            name: months[j+1],
            y:totalYearlyRevenue.dataValues.total_amount?totalYearlyRevenue.dataValues.total_amount:0,
         })
        }
        let ratingStat = []
        let overallRating = await ratings.findOne({where:{teacherId:professionalId}})
        
        if(overallRating && overallRating.dataValues){
         
          ratingStat.push(
           
            {
              name: 'behaviour',
              data: [(overallRating.dataValues.professionalBehavior)?overallRating.dataValues.professionalBehavior:0]
            },
            {
              name: 'knowledge',
              data: [(overallRating.dataValues.professionalKnow)?overallRating.dataValues.professionalKnow:0]
            },
            {
              name: 'video quality',
              data: [(overallRating.dataValues.videoQuality)?overallRating.dataValues.videoQuality:0]
            }, {
              name: 'rating',
              data: [overallRating.dataValues.rating?overallRating.dataValues.rating:0]
            },
            )
          }
        //  date.toLocaleString('en-us', { month: 'short' });
        array1.data = bookingsdata
        array.data = newArray;
        array2.data = array2Data
          MainArray.push(array);
          MainArray.push(array1)
          MainArray1.push(array2Data)
        result.push(MainArray)
        result.push(array2Data)
        result.push(ratingStat)
          return helpers.jsonResponse(
        res,
        true,
        result,
        appstrings.success,
        200,
        200
      );
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
  /////////////////////////// Admin Dashboard ////////////////////
  dashboard: async(req, res) => {
    try {
     
      const companyId = req.session.userData.id;
      //Avg Renve

      //Total Revnue
      const totalRevenue = await TeacherBooking.findOne({
        attributes: [
          [sequelize.fn('sum', sequelize.col('credit')), 'totalAmount'],
        ],
        where:{
          companyId: companyId
        }
      })

      //Total Booking
      var totalBooking = await bookingNotification.findAll({
        where:{
          companyId: companyId
        }
      });

      //Top 5 Professional
      var where={
        role: '2',
        companyId: companyId
      }

      var limit  = 5;
      var offset = 0;
      const MainArray = [];

      //Get Free Delivery Restuarant
      var featured = await subject.findAll({
        attributes: ['id','name','image'],
        where:{
          companyId: companyId
        }
      });

      for (var i = 0; i < featured.length; i++) 
      {
        var array = {};
        var id = featured[i].id;
        var name = featured[i].name;
        array.type = name;
        array.categoryId = id;
        var restDetails = await USER.findAll({
          attributes: ['id','email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = users.id)'), 'totalRating']],
          where: {
              role : '2',
              companyId: companyId
          },
          order: sequelize.literal(`totalRating DESC`),
          include: [
              {
                  model: teacherSubject,
                  required: true,
                  attributes: [],
                  where: { 
                    subjectId: id
                  }
              },
              {
                  model: userDetail,
                  attributes: ['fName','lName','dob','image','uniqueId'],
                  required: true,
                  where: {
                      status: '1'
                  } 
              }
          ],
          offset: offset, 
          limit: limit,
        });
        array.professional = restDetails;
        if(restDetails.length > 0)
        {
          MainArray.push(array);
        }
      }

      var MainArrayN = JSON.parse(JSON.stringify(MainArray));

      const userData = await USER.findAll({
        attributes: ['id','email',
        [sequelize.literal('(SELECT ROUND(AVG(rating),0) FROM ratings where teacherId = users.id)'), 'totalRating']],
        where: where,
        order: sequelize.literal(`totalRating DESC`),
        include: [{
          model: userDetail,
          attributes: ['fName','lName','status']
        }],
        limit:5, offset:0
      }); 

      //Total Categories
      var totalCategory = await subject.findAll({
        where:{
          companyId: companyId
        }
      });

      //Total Customer
      var totalCustomers = await USER.findAll({
        where: {
          role: '1',
          companyId: companyId
        }
      });

      //TotalProfessional
      var totalProfessional = await USER.findAll({
        where: {
          role: '2',
          companyId: companyId
        }
      });

      //Get Recent Bookings
      var newDate = moment(new Date()).format("YYYY-MM-DD");
      const usr = await bookingNotification.findAll({
        attributes: ['bookId','teacherId','description','status'],
        where:{
          companyId: companyId
        },
        include: [{
            model: StudentbookingDetail,
            attributes: ['id','studentId','bookingDate','timeSlot'],
            required: true,
            where: {
              bookingDate: newDate
            },
            include: [{
              model: userDetail,
              attributes: ['fName','lName','image']
            }]
        }]
      });
      var usrArray = [];
      for(var k=0;k<usr.length;k++)
      {
        var array = {};

        array.bookingDate  = usr[k].bookingDetail.bookingDate;
        array.timeSlot     = usr[k].bookingDetail.timeSlot;
        //Get Student Name
        var stuentNmae = await userDetail.findOne({
          attributes: ['fName','lName'],
          where: {
            userId: usr[k].bookingDetail.studentId
          }
        });
        array.sName     = stuentNmae.dataValues.fName+ ' ' +stuentNmae.dataValues.lName;
        //Get Teacher Details
        var teacherName = await userDetail.findOne({
          attributes: ['fName','lName'],
          where: {
            userId: usr[k].teacherId
          }
        });
        array.tName     = teacherName.dataValues.fName+ ' ' +teacherName.dataValues.lName;
        //Get Category Details
        var categoryName = await subject.findOne({
          attributes: ['id','name','image'],
          where:{
            companyId: companyId
          }
        });
        array.category     = categoryName.dataValues.name;
        usrArray.push(array);
      }
      
      //Get Revenue All Categories
      var data = {};
      data.totalCustomers = totalCustomers;
      data.totalProfessional = totalProfessional;
      data.totalCategory = totalCategory;
      data.totalBooking = totalBooking;
      data.userData = userData;
      data.CategoryProfessional = MainArrayN;
      data.totalRevenue = totalRevenue.dataValues.totalAmount;

      return res.render('pages/admin/dashboard',{data,usrArray,moment});
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

newdashboard:async(req,res)=>{
try{
    
  const companyId = req.session.userData.id;
  //Avg Renve

  //Total Revnue
  const totalRevenue = await TeacherBooking.findOne({
    attributes: [
      [sequelize.fn('sum', sequelize.col('credit')), 'totalAmount'],
    ],
    where:{
      companyId: companyId
    }
  })

  //Total Booking
  var totalBooking = await bookingNotification.findAll({
    where:{
      companyId: companyId
    }
  });

  //Top 5 Professional
  var where={
    role: '2',
    companyId: companyId
  }

  var limit  = 5;
  var offset = 0;
  const MainArray = [];

  //Get Free Delivery Restuarant
  var featured = await subject.findAll({
    attributes: ['id','name','image'],
    where:{
      companyId: companyId
    }
  });

  for (var i = 0; i < featured.length; i++) 
  {
    var array = {};
    var id = featured[i].id;
    var name = featured[i].name;
    array.type = name;
    array.categoryId = id;
    var restDetails = await USER.findAll({
      attributes: ['id','email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = users.id)'), 'totalRating']],
      where: {
          role : '2',
          companyId: companyId
      },
      order: sequelize.literal(`totalRating DESC`),
      include: [
          {
              model: teacherSubject,
              required: true,
              attributes: [],
              where: { 
                subjectId: id
              }
          },
          {
              model: userDetail,
              attributes: ['fName','lName','dob','image','uniqueId'],
              required: true,
              where: {
                  status: '1'
              } 
          }
      ],
      offset: offset, 
      limit: limit,
    });
    array.professional = restDetails;
    if(restDetails.length > 0)
    {
      MainArray.push(array);
    }
  }

  var MainArrayN = JSON.parse(JSON.stringify(MainArray));

  const userData = await USER.findAll({
    attributes: ['id','email',
    [sequelize.literal('(SELECT ROUND(AVG(rating),0) FROM ratings where teacherId = users.id)'), 'totalRating']],
    where: where,
    order: sequelize.literal(`totalRating DESC`),
    include: [{
      model: userDetail,
      attributes: ['fName','lName','status']
    }],
    limit:5, offset:0
  }); 

  //Total Categories
  var totalCategory = await subject.findAll({
    where:{
      companyId: companyId
    }
  });

  //Total Customer
  var totalCustomers = await USER.findAll({
    where: {
      role: '1',
      companyId: companyId
    }
  });

  //TotalProfessional
  var totalProfessional = await USER.findAll({
    where: {
      role: '2',
      companyId: companyId
    }
  });

  //Get Recent Bookings
  var newDate = moment(new Date()).format("YYYY-MM-DD");
  const usr = await bookingNotification.findAll({
    attributes: ['bookId','teacherId','description','status'],
    where:{
      companyId: companyId
    },
    include: [{
        model: StudentbookingDetail,
        attributes: ['id','studentId','bookingDate','timeSlot'],
        required: true,
        where: {
          bookingDate: newDate
        },
        include: [{
          model: userDetail,
          attributes: ['fName','lName','image']
        }]
    }]
  });
  var usrArray = [];
  for(var k=0;k<usr.length;k++)
  {
    var array = {};

    array.bookingDate  = usr[k].bookingDetail.bookingDate;
    array.timeSlot     = usr[k].bookingDetail.timeSlot;
    //Get Student Name
    var stuentNmae = await userDetail.findOne({
      attributes: ['fName','lName'],
      where: {
        userId: usr[k].bookingDetail.studentId
      }
    });
    array.sName     = stuentNmae.dataValues.fName+ ' ' +stuentNmae.dataValues.lName;
    //Get Teacher Details
    var teacherName = await userDetail.findOne({
      attributes: ['fName','lName'],
      where: {
        userId: usr[k].teacherId
      }
    });
    array.tName     = teacherName.dataValues.fName+ ' ' +teacherName.dataValues.lName;
    //Get Category Details
    var categoryName = await subject.findOne({
      attributes: ['id','name','image'],
      where:{
        companyId: companyId
      }
    });
    array.category     = categoryName.dataValues.name;
    usrArray.push(array);
  }
  
  //Get Revenue All Categories
  var data = {};
  data.totalCustomers = totalCustomers;
  data.totalProfessional = totalProfessional;
  data.totalCategory = totalCategory;
  data.totalBooking = totalBooking;
  data.userData = userData;
  data.CategoryProfessional = MainArrayN;
  data.totalRevenue = totalRevenue.dataValues.totalAmount;
return res.render('pages/admin/dashboard',{data,usrArray,moment});
} catch (e) {
  console.log('Error => ', e);
  return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
}
},
  getCategoryBasisPro: async(req, res) => {
    const data = req.body;
    const companyId = req.session.userData.id;
    var categoryId = data.categoryId;
     var featured = await subject.findOne({
        attributes: ['id','name','image'],
        where: {
          id: categoryId
        }
      });
    var limit  = 5;
      var offset = 0;
   
    var array = {};
    var name = featured ? featured.dataValues.name : "";
    array.type = name;
    var restDetails = await USER.findAll({
      attributes: ['id','email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = users.id)'), 'totalRating'],
      [sequelize.literal('(SELECT count(*) FROM bookings where teacherId = users.id)'), 'totalBookings'],
      [sequelize.literal('(SELECT SUM(credit) FROM bookings where teacherId = users.id AND subjectId = "'+categoryId+'")'), 'totalRevenue']],
      where: {
          role : '2',
          companyId: companyId
      },
      order: sequelize.literal(`totalRating DESC`),
      include: [
          {
              model: teacherSubject,
              required: true,
              attributes: [],
              where: { 
                subjectId: categoryId
              }
          },
          {
              model: userDetail,
              attributes: ['fName','lName','dob','image','address','phoneNo','uniqueId'],
              required: true,
              where: {
                  status: '1'
              } 
          }
      ],
      offset: offset, 
      limit: limit,
    });
    array.professional = restDetails;
  if(array){

    return helpers.jsonResponse(
      res,
      true,
      array,
      appstrings.success,
      200,
      200
    );
  }else{

    return helpers.jsonResponse(
      res,
      true,
      [],
      appstrings.success,
      201,
      201
    );
  }

  },

  /////////////////////////// Admin Logout ////////////////////
  logout: async(req, res) => {
    req.session.destroy((err) => {
    if(err) {
      return console.log(err);
    }
    return res.redirect('/admin');
    });
  },


  

  ////////////////////////////////////////////////////////////
  ///////////// Forgot PAge //////////////////////////////////
  ////////////////////////////////////////////////////////////
  forgotPassword:  async (req, res, next) => {
    try {
      return res.render('pages/admin/forgotPassword');
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  ///////////////////////////////////////////////
  /////////// Post Forgot Password //////////////
  //////////////////////////////////////////////
  postforgotPassword: async (req, res, next) => {
   
      var params=req.body
      let responseNull= commonMethods.checkParameterMissing([params.email])
    
      if(responseNull) return responseHelper.post(res, appstrings.required_field,null,400);
    
          try{
                 userData = await COMPANY.findOne({
                where: {
                    email: params.email,
                  }
                  })  
                    
                  if(userData)
                 {
    
                  
                    userData= JSON.parse(JSON.stringify(userData))
    
    
                      var number= Math.floor(Math.random()*(10000000-0+1)+10000000 )+"";
                      const newPassword = await hashPassword.generatePass(number);
                     var dataEmail={name: userData.companyName,password: number,app_name:config.APP_NAME}
                     commonNotification.sendForgotPasswordMail(userData.email,dataEmail,userData,req.id)
                      await COMPANY.update({ password: newPassword}, {where: { id: userData.id}}) ;
    
                   return responseHelper.post(res, appstrings.password_reset_success,null,200, )}  
                 
                     else    
                  {  
                      return responseHelper.post(res, appstrings.no_record,null,204);
                  }
    
                  
    
    
                         
      }catch (e) {
          console.log(e)
            return responseHelper.error(res, e.message);
    
      }
    
    },

    ////////////////////////////////////////////////////////////
  ///////////// Forgot PAge //////////////////////////////////
  ////////////////////////////////////////////////////////////
  changePassword:  async (req, res, next) => {
    try {
      return res.render('pages/admin/changePassword');
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

   ////////////////////////////////////////////////////////////
  ///////////// Post Change Password //////////////////////////////////
  ////////////////////////////////////////////////////////////
  postChangePassword:  async (req, res, next) => {
    try {
      const params = req.body;
      const userData = await COMPANY.findOne({
        where: {
          id: req.id,
        }
      })  
      if(userData)
      {
        const match = await hashPassword.comparePass(params.oldPassword,userData.dataValues.password);
        if (!match) {
          return helpers.jsonResponse(
            res,
            true,
            {},
            appstrings.inccorect_oldpass,
            204,
            204
          );
        }else{
          const newPassword = await hashPassword.generatePass(params.npassword);
          await COMPANY.update({ password: newPassword}, {where: { id: req.id}}) ;
          return helpers.jsonResponse(
            res,
            true,
            {},
            appstrings.password_change_success,
            200,
            200
          ); 
          
        }
      }  
      else    
      { 
       return helpers.jsonResponse(res, false, {},appstrings.no_record, 204, 204);
      }
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  ////////////////////////////////////////////////////////////
  ///////////// View Profile //////////////////////////////////
  ////////////////////////////////////////////////////////////
  viewProfile:  async (req, res, next) => {
    try {
      const user = await COMPANY.findOne({
         where: {
           id: req.id
         }
       });
      return res.render('pages/admin/profile',{user});
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },


   ////////////////////////////////////////////////////////////
  ///////////// Post Change Password //////////////////////////////////
  ////////////////////////////////////////////////////////////
  updateProfile:  async (req, res, next) => {
    try {
      const params = req.body;
      const userData = await COMPANY.findOne({
        where: {
          id: req.id,
        }
      })  
      if(userData)
      {
        var icon = "";
            if (req.files) {
                ImageFile = req.files.image;  
                if(ImageFile)
                {
                    icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
                    ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
                        //upload file
                        if (err)
                        return helpers.jsonResponse(res, false, {}, err.message, 400);
                    });
                }
            }

        await COMPANY.update({ 
          address: params.address1,
          longitude: params.longitude,
          latitude: params.latitude,
          fName: params.firstName,
          lName: params.lastName,
          image: (icon != "") ? icon : userData.dataValues.image
        }, {
          where: { 
            id: req.id
          }
        }) ;

 	req.session.userData.fName =params.firstName
            	let img =(icon != "") ? icon : userData.dataValues.image
        	req.session.userData.image = '/images/'+img

        return helpers.jsonResponse(
          res,
          true,
          {},
          appstrings.success,
          200,
          200
        );
      }  
      else    
      { 
       return helpers.jsonResponse(res, false, {},appstrings.no_record, 204, 204);
      }
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
  
};
