
const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model          = require("../../models/index");
const jwt            = require('jsonwebtoken');
const helpers        = require("../../helpers");
const hashPassword   = require('../../helpers/hashPassword');
const responseHelper = require("../../helpers/responseHelper");
const common         = require('../../helpers/common');
const moment         = require('moment');
const DOCUMENT       = model.documents;
const COUPAN         = model.coupan;
const subject        = model.subjects;

module.exports = {
  /**
  *@Method GET
  *@role Coupon List
  */
  list: async(req,res,next) => {
    let sessionData = req.session.userData;
    try{
      const findData = await COUPAN.findAll({
        where: {
          companyId: sessionData.id,
        }
      });
      return res.render('pages/admin/coupans/coupanListing',{data:findData,count: findData.length});
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  getCoupanList:async(req,res)=>{
    try {
      let sessionData = req.session.userData;
      var page = 1
      var limit = 10
     
      var params = req.body;
      let status = params.status
      let search = params.search ? params.search:''
      let where = {  companyId: sessionData.id }
      if (search!="")
      {
       where = {
        [Op.or]: [
	  { name: { [Op.like]: `%${params.search}%` } },
          { code: { [Op.like]: `%${params.search}%` } },
         
        ], 
        companyId: sessionData.id,
       }
      }else{
        where.companyId=sessionData.id
      }
      if(status==2){
        where.status=[0,1]
      }else{
        where.status=[status]
      }
      
      if (params.page) page = params.page
      if (params.limit) limit = parseInt(params.limit)
      if (params.role) role = parseInt(params.role)
      var offset = (page - 1) * limit
      const userList =  await COUPAN.findAndCountAll({
        where: where,  
        offset: offset, limit: limit,
      });
      return helpers.jsonResponse(res,true,userList,"Coupon list fetched successfully",200,200);
    }catch(e){
      return responseHelper.error(res, e.message, 400);
    }
  },

  /**
  *@Method GET
  *@role Add New Coupon
  */
  add: async(req,res,next) => {
    try{
      let sessionData = req.session.userData;
      const findData = await subject.findAll({
      where :{companyId :sessionData.id}
      });
      return res.render('pages/admin/coupans/addCoupan',{data:findData});
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  postAdd: async (req, res) => {
    try {
      const data = req.body;
      var icon = "";
      var thumbnail = "";
      if (req.files) {
        ImageFile = req.files.icon;    
        if(ImageFile)
        {
          icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
          ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
              //upload file
              if (err)
              return helpers.jsonResponse(res, false, {}, err.message, err.code, 400);   
          });
        }
      }
      const user = await COUPAN.findOne({
        attributes: ['id'],
        where: {
          code: data.code,
        }
      });
      if (!user) {
        let sessionData = req.session.userData;
        const users = await COUPAN.create({
          name: data.name,
          type: data.type,
          usageLimit: '2',
          code: data.code.toUpperCase(),
          discount: data.discount,
          icon: icon,
          validupto:data.validupto,
          thumbnail: icon,
          description:data.description,
          subjectId:data.subjectId,
          companyId:  sessionData.id,
          minimumAmount:data.minimumAmount
        });
        return helpers.jsonResponse(res,true,{},appstrings.add_coupan, 200, 200);
  
      }
        else  return helpers.jsonResponse(res,true,{},appstrings.already_exists, 200, 200);

    } catch (e) {
      console.log(e)
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /*
  *@Method GET
  *@role Get Coupon Detail
  */
  view: async(req,res,next) => {
    var id = req.params.id;
    try {
      const findData = await COUPAN.findOne({
        where :{id: id }
      });
      let sessionData = req.session.userData;
      const findDataCategory = await subject.findAll({
      where :{companyId :sessionData.id}
      });
      return res.render('pages/admin/coupans/viewCoupan',{data:findData , catData : findDataCategory});
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /*
  *@Method GET
  *@role Delete Coupon Detail
  */
  delete: async(req,res,next) => { 
    try{
      const numAffectedRows = await COUPAN.destroy({
        where: {
          id: req.params.id
        }
      })  
      return helpers.jsonResponse(res,true,{},appstrings.delete_success, 200, 200);
    }catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *@Method POST
  *@role Change Coupon Status Active/Block
  */
  status: async(req,res,next) => {
    var params=req.body
    try{
      let responseNull=  commonMethods.checkParameterMissing([params.id,params.status])
      if(responseNull) return responseHelper.post(res, appstrings.required_field,null,400);
      const userData = await COUPAN.findOne({
        where: {
          id: params.id 
        }
      });
       
      if(userData)
      {
        var status=0
        if(params.status=="0")  status=1
        const updatedResponse = await COUPAN.update({
            status: status,
          },
          {
            where : {
            id: userData.dataValues.id
          }
        });
         
        if(updatedResponse)
        {
          return helpers.jsonResponse(res,true,updatedResponse,appstrings.success, 200, 200);
        }
        else{
          return helpers.jsonResponse(res,false,updatedResponse,appstrings.oops_something, 400, 400);
        }
      }
      else{
        return helpers.jsonResponse(res,false,updatedResponse,appstrings.no_record, 204, 204);
      }
    }
      catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *@Method POST
  *@role Update Coupon Details
  */
  update: async (req, res) => {
    try {
      const data = req.body;
      var icon="";
      var thumbnail="";
      if (req.files) {
        ImageFile = req.files.icon;    
        if(ImageFile)
        {
          icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
          ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
              //upload file
              if (err)
              return helpers.jsonResponse(res, false, {}, err.message, err.code, 400);
          });
        }
      }
      const user = await COUPAN.findOne({
        attributes: ['id'],

        where: {
          id: data.coupanId

        }
      });
      if (user) {
        if(icon=="") icon=user.dataValues.icon
        const users = await COUPAN.update({
          name: data.name,
          type: data.type,
          code: data.code.toUpperCase(),
          discount: data.discount,
          icon: icon,
          usageLimit: '0',
          thumbnail: icon,
          description:data.description,
          validupto:data.validupto,
          minimumAmount:data.minimumAmount,
	 subjectId:data.subjectId,
        },
        {
          where:{
            id: data.coupanId
          }
        });
        if (users) {
          return helpers.jsonResponse(res,true,{},appstrings.update_success, 200, 200);
        }
       else  return helpers.jsonResponse(res,true,{},appstrings.unable_update, 200, 200);

      }
        else  return helpers.jsonResponse(res,true,{},appstrings.no_record, 200, 200);

    } catch (e) {
     // console.log(e)
     return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  }

};
