
const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model          = require("../../models/index");
const jwt            = require('jsonwebtoken');
const helpers        = require("../../helpers");
const hashPassword   = require('../../helpers/hashPassword');
const responseHelper = require("../../helpers/responseHelper");
const common         = require('../../helpers/common');
const moment         = require('moment');
const DOCUMENT       = model.documents;

CONTACTUS.belongsTo(userDetail,{foreignKey: 'userId'})
module.exports = {
  /**
  *@Method GET
  *@role Contact List
  */
  list: async(req,res,next) => {
    try{
      const findData = await CONTACTUS.findAll({
        where: {
          companyId: req.id,
          deleteStatus : 0 
        }
      })
      // console.log("here !!!!!!!!!!!!!" ,findData)
      return res.render('pages/admin/contactUs/contactusList',{data:findData});
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  
  getlist: async(req,res) => { 
  
    try {
      var params=req.body
       var fromDate =  ""
      var toDate =  ""
      var page =1
      var limit =50
      var orderby='createdAt'
      var orderType='ASC'
      let status = [0,1]
      if(params.page) page=params.page
      if(params.limit) limit=parseInt(params.limit)
      var offset=(page-1)*limit
      where={
        // readStatus: { [Op.or]: ['0','1']},
        deleteStatus : 0,
         }
         var whereUser={}
      if(params.status){
        if(params.status==5 ){
          where.status = status
        }else{
          where.status = params.status
        }
      }else{
        where.status = status
      }
          if(params.search && params.search!="")
          {
           where={ [Op.or]: [
              {query: {[Op.like]: `%${params.search}%`}},
              {email: { [Op.like]: `%${params.search}%` }},
              {phoneNumber: { [Op.like]: `%${params.search}%` }},
              {'$userDetail.fName$':{ [Op.like]: `%${params.search}%` }},
              {'$userDetail.lName$':{ [Op.like]: `%${params.search}%` }},
            ],
            deleteStatus : 0,
          }
    }
    where.companyId=req.id
          const findData = await CONTACTUS.findAndCountAll({
          where :where,
          include: [
            { model: userDetail, attributes: ['fName','lName']},
          ],
          // order: [[orderby,orderType]],
          offset: offset, limit: limit ,
          // distinct:true,
        });
    return helpers.jsonResponse(res, true, findData, appstrings.success, 200, 200);
      } catch (e) {
        console.log(e)
        return responseHelper.error(res, e.message, 400);
      }
    },

    deleteContacts: async(req,res) => { 
      try {
        const numAffectedRows = await CONTACTUS.update({
          deleteStatus:1
        },{
          where: {
            id: req.body.ids
          }
        })  
        return helpers.jsonResponse(res,true,numAffectedRows,appstrings.delete_success, 200, 200);
      }catch (e) {
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
      } 
    },
    updateStatus:async(req,res)=>{
      try {
        let status =parseInt( req.body.status )
        const numAffectedRows = await CONTACTUS.update({
          status: status
        },{
          where: {
            id: req.body.ids
          }
        })  
        return helpers.jsonResponse(res,true,numAffectedRows,appstrings.resolved_success, 200, 200);
      }catch (e) {
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
      } 
    }
};
