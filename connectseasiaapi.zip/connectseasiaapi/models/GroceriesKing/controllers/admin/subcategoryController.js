const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model          = require("../../models/index");
const jwt            = require('jsonwebtoken');
const helpers        = require("../../helpers");
const hashPassword   = require('../../helpers/hashPassword');
const responseHelper = require("../../helpers/responseHelper");
const common         = require('../../helpers/common');
const DOCUMENT       = model.documents;
const moment         = require('moment');
const COUPAN         = model.coupan;
const category       = model.subjects;
const subCategory    = model.subCategories;
const teacherSubject = model.teacherSubjects
const user			= model.users	
const userDetail          = model.userDetail;
teacherSubject.belongsTo(user,{ as:'teacher' });
subCategory.belongsTo(category,{foreignKey:'subjectId'});
module.exports = {

	//////////////////////////////// Sub Category Listing /////////////////////////////
	SubCategoryListing: async(req,res) => {
		try {
			let SessionData = req.session.userData;
			let companyId      = SessionData.id;
			let data        = await subCategory.findAll({
				attributes: ['id','name'],
				include: [{
		            model: category,
		            attributes: ['id','name'],
		            where: {
		            	companyId: companyId
		            },
		            required: true
		          }
		        ]
			});
			return res.render('pages/admin/subCategory/list',{data});
		} catch (e) {
			console.log('Error => ', e);
      		return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	////////////////////////////////Add Sub Category/////////////////////////////////////
  	addSubCategory: async (req, res) => {
	    try {
	      	let SessionData = req.session.userData;
			let companyId   = SessionData.id;
			let data        = await category.findAll({
				attributes: ['id','name'],
				where: {
					companyId: companyId
				}
			});
	      	return res.render('pages/admin/subCategory/add',{data});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	///////////////////////////// Post Add Sub Category /////////////////////
  	postAddSubCategory: async (req, res) => {
  		try {
	      	let SessionData = req.session.userData;
			let userId      = SessionData.id;
			const data      = req.body;
			
			var icon = "";
	      	if (req.files) {
		        ImageFile = req.files.icon;    
		        if(ImageFile)
		        {
					
		          icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");

		          ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
		              //upload file
		              if (err)
		              return helpers.jsonResponse(res, false, {}, err.message, err.code, 400);  
		          });
		        }else console.log('no image')
	      	}
			const response = await subCategory.create({
				subjectId: data.subjectId,
			  	name: data.serviceName,
			  	image: icon
			});
			return helpers.jsonResponse(res, true, response, appstrings.success, 200, 200);
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	//////////////////////////////// Delete Sub Category /////////////////////////////
	deleteSubCategory: async(req,res) => {
		try {
			let SessionData = req.session.userData;
			let userId      = SessionData.id;
			const params    = req.params;

			// const numAffectedRows = await subCategory.destroy({
			//  	where: {
			//     	id: params.id
			//   	}
			// });  

				const numAffectedRows = await subCategory.update(
				{
					isDeleted:1
				},	
				{
			 	where: {
			    	id: params.id
			  	}
			});
			return helpers.jsonResponse(res,true,{},appstrings.delete_success, 200, 200);
		} catch (e) {
			console.log('Error => ', e);
      		return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	//////////////////////////////// Get Sub Category /////////////////////////////
	getSubCategory: async(req,res) => {
		try {
			let SessionData = req.session.userData;
			let companyId      = SessionData.id;
			const params    = req.params;
			let Categorydata = await category.findAll({
				attributes: ['id','name'],
				where: {
					companyId: companyId
				}
			});
			let data = await subCategory.findOne({
				where: {
					id: params.id
				}
			});
			return res.render('pages/admin/subCategory/edit',{data,Categorydata});
		} catch (e) {
			console.log('Error => ', e);
      		return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	//////////////////////////////// Update Category /////////////////////////////
	updateSubCategory: async(req,res) => {
		try {
			const params = req.body;
			let data        = await subCategory.findOne({
				where: {
					id: params.subCategoryId
				}
			});
			if(data)
			{
				var icon = "";
		      	if (req.files) {
			        ImageFile = req.files.icon;    
			        if(ImageFile)
			        {
			          icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");

			          ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
			              //upload file
			              if (err)
			              return helpers.jsonResponse(res, false, {}, err.message, err.code, 400);   
			          });
			        }
		      	}

				if(req.files)
				{
					const updatedResponse = await subCategory.update({
						subjectId: params.subjectId,
					  	name: params.name,
					  	image: icon
					},
					{
					  where : {
						  	id: params.subCategoryId
						}
					});
				}else{
					let fields = {
						subjectId: params.subjectId,
					  	name: params.name
					}
					if(params.issubimageEdited==1){//image removed
						fields.image=''
					}

					const updatedResponse = await subCategory.update(fields,
					{
					  where : {
						  	id: params.subCategoryId
						}
					});
				}
				return helpers.jsonResponse(res, true, {}, appstrings.update_success, 200, 200);
			}else{
				return helpers.jsonResponse(res, false, {}, appstrings.unable_update, 204, 204);
			}
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);  
		}
	},
	//////////////////////////////// Get Sub All Category /////////////////////////////
	getAllSubCategory: async(req,res) => {
		try {
			const params     = req.params;
			let Categorydata = await subCategory.findAll({
				attributes: ['id','name','image','status','subjectId'],
				where: {
					subjectId: params.id,
					isDeleted:0
				}
			});
			return helpers.jsonResponse(res, true, Categorydata, appstrings.success,200, 200); 
		} catch (e) {
			console.log('Error => ', e);
      		return helpers.jsonResponse(res, false, {}, e.message, e.code, 400); 
		}
	},
	professionals:async(req,res)=>{
		try {
			let result = []
			const params     = req.params;
			
			let Categorydata = await teacherSubject.findAll({
				attributes: ['id','subjectId','subCategoryId','teacherId'],
				where: {
					// subCategoryId: { [Op.in]:params.id },
					// companyId: req.id
					subjectId:params.subject
				},
				include:[{ 
					model:user,
					attributes:['email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = teacher.id)'), 'totalRating']],
					as:'teacher',
					include: [{
						model: userDetail,
						attributes: ['fName','lName','status','image'],
					}]
				  }]
			});
			// let results = commonMethods.getSubCategoryProfessionals(Categorydata,subCategory)
			Categorydata = JSON.parse(JSON.stringify(Categorydata))
			// console.log('data--> ',Categorydata)
			for (var k = 0; k < Categorydata.length; k++) {

				if (Categorydata[k].subCategoryId.includes(params.id)){
					result.push(Categorydata[k])
				}
						
				//   delete Categorydata[k];
					}
		  
			return helpers.jsonResponse(res, true, result, appstrings.success,200, 200); 
		} catch (e) {
			console.log('Error => ', e);
      		return helpers.jsonResponse(res, false, {}, e.message, e.code, 400); 
		}

	},
	status:async(req,res)=>{
			var params=req.body
			try{
			  let responseNull=  commonMethods.checkParameterMissing([params.id,params.status])
			  if(responseNull) return responseHelper.post(res, appstrings.required_field,null,400);
			  const userData = await subCategory.findOne({
				where: {
				  id: params.id 
				}
			  });
			  if(userData)
			  {
				var status=0
				if(params.status==0)  status=1
				const updatedResponse = await subCategory.update({
					status: status,
				  },
				  {
					where : {
					id: userData.dataValues.id
				  }
				});
				if(updatedResponse)
				{
				  return responseHelper.post(res, appstrings.sub_category_status,updatedResponse);
				}
				else{
				  return responseHelper.post(res, appstrings.sub_category_disabled_issue,null,400);
				}
			  }
			  else{
				return responseHelper.post(res, appstrings.no_record,null,204);
			  }
			}
			  catch (e) {
			  return responseHelper.error(res, e.message, 400);
			}
	}

}