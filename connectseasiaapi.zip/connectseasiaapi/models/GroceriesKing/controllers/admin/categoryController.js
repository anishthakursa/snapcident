
const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model          = require("../../models/index");
const jwt            = require('jsonwebtoken');
const helpers        = require("../../helpers");
const hashPassword   = require('../../helpers/hashPassword');
const responseHelper = require("../../helpers/responseHelper");
const common         = require('../../helpers/common');
const moment         = require('moment');
const DOCUMENT       = model.documents;
const COUPAN         = model.coupan;
const subject        = model.subjects;
module.exports = {
  /**
  *@Method GET
  *@role Category List
  */
  list: async(req,res,next) => {
    let sessionData = req.session.userData;
    try{
      let sessionData = req.session.userData;
      const findData = await subject.findAll({
        where :{companyId :sessionData.id}
      });
      return res.render('pages/admin/category/categoryListing',{data:findData});
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *@Method GET
  *@role Add New Category
  */
  add: async(req,res,next) => {
    try{
      return res.render('pages/admin/category/addCategory');
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  postAdd: async (req, res) => {
    try {
      const data = req.body;
       let sessionData = req.session.userData;
      var icon = "";
      var thumbnail = "";
     
      if (req.files) {
        ImageFile = req.files.icon;    
        if(ImageFile)
        {
          icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");

          ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
              //upload file
              if (err)
              return helpers.jsonResponse(res, false, {}, err.message, err.code, 400);   
          });
        }
      }
      
      const user = await subject.findOne({
        attributes: ['id'],
        where: {
          name: data.name,
          companyId :sessionData.id,
isDeleted:0
        }
      });
      if (!user) {
        let sessionData = req.session.userData;
        const users = await subject.create({
          name: data.name,
          companyId :sessionData.id,
          image: icon
        });
        return helpers.jsonResponse(res,true,users,appstrings.added_success, 200, 200);
  
      }
        else  return helpers.jsonResponse(res,true,{},appstrings.already_exists, 200, 200);

    } catch (e) {
      console.log(e)
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /*
  *@Method GET
  *@role Get Category Detail
  */
  view: async(req,res,next) => {
    var id = req.params.id;
    try {
      const findData = await subject.findOne({
        where :{id: id }
      });
      return res.render('pages/admin/category/viewCategory',{data:findData});
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /*
  *@Method GET
  *@role Delete Category Detail
  */
  delete: async(req,res,next) => { 
    try{
      // const numAffectedRows = await subject.destroy({
      //   where: {
      //     id: req.params.id
      //   }
      // })  
      const numAffectedRows = await subject.update({
        isDeleted:1
      },{
        where: {
          id: req.params.id
        }
      })  
      return helpers.jsonResponse(res,true,numAffectedRows,appstrings.delete_success, 200, 200);
    }catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *@Method POST
  *@role Change Coupon Status Active/Block
  */
  status: async(req,res,next) => {
    var params=req.body
    try{
      let responseNull=  commonMethods.checkParameterMissing([params.id,params.status])
      if(responseNull) return responseHelper.post(res, appstrings.required_field,null,400);
      const userData = await subject.findOne({
        where: {
          id: params.id 
        }
      });
       
      if(userData)
      {
        var status=0
        if(params.status==0)  status=1
       
        const updatedResponse = await subject.update({
            status: status,
          },
          {
            where : {
            id: userData.dataValues.id
          }
        });
         
        if(updatedResponse)
        {
          return responseHelper.post(res, appstrings.success,updatedResponse);
        }
        else{
          return responseHelper.post(res, 'Something went Wrong',null,400);
        }
      }
      else{
        return responseHelper.post(res, appstrings.no_record,null,204);
      }
    }
      catch (e) {
      return responseHelper.error(res, e.message, 400);
    }
  },

  /**
  *@Method POST
  *@role Update Category Details
  */
  update: async (req, res) => {
    try {
      const data = req.body;
      var icon="";
      var thumbnail="";
      console.log('recieved from the data-->',data)
      if (req.files) {
        ImageFile = req.files.icon;    
        if(ImageFile)
        {
          icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
          ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
              //upload file
              if (err)
              return helpers.jsonResponse(res, false, {}, err.message, err.code, 400); 
          });
        }else{
          icon=""
        }
      }
      const user = await subject.findOne({
        attributes: ['id'],

        where: {
          id: data.categoryId

        }
      });
    
      if (user) {
        if( icon=="" && data.isimageEdited==0 ){
          var users = await subject.update({
            name: data.name
          },
          {
            where:{
              id: data.categoryId
            }
          });
        }else{
          var users = await subject.update({
            name: data.name,
            image: icon
          },
          {
            where:{
              id: data.categoryId
            }
          });
        }
        
        if (users) {
          return helpers.jsonResponse(res,true,{},appstrings.update_success, 200, 200);
        }
       else  return helpers.jsonResponse(res,true,{},appstrings.unable_update, 200, 200);

      }
        else  return helpers.jsonResponse(res,true,{},appstrings.no_record, 200, 200);

    } catch (e) {
     // console.log(e)
     return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
 /**
  *@Method GET
  *@role get category participants
  */
 professionals:async (req,res)=>{
  const category = req.params.id
  return helpers.jsonResponse(res,true,category,appstrings.success, 200, 200);
 },
 catalog:async(req,res)=>{
  try{
    
    let sessionData = req.session.userData;
      const findData = await subject.findAll({
        where :{
          companyId :sessionData.id,
          isDeleted:0
        
        }
      });
      return res.render('pages/admin/category/catalog',{ data:findData });
  }catch(e){
    return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
  }
 },

};
