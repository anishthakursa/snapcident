
const config          = require('config');
const sequelize       = require('sequelize');
const Op              = require('sequelize').Op;
const model           = require("../../models/index");
const jwt             = require('jsonwebtoken');
const helpers         = require("../../helpers");
const hashPassword    = require('../../helpers/hashPassword');
const responseHelper  = require("../../helpers/responseHelper");
const common          = require('../../helpers/common');
const moment          = require('moment');
const users           = model.users;
const DOCUMENT        = model.documents
const userDetail      = model.userDetail;
const userRedeemption = model.userRedeemptions;
const SUBSCRIPTION    = model.subscription;
const SUBDURATION     = model.subscriptionDuration;
SUBSCRIPTION.hasMany(SUBDURATION, {foreignKey: 'subId'});
module.exports = {
  /**
  *@role Get Login Page
  *@Method POST
  */
  list: async (req, res) => {
    try {
      let SessionData = req.session.userData;
      let companyId      = SessionData.id;
      const findData = await SUBSCRIPTION.findAll({
        where : { companyId :companyId },
        include:[{model:SUBDURATION,attributes:['id','price','duration']}]
      });
      return res.render('pages/admin/subscription/list',{findData});
    } catch (e) {
       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *@role Get Login Page
  *@Method POST
  */
  add: async (req, res) => {
    try {
      return res.render('pages/admin/subscription/add');
    } catch (e) {
       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },


  /**
  *@role Get Login Page
  *@Method POST
  */
  postadd: async (req, res) => {
    try {
    const data = req.body;
    let SessionData = req.session.userData;
    var companyId      = SessionData.id;
    const user = await SUBSCRIPTION.findOne({
      attributes: ['id'],
      where: {
      [Op.or]:[
      {name: data.name},
      {companyId: companyId}
      ]
    }});
    if (!user) {
      if(Array.isArray(data.feature))
      {
        var newFea = data.feature;
      }else
      {
        var  newFea = data.feature.split();
      }
      const users = await SUBSCRIPTION.create({
        name: data.name,
        credit: data.credit,
        companyId: companyId,
        features: JSON.stringify(newFea)
      });
      if (users) {

        if(Array.isArray(data.duration))
        {
          var duration = data.duration;
          var price = data.price;
        }
        else
        {
          var  duration = data.duration.split();
          var  price = data.price.split();
        }
        for(var k=0;k<duration.length;k++)
        {

          if(duration[k]!="" && price[k]!="")
          { 
            await SUBDURATION.create({
              subId: users.id,
              price: price[k],
              duration: duration[k],
              companyId: companyId,
            });
          }
        }
        return helpers.jsonResponse(res, true, {}, appstrings.success, 200, 200);
      }
      else  {
        return helpers.jsonResponse(res, true, {}, appstrings.already_exists, 201, 201);
      }

    }
    else  return helpers.jsonResponse(res, true, {}, appstrings.already_exists, 201, 201);

    } catch (e) {
      console.log(e)
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *@role Delete Plan
  *
  */
  delete: async (req, res) => {
    try{
      //console.log(pool.format('DELETE FROM `reminders` WHERE `reminder_id` = ?', [req.params.id]));
      const numAffectedRows = await SUBSCRIPTION.destroy({
        where: {
          id: req.params.id
        }
        })  
        return redirect('/subscriptions');
      }catch (e) {
       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
      }
  },

  /**
  *@role View Details
  *
  */
  view: async (req, res) => {
    var id=req.params.id
    try {
    
      const findData = await SUBSCRIPTION.findOne({
        where :{ id: id },
        include:[{model:SUBDURATION,attributes:['id','price','duration']}]
           
      });
      return res.render('pages/admin/subscription/view',{data:findData});
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *@role View Details
  *
  */
  update: async (req, res) => {
  try {
    const data = req.body;

    let SessionData = req.session.userData;
    var companyId      = SessionData.id;
    const user = await SUBSCRIPTION.findOne({
      where: {
        id:data.planId,
        companyId: companyId

      }
    });

    if(Array.isArray(data.feature))
    {
      var newFea = data.feature;
    }else
    {
      var  newFea = data.feature.split();
    }

    if (user) {
      
    
      const users = await SUBSCRIPTION.update({
        name: data.name,
        credit: data.credit,
        features: JSON.stringify(newFea)
       },

      { where:
       {
        id: data.planId,
        companyId: companyId
       }
      }
       
       );


      if (users) {


        await SUBDURATION.destroy({where:{subId:data.planId}})

        if(Array.isArray(data.duration))
        {
          var duration = data.duration;
          var price = data.price;

        }else
        {
          var  duration = data.duration.split();
          var  price = data.price.split();

        }

        for(var k=0;k<duration.length;k++)
        {
          if(duration[k]!="" && price[k]!="")
          { 
          await SUBDURATION.create({
            subId: data.planId,
            price: price[k],
            duration: duration[k],
            companyId: companyId,
          });
          }

        }
        return helpers.jsonResponse(res, true, {}, appstrings.update_success, 200, 200);
       
      }


    }
      else {
        return helpers.jsonResponse(res, false, {}, appstrings.unable_update, 204, 204);
      }

    

  } catch (e) {
    return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
  }
  }

}
