const config               = require('config');
const model                = require("../../models/index");
const jwt                  = require('jsonwebtoken');
const hashPassword         = require('../../helpers/hashPassword');
const responseHelper       = require("../../helpers/responseHelper");
const sequelize            = require('sequelize');
const common               = require('../../helpers/common');
const Op                   = require('sequelize').Op;
const moment               = require('moment');
const helpers              = require("../../helpers");


userDetail.belongsTo(Users,{foreignKey:'userId'})
adminCredit.belongsTo(Users,{foreignKey: 'professionalId'});
adminCredit.belongsTo(Users,{as: 'customer'});
adminCredit.belongsTo(subject,{foreignKey: 'categoryId'});
TeacherBooking.hasOne(bookingNotification,{foreignKey:'bookId'})
bookingNotification.belongsTo(TeacherBooking,{foreignKey:'bookId'})
TeacherBooking.belongsTo(StudentbookingDetail,{foreignKey:'bookingId',targetKey:'id'})
var  months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
module.exports = {
    getCategoryRenuve: async(req,res) => {
        try {
          const MainArray = [];
          const companyId = req.session.userData.id;
          //Avg Renve
          var featured = await subject.findAll({
            attributes: ['id','name','image'],
            where:{
              companyId: companyId
            }
          });
          for (var i = 0; i < featured.length; i++) 
          {
            var array = {};
            var id = featured[i].id;
             //Total Revnue
             var name = featured[i].name;
            array.label = name;
             
            var totalRevenue = await TeacherBooking.findOne({
              attributes: [
                [sequelize.fn('sum', sequelize.col('credit')), 'totalAmount'],
              ],
              where: {
                subjectId: id
              }
            });
            if(totalRevenue.dataValues.totalAmount == null)
            {
              console.log("0")
            }else{
              array.data = totalRevenue.dataValues.totalAmount;
              MainArray.push(array);
            }
          }
          return helpers.jsonResponse(
            res,
            true,
            MainArray,
            appstrings.success,
            200,
            200
          );
        } catch (e) {
          console.log('Error => ', e);
          return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
      },
      getStatics:async(req,res)=>{
        try{
          //fromDate1,toDate1,progressStatus1,filterName,companyId,parentCompany
        const params = req.body;
        const companyId = req.session.userData.id
        var fromDate1=params.fromDates
        var toDate1=params.toDates
        var date = new Date();
        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        var progressStatus1
        var filterName= params.filterName
         var year = params.year;
        var fromDate = moment().startOf('year');
        var fromDateMonth = new Date(fromDate);
        var fromMonth = (fromDateMonth.getMonth()+ 1) < 10 ? '0' + (fromDateMonth.getMonth()+1) : (fromDateMonth.getMonth()+1);

        if(filterName && filterName!="")
        {
          if(filterName=="MONTH")  filterNameMain= [sequelize.literal(`MONTH(creditDate)`), 'MONTH']
          if(filterName=="YEAR")  filterNameMain= [sequelize.literal(`YEAR(creditDate)`), 'YEAR']
          if(filterName=="WEEK")  {
            
            filterNameMain= [sequelize.literal(`WEEK(creditDate)`), 'WEEK']
            orderWhere={
              // companyId: companyId,
              status: 1,
              creditDate: { [Op.lte]: lastDay,[Op.gt]: firstDay}
            }
        }
        if(filterName=="DAY")  {
          filterNameMain= [sequelize.literal(`DAY(creditDate)`), 'DAY']
          orderWhere={ 
            status: 1,
            creditDate: { [Op.lte]: lastDay,[Op.gt]: firstDay}
          }
      }

      console.log('--> in calculation mode')
        } 
        if(fromDate1) fromDate= Math.round(new Date(fromDate1).getTime())
        if(toDate1) toDate= Math.round(new Date(toDate1).getTime())
        if(fromDate1!="" && toDate1!="")
      {
        orderWhere={ creditDate: { [Op.gte]: new Date(fromDate1),[Op.lte]: new Date(toDate1)},
        status: 1
      }
        // orderWhereParent={progressStatus: { [Op.or]: progressStatus},createdAt: { [Op.gte]: fromDate,[Op.lte]: toDate}} 
      }
      orderWhere.companyId = companyId
      var ordersDataqDepth = await adminCredit.findAll({
        attributes: ['status','creditDate','createdAt',
                    [sequelize.fn('sum', sequelize.col('commission')), 'total_amount'],
                    filterNameMain,
                    [sequelize.fn('COUNT', sequelize.col('status')), 'count']],
                    group: [filterNameMain],
                     where :orderWhere,
                     order:[ ['createdAt','ASC'] ]
                  });   
        return helpers.jsonResponse(
          res,
          true,
          ordersDataqDepth,
         appstrings.result_fetched_success,
          200,
          200
        );
      } catch (e) {
       
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
      }

      },
       getYearlyRevenue: async(req,res) => {
        try {
          const params = req.body;
          const companyId = req.session.userData.id;
           var year = params.year;
          var fromDate = moment().startOf('year');
          var fromDateMonth = new Date(fromDate);
          filterName='MONTH'
          var fromMonth = (fromDateMonth.getMonth()+ 1) < 10 ? '0' + (fromDateMonth.getMonth()+1) : (fromDateMonth.getMonth()+1);
    

          if(filterName && filterName!="")
          {
            if(filterName=="MONTH")  filterNameMain= [sequelize.literal(`MONTH(createdAt)`), 'MONTH']
            if(filterName=="YEAR")  filterNameMain= [sequelize.literal(`YEAR(createdAt)`), 'YEAR']
            if(filterName=="WEEK")  {
              
              filterNameMain= [sequelize.literal(`WEEK(createdAt)`), 'WEEK']
              orderWhere={
                companyId: companyId,
                progressStatus: { [Op.or]: progressStatus},
                createdAt: { [Op.lte]: lastDay,[Op.gt]: firstDay}
              }
          }
          if(filterName=="DAY")  {
            filterNameMain= [sequelize.literal(`DAY(createdAt)`), 'DAY']
            orderWhere={companyId: companyId,
              progressStatus: { [Op.or]: progressStatus},
              createdAt: { [Op.lte]: lastDay,[Op.gt]: firstDay}
            }
        }
          } 


          const MainArray = [];
          //Avg Renve
          var featured = await subject.findAll({
            attributes: ['id','name','image'],
            where:{
              companyId: companyId,
		 status:1,
                isDeleted:0
            }
          });
          for (var i = 0; i < featured.length; i++) 
          {
            var array = {};
            var id = featured[i].id;
             //Total Revnue
            var name = featured[i].name;
            array.name = name;
             
            var newArray = [];
            var year = params.year;
           
            // console.log(JSON.parse(JSON.stringify(creditHistory)))
    
            for(var j=1;j<=12;j++){
              var totalYearlyRevenue = await adminCredit.findOne({
                attributes: [
                  [ sequelize.fn('MONTH', sequelize.col('creditDate')), 'data'],
                  [sequelize.fn('sum', sequelize.col('commission')), 'total_amount'],
    
                ],
                where: {
                  [Op.and]: [
                    sequelize.where(sequelize.fn('YEAR', sequelize.col('creditDate')), year),
                    sequelize.where(sequelize.fn('MONTH', sequelize.col('creditDate')), j),
                    {categoryId: id},
                  ]
                }
              });
              if(totalYearlyRevenue.dataValues.total_amount == null)
              {
                newArray.push(0);
              }else{
                newArray.push(parseInt(totalYearlyRevenue.dataValues.total_amount));
              }
            }
            array.data = newArray;
            MainArray.push(array);
          }
         
           // console.log(MainArray);
          return helpers.jsonResponse(
            res,
            true,
            MainArray,
            appstrings.success,
            200,
            200
          );
        } catch (e) {
          // console.log('Error => ', e);
          return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
      },
      getCreditHistory:async(req,res)=>{
    try{
     
      let year = req.params.year
            let creditHistory = await adminCredit.findAll({
             
            include:[{
              model: Users,attributes:['id','email'],
              include:{model:userDetail,attributes:['fName','lName']}
            },
            {model:Users,as:'customer', include:{model:userDetail,attributes:['fName','lName']}},
            {
              model:subject,
              attributes:['id','name']
            }
          ],
          where: {
            companyId:req.id,
            [Op.and]: [
              sequelize.where(sequelize.fn('YEAR', sequelize.col('creditDate')), year),
            ]
          }
            })
             // console.log(MainArray);
             return helpers.jsonResponse(
              res,
              true,
              creditHistory,
              appstrings.credit_history_success,
              200,
              200
            );
          } catch (e) {
            console.log('Error => ', e);
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
          }
      },
      getTeacherYearlyRevenue: async(req,res) => {
        try {
          let result = []
          const params = req.body;
        
           var year = params.year;
           var professionalId = params.teacherId?params.teacherId:''
           if(!professionalId){
            return helpers.jsonResponse(res, false, {},appstrings.professionalId_absent, 400, 400);
           }
         
          var fromDate = moment().startOf('year');
          var fromDateMonth = new Date(fromDate);
          var fromMonth = (fromDateMonth.getMonth()+ 1) < 10 ? '0' + (fromDateMonth.getMonth()+1) : (fromDateMonth.getMonth()+1);
    
          const MainArray = [];
          const MainArray1 = [];
            var array = {};
            let array1 = { name: "Bookings" ,type: 'spline'}
            let array2 = { name:"Months" }
            let array2Data = []
            // var id = featured[i].id;
            var id = professionalId
             //Total Revnue
            // var name = featured[i].name;
            array.name = "Credit Earned";
            var newArray = [];
            let bookingsdata = []
            var year = params.year;
            // console.log('  -> ')
            // console.log(JSON.parse(JSON.stringify(totalbookings)))
            for(var j=1;j<=12;j++){
              var totalbookings = await bookings.findOne({
                attributes: [
                  [ sequelize.fn('MONTH', sequelize.col('bookingDate')), 'data' ],
                  [ sequelize.fn('count', sequelize.col('id')), 'total_bookings' ],
                ],
                where: {
                  [Op.and]: [
                    sequelize.where(sequelize.fn('YEAR', sequelize.col('bookingDate')), year),
                    sequelize.where(sequelize.fn('MONTH', sequelize.col('bookingDate')), j),
                    { teacherId: professionalId },
                  ]
                },
             
              })
              if(totalbookings.dataValues.total_bookings == null)
              {
                bookingsdata.push(0);
              }else{
                bookingsdata.push(parseInt(totalbookings.dataValues.total_bookings));
              } 
              var totalYearlyRevenue = await adminCredit.findOne({
                attributes: [
                  [ sequelize.fn('MONTH', sequelize.col('creditDate')), 'data'],
                  [sequelize.fn('sum', sequelize.col('commission')), 'total_amount'],
    
                ],
                where: {
                  companyId:req.id,
                  [Op.and]: [
                    sequelize.where(sequelize.fn('YEAR', sequelize.col('creditDate')), year),
                    sequelize.where(sequelize.fn('MONTH', sequelize.col('creditDate')), j),
                    { professionalId: professionalId },
                  ]
                }
              });
              if(totalYearlyRevenue.dataValues.total_amount == null)
              {
                newArray.push(0);
              }else{
                newArray.push(parseInt(totalYearlyRevenue.dataValues.total_amount));
              }
              array2Data.push({
                name: months[j-1],
                y:totalYearlyRevenue.dataValues.total_amount?totalYearlyRevenue.dataValues.total_amount:0,
             })
            }
            let ratingStat = []
            let overallRating = await ratings.findOne({where:{teacherId:professionalId}})
            
            if(overallRating && overallRating.dataValues){
              console.log(overallRating.dataValues.professionalBehavior,
                overallRating.dataValues.rating,
                overallRating.dataValues.professionalKnow
                )
              ratingStat.push(
               
                {
                  name: 'behaviour',
                  data: [(overallRating.dataValues.professionalBehavior)?overallRating.dataValues.professionalBehavior:0]
                },
                {
                  name: 'knowledge',
                  data: [(overallRating.dataValues.professionalKnow)?overallRating.dataValues.professionalKnow:0]
                },
                {
                  name: 'video quality',
                  data: [(overallRating.dataValues.videoQuality)?overallRating.dataValues.videoQuality:0]
                }, {
                  name: 'rating',
                  data: [overallRating.dataValues.rating?overallRating.dataValues.rating:0]
                },
                )
              }
            //  date.toLocaleString('en-us', { month: 'short' });
            array1.data = bookingsdata
            array.data = newArray;
            array2.data = array2Data
              MainArray.push(array);
              MainArray.push(array1)
              MainArray1.push(array2Data)
            result.push(MainArray)
            result.push(array2Data)
            result.push(ratingStat)
              return helpers.jsonResponse(
            res,
            true,
            result,
            appstrings.success,
            200,
            200
          );
        } catch (e) {
          console.log('Error => ', e);
          return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
      },
      /////////////////////////// Admin Dashboard ////////////////////
      dashboard: async(req, res) => {
        try {
         
          const companyId = req.session.userData.id;
       
          //Avg Renve
    
          //Total Revnue
          const totalRevenue = await TeacherBooking.findOne({
            attributes: [
              [sequelize.fn('sum', sequelize.col('credit')), 'totalAmount'],
            ],
            where:{
              companyId: companyId
            }
          })
    
          //Total Booking
       var totalBooking = await TeacherBooking.count({
        where:{
          companyId: companyId
        }
      });    
          //Top 5 Professional
          var where={
            role: '2',
            companyId: companyId
          }
    
          var limit  = 5;
          var offset = 0;
          const MainArray = [];
    
          //Get Free Delivery Restuarant
          var featured = await subject.findAll({
            attributes: ['id','name','image'],
            where:{
              companyId: companyId
            }
          });
    
          for (var i = 0; i < featured.length; i++) 
          {
            var array = {};
            var id = featured[i].id;
            var name = featured[i].name;
            array.type = name;
            array.categoryId = id;
            var restDetails = await Users.findAll({
              attributes: ['id','email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = users.id)'), 'totalRating']],
              where: {
                  role : '2',
                  companyId: companyId
              },
              order: sequelize.literal(`totalRating DESC`),
              include: [
                  {
                      model: teacherSubject,
                      required: true,
                      attributes: [],
                      where: { 
                        subjectId: id
                      }
                  },
                  {
                      model: userDetail,
                      attributes: ['fName','lName','dob','image','uniqueId'],
                      required: true,
                      where: {
                          status: '1'
                      } 
                  }
              ],
              offset: offset, 
              limit: limit,
            });
            array.professional = restDetails;
            if(restDetails.length > 0)
            {
              MainArray.push(array);
            }
          }
    
          var MainArrayN = JSON.parse(JSON.stringify(MainArray));
    
          const userData = await Users.findAll({
            attributes: ['id','email',
            [sequelize.literal('(SELECT ROUND(AVG(rating),0) FROM ratings where teacherId = users.id)'), 'totalRating']],
            where: where,
            order: sequelize.literal(`totalRating DESC`),
            include: [{
              model: userDetail,
              attributes: ['fName','lName','status']
            }],
            limit:5, offset:0
          }); 
    
          //Total Categories
          var totalCategory = await subject.findAll({
            where:{
              companyId: companyId
            }
          });
    
          //Total Customer
          var totalCustomers = await Users.findAll({
            where: {
              role: '1',
              companyId: companyId
            }
          });
    
          //TotalProfessional
          var totalProfessional = await Users.findAll({
            where: {
              role: '2',
              companyId: companyId
            }
          });
    
          //Get Recent Bookings
          var newDate = moment(new Date()).format("YYYY-MM-DD");
         const usr = await TeacherBooking.findAll({
        attributes: ['bookingId','teacherId','status','subjectId','bookingDate'],
        where: {
          bookingDate: "2021-10-20",

        },
        include: [{
            model: StudentbookingDetail,
            attributes: ['id','studentId','bookingDate','timeSlot'],
            required: true,
          
            include: [{
              model: userDetail,
              attributes: ['fName','lName','image']
            }]
        }]
      });     
          var usrArray = [];
          for(var k=0;k<usr.length;k++)
          {
            var array = {};
    
            array.bookingDate  = usr[k].bookingDetail.bookingDate;
            array.timeSlot     = usr[k].bookingDetail.timeSlot;
            //Get Student Name
            var stuentNmae = await userDetail.findOne({
              attributes: ['fName','lName'],
              where: {
                userId: usr[k].bookingDetail.studentId
              }
            });
            array.sName     = stuentNmae.dataValues.fName+ ' ' +stuentNmae.dataValues.lName;
            //Get Teacher Details
            var teacherName = await userDetail.findOne({
              attributes: ['fName','lName'],
              where: {
                userId: usr[k].teacherId
              }
            });
            array.tName     = teacherName.dataValues.fName+ ' ' +teacherName.dataValues.lName;
            //Get Category Details
            var categoryName = await subject.findOne({
              attributes: ['id','name','image'],
              where:{
                companyId: companyId
              }
            });
            array.category     = categoryName.dataValues.name;
            usrArray.push(array);
          }
          
          //Get Revenue All Categories
          var data = {};
          data.totalCustomers = totalCustomers;
          data.totalProfessional = totalProfessional;
          data.totalCategory = totalCategory;
          data.totalBooking = totalBooking;
          data.userData = userData;
          data.CategoryProfessional = MainArrayN;
          data.totalRevenue = totalRevenue.dataValues.totalAmount;
    
          return res.render('pages/admin/dashboard',{data,usrArray,moment});
        } catch (e) {
          console.log('Error => ', e);
          return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
      },
    
    newdashboard:async(req,res)=>{
    try{
        
      const companyId = req.session.userData.id;
     
      //Avg Renve
    
      //Total Revnue
      const totalRevenue = await TeacherBooking.findOne({
        attributes: [
          [sequelize.fn('sum', sequelize.col('credit')), 'totalAmount'],
        ],
        where:{
          companyId: companyId
        }
      })
    
      //Total Booking
     /* var totalBooking = await TeacherBooking.count({
        where:{
          companyId: companyId
        }
      }); */

	 var totalBookingFromBooking = await TeacherBooking.count({
          where:{
            companyId: companyId
          },
          include:
            {
              required:false,
              model: bookingNotification,
          }
        });  
        var totalBookingFromNotification= await bookingNotification.count({
          where:{
            companyId: companyId,
          },
          include:
            {
              required:false,
              model: TeacherBooking,
              where:{bookingId:{ [Op.ne]:null }}
          }
        }); 
        let totalBooking =  totalBookingFromBooking+totalBookingFromNotification

    
      //Top 5 Professional
      var where={
        role: '2',
        companyId: companyId
      }
    
      var limit  = 5;
      var offset = 0;
      const MainArray = [];
    
      //Get Free Delivery Restuarant
      var featured = await subject.findAll({
        attributes: ['id','name','image'],
        where:{
          companyId: companyId
        }
      });
    
      for (var i = 0; i < featured.length; i++) 
      {
        var array = {};
        var id = featured[i].id;
        var name = featured[i].name;
        array.type = name;
        array.categoryId = id;
        var restDetails = await Users.findAll({
          attributes: ['id','email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = users.id)'), 'totalRating']],
          where: {
              role : '2',
              companyId: companyId
          },
          order: sequelize.literal(`totalRating DESC`),
          include: [
              {
                  model: teacherSubject,
                  required: true,
                  attributes: [],
                  where: { 
                    subjectId: id
                  }
              },
              {
                  model: userDetail,
                  attributes: ['fName','lName','dob','image','uniqueId'],
                  required: true,
                  where: {
                      status: '1'
                  } 
              }
          ],
          offset: offset, 
          limit: limit,
        });
        array.professional = restDetails;
        if(restDetails.length > 0)
        {
          MainArray.push(array);
        }
      }
    
      var MainArrayN = JSON.parse(JSON.stringify(MainArray));
    
      const userData = await Users.findAll({
        attributes: ['id','email',
        [sequelize.literal('(SELECT ROUND(AVG(rating),0) FROM ratings where teacherId = users.id)'), 'totalRating']],
        where: where,
        order: sequelize.literal(`totalRating DESC`),
        include: [{
          model: userDetail,
          attributes: ['fName','lName','status']
        }],
        limit:5, offset:0
      }); 
    
      //Total Categories
      var totalCategory = await subject.findAll({
        where:{
          companyId: companyId
        }
      });
    
      //Total Customer
      var totalCustomers = await Users.findAll({
        where: {
          role: '1',
          companyId: companyId
        }
      });
    
      //TotalProfessional
      var totalProfessional = await Users.findAll({
        where: {
          role: '2',
          companyId: companyId
        },include: [{
          model: userDetail,
          attributes: ['fName','lName','status'],
          required:true
        }],
      });
    
      //Get Recent Bookings
      var newDate = moment(new Date()).format("YYYY-MM-DD");
    const usr = await TeacherBooking.findAll({
        attributes: ['bookingId','teacherId','status','subjectId','bookingDate'],
        where: {
          bookingDate: newDate,
          status:[0,1]

        },
        include: [{
            model: StudentbookingDetail,
            attributes: ['id','studentId','bookingDate','timeSlot'],
            required: true,
          
            include: [{
              model: userDetail,
              attributes: ['fName','lName','image']
            }]
        }]
      });      
      var usrArray = [];
      for(var k=0;k<usr.length;k++)
      {
        var array = {};
    
        array.bookingDate  = usr[k].bookingDetail.bookingDate;
        array.timeSlot     = usr[k].bookingDetail.timeSlot;
        //Get Student Name
        var stuentNmae = await userDetail.findOne({
          attributes: ['fName','lName'],
          where: {
            userId: usr[k].bookingDetail.studentId
          }
        });
        array.sName     = stuentNmae.dataValues.fName+ ' ' +stuentNmae.dataValues.lName;
        //Get Teacher Details
        var teacherName = await userDetail.findOne({
          attributes: ['fName','lName'],
          where: {
            userId: usr[k].teacherId
          }
        });
        array.tName     = teacherName.dataValues.fName+ ' ' +teacherName.dataValues.lName;
        //Get Category Details
        var categoryName = await subject.findOne({
          attributes: ['id','name','image'],
          where:{
            companyId: companyId,
	    id: usr[k].subjectId
          }
        });
        array.category     = categoryName.dataValues.name;
        usrArray.push(array);
      }
      
      //Get Revenue All Categories
      var data = {};
      data.totalCustomers = totalCustomers;
      data.totalProfessional = totalProfessional;
      data.totalCategory = totalCategory;
      data.totalBooking = totalBooking;
      data.userData = userData;
      data.CategoryProfessional = MainArrayN;
      data.totalRevenue = totalRevenue.dataValues.totalAmount;
    return res.render('dashboard',{data,usrArray,moment});
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
    },
      getCategoryBasisPro: async(req, res) => {
        const data = req.body;
        const companyId = req.session.userData.id;
        var categoryId = data.categoryId;
         var featured = await subject.findOne({
            attributes: ['id','name','image'],
            where: {
              id: categoryId
            }
          });
        var limit  = 5;
          var offset = 0;
       
        var array = {};
        var name = featured ? featured.dataValues.name : "";
        array.type = name;
        var restDetails = await Users.findAll({
          attributes: ['id','email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = users.id)'), 'totalRating'],
          [sequelize.literal('(SELECT count(*) FROM bookings where teacherId = users.id)'), 'totalBookings'],
          [sequelize.literal('(SELECT SUM(credit) FROM bookings where teacherId = users.id AND subjectId = "'+categoryId+'")'), 'totalRevenue']],
          where: {
              role : '2',
              companyId: companyId
          },
          order: sequelize.literal(`totalRating DESC`),
          include: [
              {
                  model: teacherSubject,
                  required: true,
                  attributes: [],
                  where: { 
                    subjectId: categoryId
                  }
              },
              {
                  model: userDetail,
                  attributes: ['fName','lName','dob','image','address','phoneNo','uniqueId'],
                  required: true,
                  where: {
                      status: '1'
                  } 
              }
          ],
          offset: offset, 
          limit: limit,
        });
        array.professional = restDetails;
      if(array){
    
        return helpers.jsonResponse(
          res,
          true,
          array,
          appstrings.success,
          200,
          200
        );
      }else{
    
        return helpers.jsonResponse(
          res,
          true,
          [],
          appstrings.success,
          201,
          201
        );
      }
    
      },
}