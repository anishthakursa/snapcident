const jwt = require('jsonwebtoken');
module.exports={
    viewChat:async(req,res)=>{
        try{
            const credentials = {
                // phoneNumber: req.session.userData1.phoneNumber,
                // companyId:   req.companyId,
                // countryCode: req.session.userData1.countryCode,
                userType: 1,
                id : req.id,
                 exp: Math.floor(Date.now() / 1000) + 8640000*2,
              };
              const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256'});
            return res.render('pages/admin/chat/chat',{ token: authToken, id: req.id});
        }catch(e){
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    }
}