const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model          = require("../../models/index");
const jwt            = require('jsonwebtoken');
const helpers        = require("../../helpers");
const hashPassword   = require('../../helpers/hashPassword');
const responseHelper = require("../../helpers/responseHelper");
const common         = require('../../helpers/common');
const moment         = require('moment');

module.exports = {

	/*
	*@role Get Plan List
	*@method GET
	*/
	list: async(req,res) =>{
		try {
			const userList = await tokens.findAll({
				where :{
					companyId :req.id
				}
			});
			return res.render('pages/admin/plan/list.ejs',{userList,count:userList.length});
		} catch (e) {
			return responseHelper.error(res, e.message, 400);
		}
	},

	/*
	*@role Get Plan List
	*@method GET
	*/
	getplanList: async(req,res) =>{
		try {
			const userList = await tokens.findAll({
				where :{
					companyId :req.id
				}
			});
			return helpers.jsonResponse(res,true,userList,appstrings.success,200,200);
		} catch (e) {
			return responseHelper.error(res, e.message, 400);
		}
	},
	fetchplanList:async(req,res)=>{
		try {
			let sessionData = req.session.userData;
			var page = 1
			var limit = 10
		   
			var params = req.body;
			let status = params.status
			let search = params.search ? params.search:''
			let where = {  companyId: sessionData.id }
			if (search!="")
			{
			 where = {
			  [Op.or]: [
				{ name: { [Op.like]: `%${params.search}%` } },
				{ code: { [Op.like]: `%${params.search}%` } },
				{ description: { [Op.like]: `%${params.search}%` } },
			  ], 
			  companyId: sessionData.id,
			 }
			}else{
			  where.companyId=sessionData.id
			}

			if(status==2){
			  where.status=[0,1]
			}else{
			  where.status=[status]
			}
			
			if (params.page) page = params.page
			if (params.limit) limit = parseInt(params.limit)
			if (params.role) role = parseInt(params.role)
			var offset = (page - 1) * limit

			const userList = await tokens.findAndCountAll({
			 where: where,  
        	offset: offset, limit: limit,
			});
			return helpers.jsonResponse(res,true,userList,appstrings.success,200,200);
		} catch (e) {
			return responseHelper.error(res, e.message, 400);
		}
	},
		/*
	*@role Get Plan List
	*@method GET
	*/
	addPlan: async(req,res) =>{
		try {
			const params = req.body;

			if(params.planId != "")
			{
				const dataAlre = await tokens.findOne({
					where :{
						companyId :req.id,
						token_amount:params.amount,
						id: {
							[Op.ne]: params.planId
						}
					}
				});
				if(dataAlre)
				{
					return helpers.jsonResponse(res,true,{},appstrings.already_exists,201,201);
				}

				await tokens.update({
					token_amount: params.amount,
					token_count: params.tokens,
					description: params.name
				},{where:{
					id: params.planId
				}});
				return helpers.jsonResponse(res,true,{},appstrings.credit_update_success,200,200);
			}
			const data = await tokens.findOne({
				where :{
					companyId :req.id,
					token_amount:params.amount
				}
			});
			if(data)
			{
				return helpers.jsonResponse(res,true,{},appstrings.already_exists_plan,201,201);
			}

			await tokens.create({
				token_amount: params.amount,
				token_count: params.tokens,
				companyId:req.id,
				description: params.name
			})
			return helpers.jsonResponse(res,true,{},appstrings.credit_created_success,200,200);
		} catch (e) {
			return responseHelper.error(res, e.message, 400);
		}
	},

	/*
	*@role Get Plan Details
	*@method GET
	*/
	viewPlan: async(req,res) =>{
		try {
			const userList = await tokens.findOne({
				where :{
					id :req.params.id
				}
			});
			return helpers.jsonResponse(res,true,userList,appstrings.success,200,200);
		} catch (e) {
			return responseHelper.error(res, e.message, 400);
		}
	},

	/*
	*@role Delete Plan
	*@method GET
	*/
	deletePlan: async(req,res) =>{
		try {
			const userList = await tokens.destroy({
				where :{
					id :req.params.id
				}
			});
			return helpers.jsonResponse(res,true,userList,appstrings.credit_delete_success,200,200);
		} catch (e) {
			return responseHelper.error(res, e.message, 400);
		}
	},
};