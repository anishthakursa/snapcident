const config              = require('config');
const sequelize           = require('sequelize');
const Op                  = require('sequelize').Op;
const model               = require("../../models/index");
const jwt                 = require('jsonwebtoken');
const helpers             = require("../../helpers");
const hashPassword        = require('../../helpers/hashPassword');
const responseHelper      = require("../../helpers/responseHelper");
const common              = require('../../helpers/common');
const moment              = require('moment');

FAQ.belongsTo(FAQCATEGORY, {foreignKey: 'category'});
module.exports = {

	/*
	*@role Get List Faq
	*@method GET
	*/
	list: async(req,res) =>{    
	    try {
	        
	        var category=await FAQCATEGORY.findAll({where:{companyId:req.id}})
	        return res.render('pages/admin/faq/list.ejs',{category});
	    } catch (e) {
	        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},

	/*
	*@role Get FAQ LIST
	*@method GET
	*/
	getList: async (req, res, next) => {

		var params    = req.body
		var where     = {}
		var category  = ""
		var page      = 1
		var limit     = 20
		var orderby   = 'createdAt'
		var orderType = 'DESC'
		var type=[1,2]
		if(params.orderByInfo &&   params.orderByInfo.orderby) {
			orderby=params.orderByInfo.orderby
			orderType=params.orderByInfo.orderType
		}
		if(params.page) page=params.page
		if(params.category) category=params.category
		if(params.type) type=[params.type]

		if(params.limit)
		{
			limit=parseInt(params.limit)
			
		}
		var offset=(page-1)*limit

		if(params.search && params.search!="")
		{
			where={ 
				[Op.or]: [
					{question: {[Op.like]: `%${params.search}%`}},
					{answer: { [Op.like]: `%${params.search}%` }},
					{type: { [Op.like]: `%${params.search}%` }
					}
				],
			}
		}

		if(category!="")
		{
			where.category= category
		}
		where.companyId= req.id 
		where.type=type
		try{
			var services = await FAQ.findAndCountAll({
				where: where,
				order: [[orderby,orderType]],
				include:[{
					model:FAQCATEGORY,
					attributes:['catName']
				}],
				distinct:true,
				offset:offset,limit:limit,
			})
			return helpers.jsonResponse(res,true,services,appstrings.success,200,200);
		}
		catch (e) {
			console.log(e)
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/*
	*@role Post Add Category
	*@method Post
	*/
	addCategory: async(req,res)=>{
		const params = req.body;
		try{
			var response=FAQCATEGORY.create({catName:params.category,companyId:req.id})
			if(response)
				return helpers.jsonResponse(res,true,{},appstrings.success,200,200);
			else
				return responseHelper.post(res, appstrings.oops_something, null,400);
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/*
	*@role Get Category
	*@method POST
	*/
	getCategory: async (req, res, next) => {
		try{
			var services = await FAQCATEGORY.findAndCountAll({
				where: {companyId:req.id},
				order: [['createdAt','DESC']]
			})
			return helpers.jsonResponse(res,true,services,appstrings.success,200,200);
		}
		catch (e) {
			console.log(e)
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/*
	*@role Delete Category
	*@method POST
	*/
	deleteCategory: async (req, res, next) => {
		try{
			const params = req.body;
			const numAffectedRows = await FAQCATEGORY.destroy({
				where: {
					id: params.id
				}
			}) 
			return helpers.jsonResponse(res,true,{},appstrings.success,200,200);
		} catch (e) {
			console.log(e)
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},


	addFaq: async (req, res) => {
		try {
		const data = req.body;
		var profileImage=""

		const user = await FAQ.findOne({
		where: {
		question: data.question,

		}
		});



		if (!user) {

			const users = await FAQ.create({
				question: data.question,
				answer: data.answer,
				type: data.type,
				companyId: req.id,
				category: data.categoryId
			});
			return helpers.jsonResponse(res,true,{},appstrings.success,200,200);

		}
		else  responseHelper.error(res, appstrings.already_exists, 400);

		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}

	},

	/*
	*@role Delete FAQ
	*@method GET
	*/
	delete:async(req,res,next) => { 
	   const id = req.params.id;
	  	try{
	        const numAffectedRows = await FAQ.destroy({
	          where: {
	            id: req.params.id
	          }
	          })  
	            
	          if(numAffectedRows>0)
	          {
	           	//req.flash('successMessage',appstrings.delete_success)
	          	return res.redirect(adminpath+"faq");
	          }

	          else {
	            //req.flash('errorMessage',appstrings.no_record)
	            return res.redirect(adminpath+"faq");
	          }

        }catch (e) {
          req.flash('errorMessage',appstrings.no_record)
          return res.redirect(adminpath+"faq");
        }
	},

	/*
	*@role Get FAQ Detils
	*@method GET
	*/
	viewFaq: async(req,res) =>{
		const numAffectedRows = await FAQ.findOne({
			where: {
				id: req.params.id
			}
		});
		return helpers.jsonResponse(res,true,numAffectedRows,appstrings.success,200,200);
	},


	update: async (req, res) => {
		try {
			const data = req.body;
			const user = await FAQ.findOne({
				where: {
					id:data.faqId,
					companyId: req.id
				}
			});
			if (user) {
				const users = await FAQ.update({
						question: data.questionedit,
						answer: data.answeredit,
						type: data.typeedit,
						companyId: req.id,
						category: data.categoryId
					},
					{ 
						where:
						{
							id: data.faqId,
							companyId: req.id
						}
					}
				);
				if (users) {
					return helpers.jsonResponse(res,true,{},appstrings.success,200,200);
				}
				else  
				{
					return helpers.jsonResponse(res,false,{},appstrings.oops_something,400,400);
				}
			}
			else{  return helpers.jsonResponse(res,false,{},appstrings.oops_something,204,204); }

		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	}

}