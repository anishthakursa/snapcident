const config          = require('config');
const sequelize       = require('sequelize');
const Op              = require('sequelize').Op;
const model           = require("../../models/index");
const jwt             = require('jsonwebtoken');
const helpers         = require("../../helpers");
const hashPassword    = require('../../helpers/hashPassword');
const responseHelper  = require("../../helpers/responseHelper");
const common          = require('../../helpers/common');
const moment          = require('moment');
const users           = model.users;
const DOCUMENT        = model.documents
const userDetail      = model.userDetail;
const userRedeemption = model.userRedeemptions;
const Packages        = model.packages;

module.exports = {

	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Redeemption list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	list: async (req, res) => {
	    try {
	    	let sessionData = req.session.userData;
	    	const userList =  await Packages.findAll({
	    		where: {
	    			companyId: sessionData.id
	    		}
	    	});
			return res.render('pages/admin/packages/list',{userList,moment});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// Add Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	add: async (req, res) => {
	    try {
			return res.render('pages/admin/packages/add');
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// Add Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	postAdd: async (req, res) => {
	    try {
			const data = req.body;
			let sessionData = req.session.userData;
			const userDet = await Packages.create({
	            title: data.title,
	            companyId: sessionData.id,
	            description: data.description,
	            minute: data.minute,
	            price: data.price,
	        });
	        return helpers.jsonResponse(res,true,{},appstrings.success, 200, 200);
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// Delete Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	delete: async (req, res) => {
  	  try{
        const numAffectedRows = await Packages.destroy({
          	where: {
            	id: req.params.id
          	}
          	})  
           return helpers.jsonResponse(res,true,{},appstrings.delete_success, 200, 200);
        }catch (e) {
           	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// View Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	view: async (req, res) => {
  	  	try {
	      	const findData = await Packages.findOne({
		      where :{
		      	id: req.params.id
		      }
	      	});
	      	return res.render('pages/admin/packages/view',{data:findData});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
    },

    /////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// Update Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
    update:async (req, res) =>{
    	try {
		    const data = req.body;
		    const user = await Packages.findOne({
	      		attributes: ['id'],
		      	where: {
			        id: data.pid
		      	}
    		});
		    if (user) {
		      	const users = await Packages.update({
			        title: data.title,
		            description: data.description,
		            minute: data.minute,
		            price: data.price,
		       	},
		       	{
		       		where:{
		         		id: data.pid
		       		}
		       	});
		      	if (users) {
		        	return helpers.jsonResponse(res,true,{},appstrings.update_success, 200, 200);
	     	 	}
		     	else{
		     		return helpers.jsonResponse(res, false, {},appstrings.oops_something, 400, 400);
		    	}
		    }
		    else{
		    	return helpers.jsonResponse(res, false, {},appstrings.oops_something, 400, 400);
		    }
	  	} catch (e) {
	   		console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	  	}
    }

}	