const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model          = require("../../models/index");
const jwt            = require('jsonwebtoken');
const helpers        = require("../../helpers");
const hashPassword   = require('../../helpers/hashPassword');
const responseHelper = require("../../helpers/responseHelper");
const common         = require('../../helpers/common');
const moment         = require('moment');

module.exports = {

	/*
	*@role Get Banner list
	*@method GET
	*/
	list: async(req,res) =>{
		try {
			const userList = await Banner.findAll({
			where :{
				companyId :req.id
			},
				order: [
					['orderby','DESC']
				],
			});
			return res.render('pages/admin/banner/list.ejs',{userList,count:userList.length});



		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}

	},

	getBannerlist: async(req,res) => {
		try {

			var array = [];
			if(req.body.status == '2')
			{
				array.push(1);
				array.push(0);
			}else{
				array.push(req.body.status);
			}

			const userList = await Banner.findAll({
			where :{
				companyId :req.id,
				status: {
					[Op.in]: array
				}
			},
				order: [
					['orderby','DESC']
				],
			});
			return helpers.jsonResponse(res,true,userList,appstrings.success,200,200);
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/*
	*@role Add Banner Page
	*@method GET
	*/
	add: async(req,res) =>{
		try {
			return res.render('pages/admin/banner/add.ejs');
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/*
	*@role Add Banner
	*@method POST
	*/
	postAdd: async(req,res) => {
		try{	
			const params = req.body;
			var icon = "";
            if (req.files) {
                ImageFile = req.files.image; 
                if(ImageFile)
                {
                  	icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
                  	ImageFile.mv(config.UPLOAD_DIRECTORY +"banners/"+ icon, function (err) {
                      	//upload file
                      	if (err)
                      	return helpers.jsonResponse(res, false, {}, err.message, 400);
                  	});
                }
            }
            
            const updatedResponse = await Banner.create({
				name: params.name,
				url: icon,
				companyId: req.id
			});
            return helpers.jsonResponse(res,true,{},appstrings.success,200,200);
		} catch(e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/*
	*@role Get Banner Details
	*@method GET
	*/
  	view: async (req, res) => {
  	  	try {
	      	const findData = await Banner.findOne({
		      where :{
		      	id: req.params.id
		      }
	      	});
	      	return res.render('pages/admin/banner/view',{data:findData});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
    },


    /*
	*@role Add Banner
	*@method POST
	*/
	updateBanner: async(req,res) => {
		try{	
			const params = req.body;

			const checkDetails = await Banner.findOne({
				id: params.bannerId
			});
			if(!checkDetails)
			{
				return helpers.jsonResponse(res,true,{},appstrings.no_record,201,201);
			}
			var icon = "";
            if (req.files) {
                ImageFile = req.files.image; 
                if(ImageFile)
                {
                  	icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
                  	ImageFile.mv(config.UPLOAD_DIRECTORY +"banners/"+ icon, function (err) {
                      	//upload file
                      	if (err)
                      	return helpers.jsonResponse(res, false, {}, err.message, 400);
                  	});
                }
            }
            
            const updatedResponse = await Banner.update({
				name: params.name,
				url: (icon != "") ? icon : checkDetails.dataValues.url,
				companyId: req.id
			},{
				where: {
					id: params.bannerId
				}
			});
            return helpers.jsonResponse(res,true,{},appstrings.success,200,200);
		} catch(e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/*
	*@role Delete Banner
	*@method GET
	*/
	deleteBanner: async(req,res) =>{
		try {
			const userList = await Banner.destroy({
				where :{
					id :req.params.id
				}
			});
			return helpers.jsonResponse(res,true,{},appstrings.success,200,200);
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},

	/**
  *@Method POST
  *@role Change Coupon Status Active/Block
  */
  status: async(req,res,next) => {
    var params=req.body
    try{
      
      const userData = await Banner.findOne({
        where: {
          id: params.id 
        }
      });
       
      if(userData)
      {
        var status=0
        if(params.status==0)  status=1
       
        const updatedResponse = await Banner.update({
            status: status,
          },
          {
            where : {
            id: userData.dataValues.id
          }
        });
         
        if(updatedResponse)
        {
          return helpers.jsonResponse(res,true,{},appstrings.success,200,200);
        }
        else{
          return helpers.jsonResponse(res,true,{},appstrings.oops_something,204,204);
        }
      }
      else{
      	return helpers.jsonResponse(res,true,{},appstrings.no_record,204,204);
      }
    }
    catch (e) {
      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
};