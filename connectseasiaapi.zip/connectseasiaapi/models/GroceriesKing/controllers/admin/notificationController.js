const config          = require('config');
const sequelize       = require('sequelize');
const Op              = require('sequelize').Op;
const model           = require("../../models/index");
const jwt             = require('jsonwebtoken');
const helpers         = require("../../helpers");
const hashPassword    = require('../../helpers/hashPassword');
const responseHelper  = require("../../helpers/responseHelper");
const common          = require('../../helpers/common');
const moment          = require('moment');
const users           = model.users;
const userDetail      = model.userDetail;
const Notification         = model.notifications;
module.exports = {

  /*
  *@role Notification Setting
  *@method POST
  */
  notificationSetting: async (req, res, next) => {
    var params = req.body
    try {
      const findData = await NOTIFICATIONKEY.findOne({
        where: {
          companyId: req.id
        }
      });
      if (findData) {

        var response = await NOTIFICATIONKEY.update({
          smtp: params.smtp ? params.smtp : findData.dataValues.smtp,
          username: params.username ? params.username :findData.dataValues.username,
          apikey: params.apikey ? params.apikey :findData.dataValues.apikey,
          username2: params.username2 ? params.username2 :findData.dataValues.username2,
          apikey2: params.apikey2 ? params.apikey2 :findData.dataValues.apikey2,
          sms: params.sms ?  params.sms :findData.dataValues.sms,
          accountId: params.accountId ? params.accountId :findData.dataValues.accountId,
          secretkey: params.secretkey ? params.secretkey :findData.dataValues.secretkey,
          accountId2: params.accountId2 ? params.accountId2 : findData.dataValues.accountId2,
          secretkey2: params.secretkey2 ? params.secretkey2 : findData.dataValues.secretkey2,
          pushNotification: params.both,
          companyId: req.id
        },
        {
          where: {
            id: findData.dataValues.id
          }
        });
        return responseHelper.post(res, appstrings.update_success, null, 200);
      }
      else {
        var response = await NOTIFICATIONKEY.create({
          smtp: params.smtp ? params.smtp : "",
          username: params.username ? params.username : "",
          apikey: params.apikey ? params.apikey :"",
          username2: params.username2 ? params.username2 :"",
          apikey2: params.apikey2 ? params.apikey2 :"",
          sms: params.sms ? params.sms : "",
          accountId: params.accountId ? params.accountId : "",
          secretkey: params.secretkey ? params.secretkey : "",
          accountId2: params.accountId2 ? params.accountId2 : "",
          secretkey2: params.secretkey2 ? params.secretkey2 : "",
          pushNotification: params.both,
          companyId: req.id
        });
        if (response) return responseHelper.post(res, appstrings.update_success, null, 200);

        else return responseHelper.post(res, appstrings.oops_something, null, 200);
      }
    } catch (e) {
      console.log(e)
      return responseHelper.error(res, e.message);
    }
  },


  viewNotification: async(req,res) =>{
    try {
      const companyId = req.id;
      let updateNotification =await Notification.update({status:1},{where:{status:0}})
     const userList = await Notification.findAll({
      where:{
        deleteStatus : 0
      },
        order: [
              ['createdAt', 'DESC']
          ], 
      });
      return res.render( 'pages/admin/notification/list' ,{ userList,count:userList.length });
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
  notificationCount:async(req,res)=>{
    try {
      const companyId = req.id;
     
     const userList = await Notification.findAndCountAll({
            order: [
                  ['createdAt', 'DESC']
              ], 
              where:{ status:0 }
          });
         
          return helpers.jsonResponse(res,true,userList,appstrings.notification_fetched_success,200,200);
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
  getviewNotification:async(req,res)=>{
    try {
      var page = 1
      var limit = 10
      var role = 1
      var params = req.body;
      if (params.page) page = params.page
      if (params.limit) limit = parseInt(params.limit)
      if (params.role) role = parseInt(params.role)
      var offset = (page - 1) * limit
      let updateNotification =await Notification.update({status:1},{where:{status:0}})
      const userList =  await Notification.findAll({
        order: [
          ['createdAt', 'DESC']
        ],   
        offset: offset, limit: limit,
      });
      return helpers.jsonResponse(res,true,userList,"Notifcations fetched successfully",200,200);
    }catch(e){
      return responseHelper.error(res, e.message, 400);
    }
  },
  /////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////Get Notification Page ////////////////////////////////
  /////////////////////////////////////////////////////////////////////////////////
  notification: async (req, res) => {
    try {
      const companyId = req.session.userData.id;
      return res.render('pages/admin/notification/notification');
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////Send Notification Page //////////////////////////
  /////////////////////////////////////////////////////////////////////////////////
  sendNotification:  async function (req, res) {
    try {
	let description = ''
        const params = req.body;
        var role = [];
        if(params.role == '0')
        {
          role.push(1);
          role.push(2);
        }else{
          role.push(params.role)
        }
        const userdetails = await users.findAll({
            attributes: ['id','email'],
            where: {
               companyId: req.id,
               role:{
                [Op.in]: role
               }
            },
            include: [{
                model: userDetail,
                attributes:['deviceToken'],
                where: {
                  deviceToken: {
                    [Op.ne]: ''
                  }
                }
            }]
        });
        var tokenstudent = userdetails.map(function(element){
          let device = element.userDetail.deviceToken;
          return device;
        });
        let requestType = params.tile;
        description = params.message;

        common.sendNotification(tokenstudent,description,requestType);
        return helpers.jsonResponse(res,true,{},appstrings.notification_sent,200,200);
    } catch (e) {
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /////////////////////////////////////////////////////////////////////////////////
  ////////////////////////////////Get Mail Page ///////////////////////////
  /////////////////////////////////////////////////////////////////////////////////
  mail: async (req, res) => {
    try {
      return res.render('pages/admin/notification/mail');
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
   * @role Send Mail
   * @param {Id} req 
   * @author Raghav
   * @Method GET
   */
  sendMail: async(req, res, next) => {
    var params = req.body;
    var role = [];
    const companyId = req.id;
    if(params.role == '0')
    {
      role.push(1);
      role.push(2);
    }else{
      role.push(params.role)
    }
    const userdetails = await users.findAll({
        attributes: ['id','email'],
        where: {
           companyId: companyId,
           role:{
            [Op.in]: role
           }
        }
    });
    var emails = userdetails.map(function(element){
      let mail = element.email;
      return mail;
    });
    
    var htmldata =
    '<p>Hi User</p>' +
    '<p>'+params.message+'</p>' +
    '<p>Thanks,</p>'+
    '<p>Team CereConsult</p>'+
    '<p>--------</p>'+
    '<p>This is an automated email. Please do not reply to it.</p>'+
    '<p>In case of any help, kindly reach us at - please reach us at info@CereConsult.com" for any help" etc.</p>';
    var subject = params.tile;
    common.sendMail(emails,htmldata,companyId,subject);
    return helpers.jsonResponse(res,true,{},appstrings.mail_sent, 200, 200);
  },


  clearAllNotifications: async(req, res, next) => {
    try {
      const numAffectedRows = await Notification.update({
        deleteStatus:1,
      },
      {
        where : {deleteStatus:0}
      }

      );
      return helpers.jsonResponse(res,true,numAffectedRows,appstrings.delete_success, 200, 200);
    }catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  }
} 