const config          = require('config');
const sequelize       = require('sequelize');
const Op              = require('sequelize').Op;
const model           = require("../../models/index");
const jwt             = require('jsonwebtoken');
const helpers         = require("../../helpers");
const hashPassword    = require('../../helpers/hashPassword');
const responseHelper  = require("../../helpers/responseHelper");
const common          = require('../../helpers/common');
const moment          = require('moment');
const users           = model.users;
const DOCUMENT        = model.documents
const userDetail      = model.userDetail;
const userRedeemption = model.userRedeemptions;
module.exports = {

	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Redeemption list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	list: async (req, res) => {
	    try {
			// console.log('data-->',req.id)
	    	const companyId = req.session.userData.id;
	    	const userList =  await userRedeemption.findAll({
	    		where:{
					companyId: req.id,
	    		},
	    		include: [
	    		{
	    			model: users,
	    			attributes: ['email']
	    		},
	    		{ 
	    			model: userDetail,
	    			attributes: ['fName','lName','status']
	    		}]
	    	});
			return res.render('pages/admin/user/redeem',{userList,moment});
	    } catch (e) {
	      	
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	  },
	  payoutlist: async (req, res) => {
	    try {
		
			const companyId = req.session.userData.id;
			var page = 1
			var limit = 10
			var role = 1
			var params = req.body
			var search= ""
			var status = 2

			if(params.status) status = parseInt(params.status)
			if(status==2){ status=[0,1] }else{ status = [status]}

			if (params.page) page = params.page
			if (params.limit) limit = parseInt(params.limit)
			if (params.role) role = parseInt(params.role)
			if (params.search) search = params.search
			var offset = (page - 1) * limit

	    	const userList =  await userRedeemption.findAndCountAll({
	    		where:{
					companyId: req.id,
					status:status,
					[Op.or]: [
						{ '$userDetail.fName$': { [Op.like]: `%${search}%` } },
						{ '$userDetail.lName$': { [Op.like]: `%${search}%` } },
						{ '$user.email$' : { [Op.like]: `%${search}%` } },
					  ],
	    		},
	    		include: [
	    		{
	    			model: users,
	    			attributes: ['email']
	    		},
	    		{ 
	    			model: userDetail,
	    			attributes: ['fName','lName','status']
				}],
				offset: offset, limit: limit,
			});
			return helpers.jsonResponse(res,true,userList,appstrings.success, 200, 200);
	    } catch (e) {
	      	
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	  },

  	/*
  	*@role Approve Redeemption
  	*
  	*/
  	updateRedeemption: async(req, res, next) => {
	    var id = req.body.redeemptionid;
	    const companyId = req.session.userData.id;
	    //Update Booking Status 
            const update = await userRedeemption.update(
                {
                    status: 1
                },
                {
                    where:
                    { 
                        id: id
                    }
                }
            )
	  	const userList =  await userRedeemption.findOne({
	  			where: {
	  				id: id
	  			},
	    		include: [
	    		{
	    			model: users,
	    			attributes: ['email']
	    		},
	    		{
	    			model: userDetail,
	    			attributes: ['fName','lName','status']
	    		}]
	    	});

		    var htmldata =
		    '<p>Hi '+userList.userDetail.fName+'</p>' +
		    '<p>Your '+userList.dataValues.tokenAmount+' amount has been approved successfully. Amount will be credited in your given bank account soon.</p>' +
		    '<p>Thanks,</p>'+
		    '<p>Team Cere Consult</p>'+
		    '<p>--------</p>'+
		    '<p>This is an automated email. Please do not reply to it.</p>'+
		    '<p>In case of any help, kindly reach us at - please reach us at info@CereConsult.com" for any help" etc.</p>';
		    var subject = 'Cere Consult Token Redeemption Confirm';
		    common.sendMail(userList.user.email,htmldata,companyId,subject);
		    
	    return helpers.jsonResponse(res,true,{},appstrings.success, 200, 200);
	},

	/**
	 * @role Send Payout Mail
	 * @param {Id} req 
	 * @author Raghav
	 * @Method GET
	 */
	sendpayoutMail: async(req, res, next) => {
	    var FormData = req.body;
	    var email = FormData.email;
	    var array = email.split(',');
	    const companyId = req.session.userData.id;
	  var htmldata =
	    `<p>Hi User</p> 
	    <p>${FormData.message}</p>
	    <p>Thanks,</p>
	    <p>Team Cere Consult</p>
	    
	    <p>This is an automated email. Please do not reply to it.</p>
	    <p>In case of any help, kindly reach us at - Please reach us at <a href="">info@cereconsult.com</a> for any help</p>`;
	    var subject = 'Cere Consult Payout Confirmation!';
	    common.sendMail(array,htmldata,companyId,subject);
	    
	    return helpers.jsonResponse(res,true,{},appstrings.mail_sent, 200, 200);
	}
}	