﻿const model = require("../models/index");
const sequelize = model.sequelize;
const { Op } = require('sequelize');
const { createToken } = require("../middleware");
const helpers = require("../helpers");
const common              = require('../helpers/common');
const handleError = helpers.handleError;
const nodemailer = require('nodemailer');
var moment = require('moment');

const transporter = nodemailer.createTransport({
  service: config.SMTPSER,
  auth: {
    user: config.SENDMAIL,
    pass: config.SENDPWD,
  }
});
const fs = require('fs');
var ejs = require('ejs');
 
USERSUB.belongsTo(SUBSCRIPTION, {foreignKey: 'subscriptionId'});
//const recentSearch = model.recentSearch;
recentSearch.belongsTo(user,{foreignKey: 'professionalId'});
teacherSubject.belongsTo(subjectDetail);
//teacherSubject.belongsTo(subCategory);

StudentbookingDetail.hasOne(bookingNotification,{foreignKey:'bookId',sourceKey:'id'})
bookingNotification.belongsTo(StudentbookingDetail,{foreignKey:'bookId',targetKey:'id'})

bookingNotification.hasOne(subjectDetail,{foreignKey:'id',sourceKey:'subjectId'})
subjectDetail.belongsTo(bookingNotification,{foreignKey:'id'})

bookingNotification.hasOne(userDetail,{foreignKey:'userId',sourceKey:'teacherId',as:'teacher'})
userDetail.belongsTo(bookingNotification,{foreignKey:'userId'})

TeacherBooking.hasOne(userDetail,{foreignKey:'userId',sourceKey:'teacherId',as:'tutor'})
userDetail.belongsTo(TeacherBooking,{foreignKey:'userId'})

TeacherBooking.hasOne(subjectDetail,{foreignKey:'id',sourceKey:'subjectId',as:'subjectTaken'})
subjectDetail.belongsTo(TeacherBooking,{foreignKey:'id'})

user.hasOne(teacherSubject, {foreignKey: 'teacherId'});

module.exports = {

//////////////////////////////////////////////////////////////////////////////////
///////////////////////// get registeration screen dropdown /////////////////////
//////////////////////////////////////////////////////////////////////////////// 
    
    registerList: async function(req, res) {
        try {


            const cls = await classes.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1                     /// only active
                }
            });
            const hse = await house.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1                     /// only active
                }
            });
            const data = {};
            data.class = cls;
            data.house = hse;
            return helpers.jsonResponse(
                res,
                true,
                data,
                "List",
                200,
                200
            );
                
            
        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
    

      //////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////// register /////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////   

    register: async function (req, res) {
        let transaction;
        try {
            const validations = {
                email: "required|email",
                password: "required|minLength:4",
                lName: "required|minLength:2",
                fName: "required|minLength:2",
                rollNo: "required",
                dob: "required|dateFormat:YYYY-MM-DD",
                class: "required|minLength:4",
                house: "required|minLength:4",
                section: "required|minLength:4"

                //planId: "required",
            };
            const formData = req.body;
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                if (matched.data.email && matched.data.email.rule == 'email') {
                    throw new handleError(appstrings.invalid_email, 422);
                }
                throw new handleError("Fields Required", 400);
            }

            // Verify User
            let verifyUser = await user.findOne({
                where: {
                    email: formData.email,
                }
            });
            
            const codeData = await COMPANY.findOne({ where: {code: formData.code?formData.code:config.STATIC_CODE}});

            if(codeData)
            {
                const companyId = codeData.dataValues.id


            if (verifyUser) {
                return helpers.jsonResponse(res, false, {}, "Email Already Exist", 400, 400);
            } else {
                var lPoints = '0';
                let refreeUser = formData.referralCode ? formData.referralCode : "";
                if(refreeUser != "")
                {
                    var checkRefrr = await userDetail.findOne({
                        where: {
                            referralCode: refreeUser,
                        }
                    });
                    if(checkRefrr)
                    {
                        var lPoints = '50';
                        await userDetail.update({ lPoints: lPoints }, { where: { userId: checkRefrr.dataValues.userId } });
                    }else{
                        return helpers.jsonResponse(res, false, {}, "Invalid referral code", 400, 400);
                    }
                }
                const password = formData.password;
                const pswd = await helpers.cryptPassword(password);
                var newpassword = pswd;
                transaction = await sequelize.transaction();

                const usr = await user.create({
                    email: formData.email,
                    password: newpassword,
                    companyId: companyId,
                    role: 1                    //// role for student
                }, { transaction });

                // const subscription = await tokens.findOne({
                //     where: {
                //         id: formData.planId
                //     }
                // }); 
                // if(formData.planId != '7')
                // {
                //     var totaltoken = subscription.dataValues.token_count;
                // }else{
                //     let per   = parseInt(formData.amount);
                //     let discount_price = per*(20/100);        // Get Discount Token
                //     var totaltoken  = per + discount_price;  //Get Total Token
                //     //var totaltoken = parseInt(formData.amount) * 12;
                // }
                //let lPoints = '0';
                let nameUser  = usr.dataValues.id;
                let code = "USERDELC" + nameUser.substring(1, 7).toUpperCase();
                const userDet = await userDetail.create({
                    fName: formData.fName,
                    lName: formData.lName,
                    dob : moment(formData.dob,"YYYY-MM-DD").add(0, 'day').format('YYYY-MM-DD'),
                    userId: usr.dataValues.id,
                    uniqueId: formData.rollNo,
                    planId: '0',
                    info: formData.info,
                    grade: formData.grade,
                    needed: formData.needed,
                    help: formData.help,
                    superhero: formData.superhero,
                    rememberToken: '0',
                    status: '1',
                    referralCode: code,
                    lPoints: lPoints,
			  address: formData.address?formData.address:'',
                }, { transaction })

                await stdntInfo.create({
                    classId: formData.class,
                    houseId: formData.house,
                    sectionId: formData.section,
                    studentId: usr.dataValues.id,
                }, { transaction })

                //Send Mail
                var htmldata =
                  '<p>Hi ' + formData.fName + '</p>' +
                  '<p>You account has been created successfully. Below are the login Credentails:- </p>' +
                  '<p>Email Id:  '+formData.email+'</p>  ' +
                  '<p>Password:  '+formData.password+' </p>' +
                  '<p>Thanks,</p>' +
                  '<p>Team Cere Consult</p>' +
                  '<p>--------</p>' +
                  '<p>This is an automated email. Please do not reply to it.</p>' +
                  '<p>In case of any help, kindly reach us at - please reach us at info@consult.com" for any help" etc.</p>';
                var subject = "Cere consult Signup Successfully!";
                common.sendMail(formData.email,htmldata,companyId,subject);
                await transaction.commit();

                if(refreeUser != "")
                {
                    //Refree User
                    var message = "Points added to your account by using "+checkRefrr.dataValues.fName+"'s referral code";
                    common.addLoyality(userDet.dataValues.userId,checkRefrr.dataValues.userId,message,lPoints);

                    //Own User
                    var message = "Points added to your account as your friend "+formData.fName+" used your referral code";
                    common.addLoyality(checkRefrr.dataValues.userId,userDet.dataValues.userId,message,lPoints);
                }
                const result = {
                    userName: userDet.dataValues.fName,
                    userId: userDet.dataValues.userId,
                    status: userDet.dataValues.status,
                    authToken: await createToken(usr.dataValues),
                    type: 1,
                    referralCode:code,
                    colorCode: "#373E80"
                };
                return helpers.jsonResponse(
                    res,
                    true,
                    result,
                    "successfull_signup",
                    200,
                    200
                );
            }
        }
        else return responseHelper.post(res, appstrings.code_invalid, null, 400);

        } catch (e) {
            if (transaction) await transaction.rollback();
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    ////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// get student based on class and section //////////////
    ////////////////////////////////////////////////////////////////////////////// 

    classStudent: async function (req, res) {
        try {

            const student = await stdntInfo.findAll({
                attributes: ['id'],
                where: {
                    status: 1,                     /// only active
                    classId: req.params.classId,
                    sectionId:req.params.sectionId
                },
                include: [{
                    attributes: ['fName', 'lName','userId'],
                    model: userDetail
                }]
            });
            if (student) {
            
                return helpers.jsonResponse(
                    res,
                    true,
                    student,
                    "List",
                    200,
                    200
                );
            }

        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    ////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// get all active students /////////////////////////////
    ////////////////////////////////////////////////////////////////////////////// 

    list: async function (req, res) {
        try {

            const student = await stdntInfo.findAll({
                attributes: ['id','classId','sectionId'],
                where: {
                    status: 1,                     /// only active
                },
                include: [
                    {
                    attributes: ['fName', 'lName','userId'],
                    model: userDetail
                    },
                    {
                        attributes: ['email','password'],
                        model: user
                        },
                    {
                    attributes: ['name'],
                    model: classes
                    },
                    {
                        attributes: ['name'],
                        model: section
                        }
                ]
            });
            if (student) {
            
                return helpers.jsonResponse(
                    res,
                    true,
                    student,
                    "List",
                    200,
                    200
                );
            }

        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


       ////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// delete active  students /////////////////////////////
    ////////////////////////////////////////////////////////////////////////////// 

    delete: async function (req, res) {
        try {

           const del = await user.destroy({
            where: {
               id: req.params.id
            }
        })
            if (del) {
            
                return helpers.jsonResponse(
                    res,
                    true,
                    {},
                    "Success",
                    200,
                    200
                );
            }

        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    ////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// Contact US /////////////////////////////
    ////////////////////////////////////////////////////////////////////////////// 
    contactus: async function (req, res) {
        try {
            const data  = req.body;
		const usr = await contactus.create({
                phoneNumber: data.phoneNumber,
                query: data.query,
                email: data.email,
                name: data.name,
                type:1,
		       companyId:req.parentCompany
            });
            //Send Mail
                var htmldata =
                  '<p>Hi Admin</p>' +
                  '<p>'+data.name+' has sent a query:- </p>' +
                  '<p>'+data.message+'</p>  ' +
                  '<p>Thanks,</p>' +
                  '<p>'+data.name+'</p>' +
                  '<p>'+data.email+'</p>' +
                  '<p>--------</p>' +
                  '<p>This is an automated email. Please do not reply to it.</p>' +
                  '<p>In case of any help, kindly reach us at - please reach us at '+config.SENDER_EMAIL+'" for any help" etc.</p>';
                var subject = "Let’s Discuss Requirement";
                var mailOptions = {
                  from: config.SENDER_EMAIL,
                  to: data.email,
                  subject: subject,
                  html: htmldata
                };
           
            return helpers.jsonResponse(
                res,
                    true,
                    {},
                    "Success",
                    200,
                    200
                );
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

      ////////////////////////////////////////////////////////////////////////////////
    /////////////////////////Get Profile /////////////////////////////
    ////////////////////////////////////////////////////////////////////////////// 

    getProfile: async function (req, res) {
        try {
            const id = req.params.id;
            const userdetails = await user.findOne({
                attributes: ['id','email'],
                where: {
                   id: id
                },
                include: [{
                    model: userDetail,
                    attributes: ['fName','lName','dob','uniqueId','languages','planId','age','rememberToken','info','grade','education','needed','help','superhero','summery','image','phoneNo','superPower','address','grade','hours','referralCode']
                }]
            })
            if (userdetails) {
                //User Bank Details
                const userBankdetails = await bankDetail.findOne({
                    attributes: ['bankName','userName','ifcCode','accountNumber'],
                    where: {
                       userId: id
                    }
                });
                //User subjects Details
                const userSubjectdetails = await teacherSubject.findAll({
                    attributes: ['teacherId','subjectId','subCategoryId'],
                    where: {
                       teacherId: id
                    },
                    include: [{
                        model: subjectDetail,
                        attributes: ['name']
                    }]
                })
                for (var i = 0; i < userSubjectdetails.length; i++) {
                    var subCateId = JSON.parse(userSubjectdetails[i].subCategoryId);
                    let subDetails = await subCategory.findAll({
                        attributes: ['id','name'],
                      where: {
                          isDeleted:0,
                          status:1,
                        id: {
                          [Op.in]: subCateId,
                         
                        }
                      }
                    });
                    userSubjectdetails[i].dataValues.subCategories = subDetails;
                }
                const data = {};
                data.userdetails    = userdetails;
                data.userBankdetail = userBankdetails;
                data.professionalSubject = userSubjectdetails;
                return helpers.jsonResponse(
                    res,
                    true,
                    data,
                    "Success", 
                    200,
                    200
                );
            }

        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    getProfessionalProfile: async function (req, res) {
        try {
            const validations = {
                userId: "required",
                professionalId: "required"
            };
            const Fdata = req.body;
            // Call Translate
            const matched = await helpers.validate(Fdata, validations);
             if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }

            var professionalId = Fdata.professionalId;
            // var userId         = "55ba8d76-0376-449d-a21f-9192b216976b";
            var userId         = req.id;
            const userdetails = await user.findOne({
                attributes: ['id','email',[sequelize.literal('(SELECT AVG(rating) FROM ratings where teacherId = users.id)'), 'totalRating']],
                where: {
                   id: professionalId
                },
                include: [{
                    model: userDetail,
                    attributes: ['fName','lName','dob','uniqueId','age','planId','rememberToken','info','grade','needed','help','superhero',['summery','aboutUs'],'image','phoneNo','superPower','address','education','grade','hours','languages']
                }]
            })
            if (userdetails) {
                const userRecent = await recentSearch.findOne({
                    where: {
                       professionalId: professionalId,
                        userId: userId
                    }
                });
                if(!userRecent)
                {
                    //Add Recent Search
                    const usr = await recentSearch.create({
                        professionalId: professionalId,
                        userId: userId
                    });
                }
                

                //User Bank Details
                const userBankdetails = await bankDetail.findOne({
                    attributes: ['bankName','userName','ifcCode','accountNumber'],
                    where: {
                       userId: professionalId
                    }
                });
                //User subjects Details
                const userSubjectdetails = await teacherSubject.findAll({
                    attributes: ['teacherId','subjectId','subCategoryId'],
                    where: {
                       teacherId: professionalId
                    },
                    include: [{
                        model: subjectDetail,
			attributes: ['name']
                    }]
                        // },{
                        //     model: subCategory,
                        //     attributes: ['name']
                        // }]
                });

                for (var i = 0; i < userSubjectdetails.length; i++) {
                    var subCateId = JSON.parse(userSubjectdetails[i].subCategoryId);
                   
                    let subDetails = await subCategory.findAll({
                        attributes: ['id','name'],
                      where: {
			status:1,
			 isDeleted:0,  
                        id: {
                          [Op.in]: subCateId,
				 
                        }
                      }
                    });
                    userSubjectdetails[i].dataValues.subCategories = subDetails;
                }
                const data = {};
                data.userdetails    = userdetails;
                data.userBankdetail = userBankdetails;
                data.Subject        = userSubjectdetails;
                return helpers.jsonResponse(
                    res,
                    true,
                    data,
                    "Success", 
                    200,
                    200
                );
            }

        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////
    /////////////////////////Add Booking For Student//////////////////
    //////////////////////////////////////////////////////////////////
    addBooking:  async function (req, res) {

        const params = req.body;
        //Check User Token
        var userdetails = await userDetail.findOne({
            attributes: ['rememberToken','fName'],
            where :{
                userId: params.userId
            }
        })
        if(parseInt(userdetails.dataValues.rememberToken) < 50 || userdetails.dataValues.rememberToken == "" )
        {
            return helpers.jsonResponse(res,true,{},appstrings.no_credit,400,200);
        }
       // var days=['sun','mon','tue','wed','thu','fri','sat']
        var days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        var date1    = new Date(params.date)
        var dayCount = days[date1.getDay()]
        var schedules= await SCHEDULE.findOne({where :{userId: params.teacherId,dayParts:dayCount}})
        if(schedules)
        {
            var slotdata = JSON.parse(schedules.dataValues.slots);
            var startDate= params.time
            var slotsBookingsAlowed = 0
		let slotDuration = schedules.dataValues.timeInterval
		
		// check for the previous booking on the booking Date
             var previousBookingStatus = await TeacherBooking.findOne({
                where :{
                    teacherId: params.teacherId,
                    bookingDate: params.date,
                    status:1,
                    slotDuration:{ [Op.ne]:slotDuration } // if other than current slot
                }
            });
            if(previousBookingStatus){
                return helpers.jsonResponse(res,true,{},appstrings.old_booking_pending,400,200);
            }

            var bookingstatus = await TeacherBooking.findOne({
                where :{
                    teacherId: params.teacherId,
                    bookingDate: params.date,
                    timeSlot: startDate,
                    status:1

                }
            });
            if(bookingstatus)   
            {
                return helpers.jsonResponse(res,true,{},appstrings.slot_full,400,200);
            }  
              var studentRequests = await StudentbookingDetail.findOne({
                where :{
                    studentId: params.userId,
                    timeSlot: params.time,
                    bookingDate : params.date,

                },
		include:[{
                    model:bookingNotification,
                    where:{status:1},
                    required:true
                   
                }]
		})

            if(studentRequests)  {
                return helpers.jsonResponse(res,true,{},appstrings.already_slot_booked,400,200);
            } 

            const companyId = req.parentCompany ? req.parentCompany : config.STATIC_COMPANYID;
   	  const slot = await common.changeHourFormat(params.time)
            //Create Booking Details
            const getBookingDetails = await StudentbookingDetail.create({
                studentId: params.userId,
                companyId: companyId,
                bookingDate : params.date,
                timeSlot: params.time,
                credit: params.credit,
                packageId: params.packageId,
                couponId: params.couponId,
                couponDiscount: params.couponDiscount,
                membershipDiscount: params.membershipDiscount,
                totalCredit: params.totalCredit,
		slot:slot,
		 slotDuration:slotDuration     // for schedule duration
            });

            var id = getBookingDetails.dataValues.id;

            //Get Teacher UserDetails
            var teacheruserdetails = await userDetail.findOne({
                attributes: ['fName','lName','deviceToken'],
                where :{
                    userId: params.teacherId
                },
                include: [{
                    model: user,
                    attributes: ['email']
                }]
            })
 	    //get the subject details
            let selectedSubDetails = await SubCategory.findOne({
                attributes: ['id','name'],
                where: {
                    id: params.subCategoryId
                }
            });
 
            var description = "You have been received booking request from "+userdetails.dataValues.fName+" for "+ selectedSubDetails.dataValues.name;
            var htmldata =
            '<p>Hi '+teacheruserdetails.dataValues.fName+'</p>' +
              '<p>'+description+'</p>  ' +
              '<p>Thanks,</p>' +
              '<p>info@onlineconsult.com</p>' +
              '<p>--------</p>' +
              '<p>This is an automated email. Please do not reply to it.</p>' +
              '<p>In case of any help, kindly reach us at - please reach us at info@onlineconsult.com" for any help" etc.</p>';
            var subject = "Booking Request!";
            common.sendMail(teacheruserdetails.user.email,htmldata,companyId,subject);

            //Send Notification
            if(teacheruserdetails.dataValues.deviceToken != "")
            { 
                common.sendNotification([teacheruserdetails.dataValues.deviceToken],description,subject);
            }
            
            //Send Notification to Teacher
            const usr = await bookingNotification.create({
                bookId: id,
                companyId: companyId,
                teacherId: params.teacherId,
                subjectId: params.subjectId,
                subCategoryId: params.subCategoryId,
                description: 'You will be receive booking request',
                status: '0',
		createdAt: Math.floor(new Date().getTime() / 1000)
            });
            
            return helpers.jsonResponse(res,true,{},appstrings.send_notification,200,200);
   
        }else{
            return helpers.jsonResponse(res,true,{},appstrings.slot_full, 400, 400);
        }
    },


    ////////////////////////////////////////////////////////
    /////////////////////////Get All Slots//////////////////
    ////////////////////////////////////////////////////////
    getAllSlots: async function (req, res) {
        try {
            const params = req.body;
            //var teacherId = params.subjectId;
            var professionalId = params.professionalId;
            //var days=['sun','mon','tue','wed','thu','fri','sat'];
            var days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var dat = params.date;
            var date1    = new Date(dat)
            var dayCount = days[date1.getDay()]
            var teachers = await teacherSubject.findAll({
                where :{
                    subjectId: params.subjectId,
                    teacherId: professionalId,
                    status: '1'
                }
            })
            var slotsA=[];
            if(teachers.length == 0 )
            {
                return helpers.jsonResponse(res, true,{},"Sorry! No teacher are available for this subjects.", 400, 400);
            }
            var mainArray  = [];
           // for (var i = 0; i < teachers.length; i++) {
                var teacherId = params.professionalId;
                //Get 
                var schedules= await SCHEDULE.findOne({
                    attributes: ['id','dayParts','slots'],
                    where :{
                        userId: teacherId,
                        dayParts:dayCount,
                        // fromDate: {
                        //     [Op.lte]: dat
                        // },
                        // toDate: {
                        //     [Op.gte]: dat
                        // },
                    }
                });
                if(schedules)
                {
                    var slotdata = JSON.parse(schedules.dataValues.slots);
                    for(var k=0;k<slotdata.length;k++ )
                    {
                        //Compare Time
                        var compareDate = dat+' '+slotdata[k].slot;
                        compareDate = new Date(compareDate);
                        let checkCompare = await common.compareDateTime(compareDate);
                        
                        if(checkCompare == "false")
                        {   
                            var slot = {};
                            slot.time = slotdata[k].slot;
                           // var slot = slotdata[k].slot;
                            var bookingstatus = await TeacherBooking.findOne({
                                where :{
                                    teacherId: teacherId,
                                    bookingDate:dat,
                                    timeSlot: slotdata[k].slot,
				     status:{
                                        [Op.notIn]:[1,4]         
                                    }
                                }
                            });


                            if(!bookingstatus) 
                            {
                                slot.bookingStatus = "false";
                                slotsA.push(slot)
                            }else{
                                slot.bookingStatus = "true";
                                slotsA.push(slot);
                            }
                        }
                    }
                }
            //}
            
            // var uniqueNames = [];
            // slotsA.forEach(function(item) {
            //      if(uniqueNames.indexOf(item) < 0) {
            //         let array = {};
            //         array.time = item;
            //         uniqueNames.push(array);
            //      }
            // });
            if(slotsA.length >0)
            {
                return helpers.jsonResponse(res,true,slotsA,"Success",200,200);
            }else{
                return helpers.jsonResponse(res,true,[],"No Slots Available",200,200);
            }
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////
    /////////////////////////Add Token For Student//////////////////
    //////////////////////////////////////////////////////////////////
    addToken:  async function (req, res) {
        try{
        const params = req.body;
        const subscription = await tokens.findOne({
            where: {
                id: params.planId
            }
        }); 
        if(params.planId != '7')
        {
            var totaltoken = subscription.dataValues.token_count;
        }else{
            let per            = parseInt(params.amount);
            let discount_price = per*(20/100);        // Get Discount Token
            var totaltoken     = per + discount_price;  //Get Total Token
           // var totaltoken = parseInt(params.amount) * 12;
        }
        //Check User Token
        var userdetails = await userDetail.findOne({
            attributes: ['rememberToken'],
            where :{
                userId: params.userId
            }
        })
        //var tokenAmount = params.amount;
        const teacherUpdate = await userDetail.update({
            rememberToken: sequelize.literal('rememberToken +' + totaltoken)
        }, {
            where: {
                userId: params.userId
            }
        })
	
        var tokenBalance = parseInt(userdetails.dataValues.rememberToken) + parseInt(totaltoken);
        //Teacher Token Histoy Create
        await addTokenHistory(params.userId,params.userId,1,totaltoken,tokenBalance,"Purchased");
        return helpers.jsonResponse(res,true,{"buyer":params.userId,"token":tokenBalance,"purchased at":new Date().toLocaleTimeString()},"Success",200,200);
    } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
        }
    },

   //////////////////////////////////////////////////////////////////
    /////////////////////////Token History Student//////////////////
    //////////////////////////////////////////////////////////////////
    sTokenHistory:  async function (req, res) {
        try{
        const id = req.id;
        //Check User Token
        var datat = await userTokenHistory.findAll({
            attributes: ['token','tokenBalance','status','type','createdAt','receiverId','modifiedAt'],
            where :{
                senderId: id
            },
            order: [
                ['id', 'DESC']
            ],
        })
        var mainArray  = [];
        for (var i = 0; i < datat.length; i++) {
            var array = {};
            var token = datat[i].token;
            var tokenBalance = datat[i].tokenBalance;
            var status = datat[i].status;
            if(status == '1')
            {
                var type = datat[i].type;
            }else{
                var userdetails = await userDetail.findOne({
                    where :{
                        userId: datat[i].receiverId
                    }
                })
                var type = "Paid to " + userdetails.dataValues.fName + ' ' +userdetails.dataValues.lName;
            }
            array.token        = token;
            array.tokenBalance = tokenBalance;
            array.type         = type;
            var theDate = new Date( datat[i].createdAt * 1000);
            var dateString = await common.formatAMPM(theDate);
            //var dateString = theDate.toGMTString();
        //     if(datat[i].modifiedAt)
		// array.createdAt =new Date( datat[i].modifiedAt ).toLocaleString()
		// else
            array.createdAt    = dateString; 
            //array.createdAt    = datat[i].createdAt;
            mainArray.push(array);
        }
        return helpers.jsonResponse(res,true,mainArray,"Success",200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
        }
    },
    
    //////////////////////////////////////////////////////////////////
    /////////////////////////Student Booking list//////////////////
    //////////////////////////////////////////////////////////////////
    sBookingList:  async function (req, res) {
        try {
            const id = req.params.id;

            const topic = await TeacherBooking.findAll({
                attributes: ['id','bookingDate','slot','teacherId','packageId','timeSlot','subjectId','credit','channelName','accessToken','status'],
		group:['bookingDate','slot'],
		order: [
                    ['bookingDate', 'DESC'],
			['slot','DESC']],
                where: {
                    userId:id,
                    status: {
                        [Op.ne]: '2'
                    },
 		
                }
            });
            var mainArray  = [];
            for (var i = 0; i < topic.length; i++) {
                var array       = {};
                var bookingDate = topic[i].bookingDate;
                var teacherId   = topic[i].teacherId;
                var timeSlot    = topic[i].timeSlot;

                var userdetails = await userDetail.findOne({
                    where :{
                        userId: teacherId
                    }
                })

                var packagedetails = await Packages.findOne({
                    where :{
                        id: topic[i].packageId
                    }
                })

                //Get Subject Details
                if( topic[i].subjectId != null)
                {
                    var subjectdetails = await subjectDetail.findOne({
                        where :{
                            id: topic[i].subjectId
                        }
                    })
                    var subName = subjectdetails.dataValues.name;
                }else{
                    var subName = "";
                }
                
                array.id          = topic[i].id;
                array.bookingDate = bookingDate;
                array.teacherId   = teacherId;
                array.timeSlot    = timeSlot;
                array.channelName = topic[i].channelName;
                array.accessToken = topic[i].accessToken;
                array.subjectId   = topic[i].subjectId;
                array.subjectName = subName;
                array.credit      = topic[i].credit;
                array.status      = topic[i].status;
                array.fName       = userdetails.dataValues.fName;
                array.lName       = userdetails.dataValues.lName;
                array.image       = userdetails.image;
                array.duration = packagedetails.dataValues.minute;
                mainArray.push(array);
            }
            return helpers.jsonResponse(res,true,mainArray,"Success",200,200);

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    ///////////////////////////////////////////////////
    /////////// Update Profile ////////////////////////
    ///////////////////////////////////////////////////
    updateprofile: async function(req, res) { 
        try {
           
            let userId = req.id

            const validations = {
                fName:"required",
                lName:"required",
                dob:"required",
                phoneNo: "required",
                email:"required|email",
			};
           
			let matched = await helpers.validate(req.body, validations);
			if (!matched.status) {
                if (matched.data.fName) {
                    throw new handleError(appstrings.fName_required, 422);
                }
                if (matched.data.lName) {
                    throw new handleError(appstrings.lName_required, 422);
                }
				if (matched.data.dob) {
                    throw new handleError(appstrings.dob_required, 422);
                }
                if (matched.data.email) {
                    throw new handleError(appstrings.email_required, 422);
                }
                
                if (matched.data.phoneNo) {
                    throw new handleError(appstrings.phone_required, 422);
                }

                let ifemailtaken = await user.findOne({
                    where: {
                        email: req.body.email,
                        id:{[Op.ne]:req.id},
                        role:req.role
                    }
                });

                if (ifemailtaken) {
                    throw new handleError(appstrings.email_exists, 422);
                }
            }
            
            const formdata = req.body;

            let verifyUser = await user.findOne({
                where: {
                    id: req.id,
                }
            });
            if(verifyUser){

                var icon = "";
                if (req.files) {
                    ImageFile = req.files.image; 
                    if(ImageFile)
                    {
                      icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
                   
                      ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
                          //upload file
                          if (err)
                          return helpers.jsonResponse(res, false, {}, err.message, 400);
                          
                      });
                    }
                }

                    // update email
                let udpatedemail = await userDetail.update({ email :formdata.email},{where:{
                        id:userId
                    }
                })

                if(icon == "")
                {
                    var updateuserDetail = await userDetail.update({
                    fName: formdata.fName,
                    lName: formdata.lName,
                    dob : moment(formdata.dob,"YYYY-MM-DD").add(0, 'day').format('YYYY-MM-DD'),
                    info: formdata.info,
                    grade: formdata.grade,
                    needed: formdata.needed, 
                    help: formdata.help,
                    superhero: formdata.superhero,
                    summery: formdata.summery,
                    languages:formdata.languages,
                    phoneNo: formdata.phoneNo,
                    hours: formdata.hours,
                    superPower: formdata.superPower,
                    address: formdata.address,
                    age: formdata.age,
		    education:formdata.education
                },
                {
                    where : {
                        userId: userId
                    }
                });
                }else{
                    var updateuserDetail = await userDetail.update({
                    fName: formdata.fName,
                    lName: formdata.lName,
                    dob : moment(formdata.dob,"YYYY-MM-DD").add(0, 'day').format('YYYY-MM-DD'),
                    info: formdata.info,
                    grade: formdata.grade,
                    needed: formdata.needed, 
                    help: formdata.help,
                    superhero: formdata.superhero,
                    summery: formdata.summery,
                    languages:formdata.languages,
                    phoneNo: formdata.phoneNo,
                    hours: formdata.hours,
                    superPower: formdata.superPower,
                    address: formdata.address,
                    image: icon,
                    age: formdata.age,
		    education:formdata.education

                },
                {
                    where : {
                        userId: userId
                    }
                });
                }

                const userDetails  = await userDetail.findOne({
                   where: {
                     userId : userId
                   }
                 })
                return helpers.jsonResponse(
                    res,
                    true,
                    userDetails,
                    appstrings.profile_update_success,
                    200,
                    200
                );
            }else{
                return helpers.jsonResponse(res, false, {}, appstrings.user_not_exists,'', 206);
            }
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message,'', 400);
        }
    },

    //////////////////////////////////////////////////
    //////// Save Profile Image /////////////////////////
    /////////////////////////////////////////////////
    saveImage : async function(req, res) {   
        const timestamp = Math.round(new Date().getTime()/1000);
        const formData  = req.body;
        var ImageFile1  = req.files.image;
        ImageFile1.mv('public/images/'+timestamp + '.png', async function (err) {
            if (err)
                console.log(err);
            else {
                const cls = await userDetail.update(
                    {
                        image: `images/${timestamp}.png`
                    },
                    {
                        where:
                        {
                            userId: formData.userId
                        }
                    }
                )
            }
        });
   
        return helpers.jsonResponse(res, true, {}, "Success", 200, 200);
    },


    // addBooking:  async function (req, res) {
    //     try{
    //     const params = req.body;
    //     //Check User Token
    //     var userdetails = await userDetail.findOne({
    //         attributes: ['fName','rememberToken'],
    //         where :{
    //             userId: params.userId
    //         }
    //     })
    //     if(parseInt(userdetails.dataValues.rememberToken) < 50 || userdetails.dataValues.rememberToken == "" )
    //     {
    //         return helpers.jsonResponse(res, true,{},"Sorry! You dont have enough credit. Minimum 50 credits required.", 201, 201);
    //     }
    //     var days=['sun','mon','tue','wed','thu','fri','sat'];
    //     var dat = params.date;
    //     var date1    = new Date(params.date)
    //     var dayCount = days[date1.getDay()];
       
    //     //Get All teacher
    //     var teachers = await teacherSubject.findAll({
    //         where :{
    //             subjectId: params.subjectId,
    //             status: '1'
    //         }
    //     })
    //     if(teachers.length == 0 )
    //     {
    //         return helpers.jsonResponse(res, true,{},"Sorry! No teacher are available for this subjects.", 400, 400);
    //     }
    //     var mainArray  = [];
        
    //     //Create Booking Details
    //     const getBookingDetails = await StudentbookingDetail.create({
    //         studentId: params.userId,
    //         bookingDate : params.date,
    //         timeSlot: params.time,
    //         credit: params.credit
    //     }); 
    //     var id = getBookingDetails.dataValues.id;

    //     for (var i = 0; i < teachers.length; i++) {
    //         var teacherId = teachers[i].teacherId;
    //         //Get 
    //         var schedules= await SCHEDULE.findOne({
    //             attributes: ['id','dayParts','slots'],
    //             where :{
    //                 userId: teacherId,
    //                 dayParts:dayCount,
    //                 fromDate: {
    //                     [Op.lte]: dat
    //                 },
    //                 toDate: {
    //                     [Op.gte]: dat
    //                 },
    //             }
    //         })
    //         if(schedules)
    //         {
                
    //             var slotdata = JSON.parse(schedules.dataValues.slots);
    //             var startDate= params.time
    //             var slotsBookingsAlowed = 0
    //             var bookingstatus = await TeacherBooking.findOne({
    //                 where :{
    //                     teacherId: teacherId,
    //                     bookingDate: params.date,
    //                     timeSlot: startDate
    //                 }
    //             });
    //             if(!bookingstatus)   
    //             {
    //                 mainArray.push(teacherId);

    //                 //Send Notification
    //                 //Get Teacher UserDetails
    //                 var teacheruserdetails = await userDetail.findOne({
    //                     attributes: ['fName','lName','deviceToken'],
    //                     where :{
    //                         userId: teacherId
    //                     },
    //                     include: [{
    //                         model: user,
    //                         attributes: ['email']
    //                     }]
    //                 })
    //                 var description = "You have been received booking request from "+userdetails.dataValues.fName;
    //                 var htmldata =
    //                 '<p>Hi '+teacheruserdetails.dataValues.fName+'</p>' +
    //                   '<p>'+description+'</p>  ' +
    //                   '<p>Go To Request list. Accept this!</p>  ' +
    //                   '<p>Thanks,</p>' +
    //                   '<p>info@k12superhero.com</p>' +
    //                   '<p>--------</p>' +
    //                   '<p>This is an automated email. Please do not reply to it.</p>' +
    //                   '<p>In case of any help, kindly reach us at - please reach us at info@k12superhero.com" for any help" etc.</p>';
    //                 var subject = "Booking Request!";
    //                 var mailOptions = {
    //                   from: "info@k12superheroes.com",
    //                   to: teacheruserdetails.user.email,
    //                   subject: subject,
    //                   html: htmldata
    //                 };
    //                 transporter.sendMail(mailOptions, function(error, info){
    //                     if (error) {
    //                         console.log("error",error)
    //                         return helpers.jsonResponse(res, false, {}, "error", 400,400);
    //                     }
    //                 });
    //                 if(teacheruserdetails.dataValues.deviceToken != "")
    //                 {
                        
    //                     var message = {
    //                         to: teacheruserdetails.dataValues.deviceToken,
    //                         notification: { 
    //                             "title": "Booking Request", 
    //                             "body": description
    //                         },
    //                         priority: "high",
    //                         data: { 
    //                             "title": "Booking Request", 
    //                             "body": description
    //                         }
    //                     };
    //                     fcm.send(message, function (err, response) {
    //                         if (err) {
    //                             console.log(err);
    //                             console.log("Error >>>>>>>>>> " + err);
    //                         } else {
    //                             console.log("Success >>>>>>>>>> " + response);
    //                         }
    //                     });
    //                 }
                    
    //                 //Send Notification to Teacher
    //                 const usr = await bookingNotification.create({
    //                     bookId: id,
    //                     teacherId: teacherId,
    //                     subjectId: params.subjectId,
    //                     description: 'You will be receive booking request',
    //                     status: '0',
            //createdAt: Date.now()

    //                 });
    //             }  
    //         }
    //     }
    //     if(mainArray.length > 0)
    //     {
    //         return helpers.jsonResponse(res,true,{},"Send Notification to teacher successfully",200,200);
    //     }else{
    //         return helpers.jsonResponse(res, true,{},"Sorry! No teacher are available at this time.", 400, 400);
    //     }
    //     } catch (e) {
    //         return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
    //     }
        
    // },

    

    ////////////////////////////////////////////////////////////
    /////////////////////////Get Plan list//////////////////
    ////////////////////////////////////////////////////////////
    getPlanlist:  async function (req, res) {
        try {
            const subscription = await tokens.findAll({
                attributes: ['id','token_count','token_amount','description'],
                where: {
                    status: '1'
                }
            }); 
            return helpers.jsonResponse(res,true,subscription,"Success",200,200);

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    ///////////////////////////////////////////////////
    ///////// FeedBack Student To Teacher ////////////
    /////////////////////////////////////////////////
    feedbackToTeacher: async function (req, res) {

        let transaction;
        let formData = req.body;
        let userId = req.id
        var subject = "Feedback";
        var index = fs.readFileSync('html/feedback-teacher.html', 'utf8');
        var renderedHtml = ejs.render(index, 
        formData); 
        var mailOptions = {
            from: 'info@k12superheroes.com',
            to: formData.parentEmail,
            subject: subject,
             // forceEmbeddedImages: true,
            html: renderedHtml
        };
        transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
              return false;
            }
              return true;
        });
        transaction = await sequelize.transaction();
        const userDet = await feedbacks.create({
            parentName: "",
            subject: formData.subject,
            datetime: formData.datetime,
            tutorName: formData.tutorName,
            step1: "",
            step2: "",
            step3: "",
            step4: "",
            rememberThings: formData.rememberThings,
            progress: "",
            learned: "",
            rating: formData.rating,
            excercises: "",
            tips: "",
            amount: "",
            studentEmail: formData.studentEmail,
            parentEmail: formData.parentEmail,
            studentName: formData.studentName,
            userId: userId,
        }, { transaction })
        await transaction.commit();
        
        return helpers.jsonResponse(
            res,
            true,
            appstrings.feedback_success,
            200,
            200
        );


    },


    ////////////////////////////////////////////////////////////
    /////////////////////////Cancel Booking//////////////////
    ////////////////////////////////////////////////////////////
    cancelBooking:  async function (req, res) {
        try {
            var date = new Date();
            date.setDate(date.getDate() + 2);
            var year = date.getFullYear().toString();
            var month = (date.getMonth() + 101).toString().substring(1);
            var day = (date.getDate() + 100).toString().substring(1);

            var newdate = year + "-" + month + "-" + day; 
            
            const data = req.body;
            const subscription = await TeacherBooking.destroy({
                where: {
                    id: data.bookId,
                    bookingDate: {
                        [Op.gte] : newdate
                    }
                }
            }); 
            if(subscription>0){
                return helpers.jsonResponse(
                res,
                true,
                appstrings.booking_cancel_success,
                200,
                200
            );
            }else{
                return helpers.jsonResponse(
                res,
                true,
                appstrings.booking_cancel_failure,
                 201, 201
            );
            }
            
        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /**
    *@role Edit Reschedule
    */
    updateBooking:  async function (req, res) {
        try{
        const params = req.body;

        const getPreviousBooking = await TeacherBooking.findOne({
            where: {
                id: params.bookId
            }
        }); 
        //Check User Token
        var userdetails = await userDetail.findOne({
            attributes: ['fName','rememberToken'],
            where :{
                userId: params.userId
            }
        })
        if(parseInt(userdetails.dataValues.rememberToken) < 50 || userdetails.dataValues.rememberToken == "" )
        {
            return helpers.jsonResponse(res, true,{},appstrings.no_credit, 201, 201);
        }
        var days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        var dat = params.date;
        var date1    = new Date(params.date)
        var dayCount = days[date1.getDay()];
       
        //Get All teacher
        var teachers = await teacherSubject.findAll({
            where :{
                subjectId: params.subjectId,
                status: '1'
            }
        })
        if(teachers.length == 0 )
        {
            return helpers.jsonResponse(res, true,{},appstrings.no_professional, 400, 400);
        }
        var mainArray  = [];
        const companyId = req.parentCompany ? req.parentCompany : STATIC_COMPANYID;
        //Create Booking Details
        const getBookingDetails = await StudentbookingDetail.create({
            studentId: params.userId,
            companyId: companyId,
            bookingDate : params.date,
            timeSlot: params.time,
            credit: params.credit
        }); 
        var id = getBookingDetails.dataValues.id;

        for (var i = 0; i < teachers.length; i++) {
            var teacherId = teachers[i].teacherId;
            //Get 
            var schedules= await SCHEDULE.findOne({
                attributes: ['id','dayParts','slots'],
                where :{
                    userId: teacherId,
                    dayParts:dayCount,
                    // fromDate: {
                    //     [Op.lte]: dat
                    // },
                    // toDate: {
                    //     [Op.gte]: dat
                    // },
                }
            })
            if(schedules)
            {
                
                var slotdata = JSON.parse(schedules.dataValues.slots);
                var startDate= params.time
                var slotsBookingsAlowed = 0
                var bookingstatus = await TeacherBooking.findOne({
                    where :{
                        teacherId: teacherId,
                        bookingDate: params.date,
                        timeSlot: startDate
                    }
                });
                if(!bookingstatus)   
                {
                    mainArray.push(teacherId);

                    //Send Notification
                    //Get Teacher UserDetails
                    var teacheruserdetails = await userDetail.findOne({
                        attributes: ['fName','lName','deviceToken'],
                        where :{
                            userId: teacherId
                        },
                        include: [{
                            model: user,
                            attributes: ['email']
                        }]
                    })
                    var description = "You have received booking request from "+userdetails.dataValues.fName;
                    var htmldata =
                    '<p>Hi '+teacheruserdetails.dataValues.fName+'</p>' +
                      '<p>'+description+'</p>  ' +
                      '<p>Go To Request list. Accept this!</p>  ' +
                      '<p>Thanks,</p>' +
                      '<p>info@k12superhero.com</p>' +
                      '<p>--------</p>' +
                      '<p>This is an automated email. Please do not reply to it.</p>' +
                      '<p>In case of any help, kindly reach us at - please reach us at info@k12superhero.com" for any help" etc.</p>';
                    var subject = "Booking Request!";
                    common.sendMail(teacheruserdetails.user.email,htmldata,companyId,subject);
                    if(teacheruserdetails.dataValues.deviceToken != "")
                    {
                        common.sendNotification(teacheruserdetails.dataValues.deviceToken,description,subject);
                    }
                    
                    //Send Notification to Teacher
                    const usr = await bookingNotification.create({
                        bookId: id,
                        companyId: companyId,
                        teacherId: teacherId,
                        subjectId: params.subjectId,
                        description: 'You will be receive booking request',
                        status: '0',
                        createdAt: Math.floor(new Date().getTime() / 1000)

                    });
                }  
            }
        }

        //Get Student Email
        var StudentDetails = await user.findOne({
            attributes: ['email'],
            where :{
                id: params.userId
            }
        });
        var descriptionRes = "We have rescheduled your Live Super Tutor from "+getPreviousBooking.dataValues.bookingDate+ 'to'+params.date+"and appointment settings.";
        var htmldata =
        '<p>Hi '+userdetails.dataValues.fName+'</p>' +
          '<p>'+descriptionRes+'</p>  ' +
          '<p>Thanks,</p>' +
          '<p>info@k12superhero.com</p>' +
          '<p>--------</p>' +
          '<p>This is an automated email. Please do not reply to it.</p>' +
          '<p>In case of any help, kindly reach us at - please reach us at info@k12superhero.com" for any help" etc.</p>';
        var subject = "Booking Rescheduled!";
        common.sendMail(StudentDetails.dataValues.email,htmldata,companyId,subject);
        //Delete Previous Booking
        const subscription = await TeacherBooking.destroy({
            where: {
                id: params.bookId
            }
        }); 

        if(mainArray.length > 0)
        {
            return helpers.jsonResponse(res,true,{},appstrings.send_notification,200,200);
        }else{
            return helpers.jsonResponse(res, true,{},appstrings.no_professional, 400, 400);
        }
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
        }
        
    },


    /**
    *@Method GET
    *@role Get Restaurant List
    */
    homeAPI: async (req, res, next) => {
        try{
            const Maindata = {};
             const MainArray = [];
            var limit  = 5;
            var offset = 0;


            //Get Recent Search
            const getrecentSearchs = await recentSearch.findAll({
                attributes: ['userId','professionalId'],
                where: {
                   userId: req.id
                },
                include: [{
                    model: user,
                    include: [
                        {
                        model: teacherSubject,
                        required: true,
                        attributes: ['teacherId','subjectId','status'],
                        include: [{
                            model: subjectDetail,
                            attributes: ['name'],
			     where:{
                                status:1,
                                isDeleted:0, 
                            }		
                        }]
                        // },{
                        //     model: subCategory,
                        //     attributes: ['name']
                        // }]
                        
                    },{
                            model: userDetail,
                            attributes: ['fName','lName','dob','image','uniqueId'],
                            required: true,
                            where: {
                                status: '1'
                            } 
                        }
                    ],
                }],
                offset: offset, 
                limit: limit,
            })
            //User Subscription
            const findData = await USERSUB.findOne({
                attributes:['id','amount','duration','durationId','startDate','endDate'],
                where:{
                    status:1,
                    userId: req.id
                },
                include:[
                {
                  model:SUBSCRIPTION
                }]
            });


            //Get Free Delivery Restuarant
            var featured = await subjectDetail.findAll({
              attributes: ['id','name','image'],
		 where:{
                status:1,
                isDeleted:0,  
              }
            });
            for (var i = 0; i < featured.length; i++) 
            {
              var array = {};
              var id = featured[i].id;
              var name = featured[i].name;
              array.type = name;
              array.categoryId = id;
              var restDetails = await user.findAll({
                attributes: ['id','email',[sequelize.literal('(SELECT AVG(rating) FROM ratings where teacherId = users.id)'), 'totalRating']],
                where: {
                    role : '2'
                },
                order: sequelize.literal(`totalRating DESC`),
                include: [
                    {
                        model: teacherSubject,
                        required: true,
                        attributes: ['teacherId','subjectId','status'],
                        where: { 
                          subjectId: id
                        },
                        include: [{
                            model: subjectDetail,
                            attributes: ['name'],
				 where:{
                                status:1,
                                isDeleted:0,  
                              }
                        }]
                        // },{
                        //     model: subCategory,
                        //     attributes: ['name']
                        // }]
                        
                    },
                    {
                        model: userDetail,
                        attributes: ['fName','lName','dob','image','uniqueId'],
                        required: true,
                        where: {
                            status: '1'
                        } 
                    }
                ],
                offset: offset, 
                limit: limit,
              });
              array.professional = restDetails;
              if(restDetails.length > 0)
              {
                MainArray.push(array);
              }
            }

            const objColourCode = {
                colorCode: "#373E80",
                colorCode2: "#E3AC51"
            };
            Maindata.typeRest          = MainArray;   
            Maindata.categories        = featured;
            Maindata.popularcategories = featured;
            Maindata.recentSearches    = getrecentSearchs;
            Maindata.userSubscription  = findData;
            Maindata.colorCode         = objColourCode;
            const cls = await Banner.findAll({
                attributes: ['id', 'name','url'],
                where: {
                    status: 1                     /// only active
                }
            });
            Maindata.banners = cls;
            return helpers.jsonResponse(res,true,Maindata,"List fetch successfully",200,200);
        }
        catch (e) {
          return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
        }
    },

    /********** Add Rating to Professional*************/
    addRating: async function (req, res) {
        try {
            const validations = {
                professionalId: "required",
                bookingId: "required",
                rating: "required"
            };
            const data = req.body;
            // Call Translate
            const matched = await helpers.validate(data, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }
            var userId = req.id;
            var teacher = data.professionalId;
            var rating = data.rating;
            const usr = await ratingProfessional.create({
                userId: userId,
                teacherId: teacher,
                BookingId: data.bookingId,
                helpful: data.helpful,
                moneyValue: data.moneyValue,
                communication: data.communication,
                overall: data.overall,
                professionalKnow: data.professionalKnow,
                rating: rating,
                comment: data.comment
            });
            return helpers.jsonResponse(res,true,{},appstrings.ratings_success,200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /**
    *@Method GET
    *@role Search API
    */
    search: async (req, res, next) => {
        try{
            const data = req.body;
            var search = data.name;
            var status = data.status; //0->Professional , 1->Category
            const Maindata = {};
            const MainArray = [];
            var limit  = 5;
            var offset = 0;
            var where = {
              status: '1'
            }
            //Search With Service Name and Restaurants Name
            if(search != "")
            {
                where.fName = {
                    [Op.like]: `%${search}%`
                };
            }
            var featured = await subjectDetail.findAll({
                attributes: ['id','name']
            });
            

              var restDetails = await user.findAll({
                attributes: ['id','email',[sequelize.literal('(SELECT IFNULL(AVG(rating), 0) FROM ratings where teacherId = users.id)'), 'totalRating']],
                where: {
                    role : '2'
                },
		order: sequelize.literal('totalRating DESC'),
                include: [
                    {
                        model: teacherSubject,
                        required: true,
                        attributes: ['teacherId','subjectId','status'],
                        include: [{
                            model: subjectDetail,
                            attributes: ['name']
                        }]
                        // },{
                        //     model: subCategory,
                        //     attributes: ['name']
                        // }]
                    },
                    {
                        model: userDetail,
                        attributes: ['fName','lName','dob','image','uniqueId'],
                        required: true,
                        where: where
                    }
                ],
              });
              
              if(restDetails.length > 0)
              {
                MainArray.push(restDetails);
              }
            
            Maindata.typeRest          = MainArray;   
            Maindata.categories        = featured;
            Maindata.popularcategories = featured;

            const cls = await Banner.findAll({
                attributes: ['id', 'name','url'],
                where: {
                    status: 1                     /// only active
                }
            });
            Maindata.banners = cls;
            return helpers.jsonResponse(res,true,Maindata,appstrings.list_fetch_success,200,200);
        }
        catch (e) {
          return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
        }
    },

    /**
    *@Method GET
    *@role Search API
    */
    searchtest: async (req, res, next) => {
        try{
            const data = req.body;
            var search = data.name;
            var status = data.status; //0->Professional , 1->Category
            const Maindata = {};
            const MainArray = [];
            var limit  = 5;
            var offset = 0;
            var where = {
              status: '1'
            }
            if(status == '1')
            {
                var featured = await subjectDetail.findAll({
                    attributes: ['id','name','image'],
                    where: {
                       name: {[Op.like] : `%${search}%`}
                    }
                });
            }else{

                //Search With Service Name and Restaurants Name
                if(search != "")
                {
                    // var where = {
                    //     status: '1',
                    //     [Op.or] : [
                    //       {"$fName$" : {[Op.like] : `%${search}%`}},
                    //       {"$fName$" : {[Op.like] : `%${searchh}%`}}
                    //     ]
                    // }
                    where.fName = {
                        [Op.like]: `%${search}%`
                    };
                }
                var featured = await subjectDetail.findAll({
                    attributes: ['id','name']
                });
            }
           
            for (var i = 0; i < featured.length; i++) 
            {
              var array = {};
              var id = featured[i].id;
              var name = featured[i].name;
              array.type = name;
              array.categoryId = id;
              var restDetails = await user.findAll({
                attributes: ['id','email'],
                where: {
                    role : '2'
                },
                include: [
                    {
                        model: teacherSubject,
                        required: true,
                        attributes: [],
                        where: { 
                          subjectId: id
                        }
                    },
                    {
                        model: userDetail,
                        attributes: ['fName','lName','dob','image','uniqueId'],
                        required: true,
                        where: where
                    }
                ],
              });
              array.professional = restDetails;
              if(restDetails.length > 0)
              {
                MainArray.push(array);
              }
            }
            Maindata.typeRest          = MainArray;   
            Maindata.categories        = featured;
            Maindata.popularcategories = featured;

            const cls = await Banner.findAll({
                attributes: ['id', 'name','url'],
                where: {
                    status: 1                     /// only active
                }
            });
            Maindata.banners = cls;
            return helpers.jsonResponse(res,true,Maindata,appstrings.list_fetch_success,200,200);
        }
        catch (e) {
          return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
        }
    },

    /////////////////////////////////////////////////////////////////
    /////////////////////////Get Pending Request List////////////////
    /////////////////////////////////////////////////////////////////
    getPendinglist:  async function (req, res) {
        try {
            const id = req.params.id;
            const usr = await bookingNotification.findAll({
                attributes: ['bookId','teacherId','description','status'],
                where: {
                    status: '0'
                },
                include: [{
                    model: StudentbookingDetail,
                    attributes: ['id','studentId','bookingDate','timeSlot'],
                    where: {
                        studentId: id
                    },
                    required: true,
                    include: [{
                        model: userDetail,
                        attributes: ['fName','lName','image']
                    }]
                }]
            });
            console.log(usr);
            var mainArray = [];
            for (var i = 0; i < usr.length; i++) {
                var array       = {};
                var bookingDate = usr[i].bookingDetail.bookingDate;
                var teacherId   = usr[i].teacherId;
                var timeSlot    = usr[i].bookingDetail.timeSlot;

                var userdetails = await userDetail.findOne({
                    attributes: ['fName','lName','image'],
                    where :{
                        userId: teacherId
                    }
                })
                array.id          = usr[i].bookId;
                array.bookingDate = bookingDate;
                array.teacherId   = teacherId;
                array.timeSlot    = timeSlot;
                array.fName       = userdetails.dataValues.fName;
                array.lName       = userdetails.dataValues.lName;
                array.image       = userdetails.image;
                mainArray.push(array);
            }
            return helpers.jsonResponse(res,true,mainArray,appstrings.success,200,200);
           // return helpers.jsonResponse(res,true,usr,"Success",200,200);
            
            
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    ////////////////////////////////////////////////////////////
    /////////////////////////Get Complete list//////////////////
    ////////////////////////////////////////////////////////////
    getCompleteClass:  async function (req, res) {
        try {
            const id = req.params.id;

            const topic = await TeacherBooking.findAll({
                attributes: ['id','bookingDate','teacherId','timeSlot',
                [sequelize.literal('(SELECT count(id) FROM ratings where bookingId = bookings.id)'), 'ratingStatus']],
                where: {
                    userId:id,
                    status: '2'
                }
            });
            var mainArray  = [];
            for (var i = 0; i < topic.length; i++) {
                var array       = {};
                var bookingDate = topic[i].bookingDate;
                var teacherId   = topic[i].teacherId;
                var timeSlot    = topic[i].timeSlot;

                var userdetails = await userDetail.findOne({
                    attributes: ['fName','lName','image'],
                    where :{
                        userId: teacherId
                    }
                })
                array.id          = topic[i].id;
                array.bookingDate = bookingDate;
                array.teacherId   = teacherId;
                array.timeSlot    = timeSlot;
                array.fName       = userdetails.dataValues.fName;
                array.lName       = userdetails.dataValues.lName;
                 array.image       = userdetails.image;
                mainArray.push(array);
            }
            return helpers.jsonResponse(res,true,mainArray,"Success",200,200);

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
 getCompleteClassAdmin:  async function (req, res) {
        try {
            const id = req.params.id;
            let param =req.body
            let search =''
            let state = 2
            if (param.page) page = param.page
            if (param.limit) limit = parseInt(param.limit)
            if(param.state) state =param.state
			if (param.search) search = param.search
	
            var offset = (page - 1) * limit
            let  where = {
                userId:id,
                status: state,
                    [Op.or]: [
                      sequelize.where( sequelize.fn("concat", sequelize.col("tutor.fName"),' ', sequelize.col("tutor.lName")), {[Op.like]: `%${search}%` }), 
                      { '$tutor.fName$': { [Op.like]: `%${search}%` } },
                      { '$tutor.lName$': { [Op.like]: `%${search}%` } },
                      { '$subjectTaken.name$': { [Op.like]: `%${search}%` } },
                    ],
                  }
            const topic = await TeacherBooking.findAndCountAll({
                
                attributes: ['id','bookingDate','teacherId','timeSlot','credit',
                [sequelize.fn('IFNULL', sequelize.col('tutor.fName'), ''), 'fName'],
                [sequelize.fn('IFNULL', sequelize.col('tutor.lName'), ''), 'lName'], 
                [sequelize.fn('IFNULL', sequelize.col('subjectTaken.name'), ''), 'subjectName'],  
                [sequelize.literal('(SELECT count(id) FROM ratings where bookingId = bookings.id)'), 'ratingStatus']],
                where: where,
                offset: offset, limit: limit,
                include:[
                    {
                    model:subjectDetail,
                    as:'subjectTaken'
                },
                {
                    model:userDetail,
                    as:'tutor'
                }
            ]
            });
           
            return helpers.jsonResponse(res,true,topic,"Success",200,200);

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
getPendinglistAdmin:  async function (req, res) {
        try {
            var page = 1
			var limit = 10
            const id = req.params.id;
            let param =req.body
            let search =''
            if (param.page) page = param.page
			if (param.limit) limit = parseInt(param.limit)
			// if (params.role) role = parseInt(params.role)
			if (param.search) search = param.search
			// if ( params.category ) category = params.category
			// console.log('-->',params.category)
            var offset = (page - 1) * limit
           
           let  where = {
            status: '0',
                [Op.or]: [
                  sequelize.where( sequelize.fn("concat", sequelize.col("teacher.fName"),' ', sequelize.col("teacher.lName")), {[Op.like]: `%${search}%` }), 
                  { '$teacher.fName$': { [Op.like]: `%${search}%` } },
                  { '$teacher.lName$': { [Op.like]: `%${search}%` } },
                  { '$subject.name$': { [Op.like]: `%${search}%` } },
                ],
              }
            const usr = await bookingNotification.findAndCountAll({
                attributes: ['bookId','subjectId','teacherId','description','status',
                [sequelize.fn('IFNULL', sequelize.col('teacher.fName'), ''), 'fName'],
                [sequelize.fn('IFNULL', sequelize.col('teacher.lName'), ''), 'lName'], 
                [sequelize.fn('IFNULL', sequelize.col('subject.name'), ''), 'subjectName'],  
                [sequelize.fn('IFNULL', sequelize.col('bookingDetail.credit'), ''), 'credit'], 
                [sequelize.fn('IFNULL', sequelize.col('bookingDetail.timeSlot'), ''), 'timeSlot'], 
                [sequelize.fn('IFNULL', sequelize.col('bookingDetail.bookingDate'), ''), 'bookingDate'],                    
                ],
                offset: offset, limit: limit,
                where: where,
                include: [{
                    model: StudentbookingDetail,
                    attributes: ['id','studentId','bookingDate','timeSlot','credit'],
                    where: { studentId: id },
                    required: true,
                    include: [
                        { model: userDetail, attributes: ['fName','lName','image'] },  
                    ]
                },
                { model:subjectDetail },
                { model: userDetail,as:'teacher', attributes: ['fName','lName','image'] }
            ]
            });
            return helpers.jsonResponse(res,true,usr,appstrings.success,200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
   listBooking:  async function (req, res) {
        try {
            const id = req.id;
            const type = req.params.type;
            var mainArray = [];
            if(type == "pending")
            {
                //Get Pending List
                const usr = await bookingNotification.findAll({
                    attributes: ['bookId','teacherId','description','status','subjectId',
			 [sequelize.literal('bookingDetail.slot'), 'slot'],
			 [sequelize.literal('bookingDetail.bookingDate'), 'bookingDate'],
			],
                     group:['bookingDate','slot'],
                     logging:console.log,
                    where: {
                        status: '0'
                    },
                    include: [{
                        model: StudentbookingDetail,
                        attributes: ['id','studentId','bookingDate','timeSlot','slot'],
                        where: {
                            studentId: id,
			   
                        },
                        required: true,
                        include: [{
                            model: userDetail,
                            attributes: ['fName','lName','image']
                        }]
                    }],
   		order: sequelize.literal('bookingDate,slot ASC')
                });
                                
                for (var i = 0; i < usr.length; i++) {
                    var array       = {};
                    var bookingDate = usr[i].bookingDetail.bookingDate;
                    var teacherId   = usr[i].teacherId;
                    var timeSlot    = usr[i].bookingDetail.timeSlot;
		
                    var userdetails = await userDetail.findOne({
                        attributes: ['fName','lName','image'],
                        where :{
                            userId: teacherId
                        }
                    });
                    //Get Subject Details
                    if( usr[i].subjectId != null)
                    {
                        var subjectdetails = await subjectDetail.findOne({
                            where :{
                                id: usr[i].subjectId
                            }
                        })
                        var subName = subjectdetails.dataValues.name;
                    }else{
                        var subName = "";
                    }
			
                    array.id          = usr[i].bookId;
                    array.bookingDate = bookingDate;
                    array.teacherId   = teacherId;
                    array.timeSlot    = timeSlot;
		    array.slot        =  usr[i].bookingDetail.slot
                    array.fName       = userdetails.dataValues.fName;
                    array.lName       = userdetails.dataValues.lName;
                    array.image       = userdetails.image;
                    array.subjectName = subName;
                    array.channelName = "";
                    array.accessToken = "";
                    array.status      = 3;
		   mainArray.push(array);
                }
            }else if(type == "complete")
            {
                //Get Complete List
                var topic = await TeacherBooking.findAll({
                    attributes: ['id','bookingDate','teacherId','subjectId','timeSlot','slot','modifiedAt',
                    [sequelize.literal('(SELECT count(id) FROM ratings where bookingId = bookings.id)'), 'ratingStatus']],
                    where: {
                        userId:id,
                        status: '2'
                    },
		 order:[['modifiedAt','Desc']],
              });
                for (var i = 0; i < topic.length; i++) {
                    var array       = {};
                    var bookingDate = topic[i].bookingDate;
                    var teacherId   = topic[i].teacherId;
                    var timeSlot    = topic[i].timeSlot;

                    var userdetails = await userDetail.findOne({
                        attributes: ['fName','lName','image'],
                        where :{
                            userId: teacherId
                        }
                    });

                    //Get Subject Details
                    if( topic[i].subjectId != null)
                    {
                        var subjectdetails = await subjectDetail.findOne({
                            where :{
                                id: topic[i].subjectId
                            }
                        })
                        var subName = subjectdetails.dataValues.name;
                    }else{
                        var subName = "";
                    }

                    array.id          = topic[i].id;
                    array.bookingDate = bookingDate;
                    array.teacherId   = teacherId;
                    array.timeSlot    = timeSlot;
                    array.subjectName = subName;
                    array.fName       = userdetails.dataValues.fName;
                    array.lName       = userdetails.dataValues.lName;
                    array.image       = userdetails.image;
                    array.channelName = "";
                    array.accessToken = "";
                    array.status      = topic[i].status;
                    mainArray.push(array);
                }
            }else if(type == "booking")
            {
		let slotWise = new Date().toTimeString().slice(0,8)
                var topic = await TeacherBooking.findAll({
                    attributes: ['id','bookingDate','slot','teacherId','packageId','timeSlot','subjectId','credit','channelName','accessToken','status','modifiedAt'],
                    where: {
                        userId:id,
			  bookingDate: {
                            [Op.gte]: new Date(),
			    	
                        },
                        status: {
                            [Op.notIn]:[ 2, 3]          
               }
                    },
		group:['bookingDate','slot'],
				order: [
                    ['bookingDate', 'ASC'],
		 ['slot','ASC']
                                        ],       
         });
                var mainBookArray  = [];
                for (var i = 0; i < topic.length; i++) {
                    var array       = {};
                    var bookingDate = topic[i].bookingDate;
                    var teacherId   = topic[i].teacherId;
                    var timeSlot    = topic[i].timeSlot;
                  
                    var d1 = new Date();
                    var d3 = new Date(bookingDate +" "+timeSlot);
                    var same1 = d1.getTime() <d3.getTime();



                    if(same1)
{


                    var userdetails = await userDetail.findOne({
                        where :{
                            userId: teacherId
                        }
                    })

                    var packagedetails = await Packages.findOne({
                        where :{
                            id: topic[i].packageId
                        }
                    })

                    //Get Subject Details
                    if( topic[i].subjectId != null)
                    {
                        var subjectdetails = await subjectDetail.findOne({
                            where :{
                                id: topic[i].subjectId
                            }
                        })
                        var subName = subjectdetails.dataValues.name;
                    }else{
                        var subName = "";
                    }

                    array.id          = topic[i].id;
                    array.bookingDate = bookingDate;
                    array.teacherId   = teacherId;
                    array.timeSlot    = timeSlot;
                    array.fName       = userdetails.dataValues.fName;
                    array.lName       = userdetails.dataValues.lName;
                    array.image       = userdetails.image;
                    array.subjectName = subName;
                    array.channelName = topic[i].channelName;
                    array.accessToken = topic[i].accessToken;
                    array.status      = topic[i].status;

                    // array.credit      = topic[i].credit;
                    
                    // array.duration = packagedetails.dataValues.minute;
                    mainArray.push(array);
}
                }
            }
        

            return helpers.jsonResponse(res,true,mainArray,appstrings.success,200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

};
const subtractBookingsCount = async function (slotdata,serviceDateTime,dayCount,teacherId,startDate)
{
    
    var startDate =startDate
    for(var t=0;t<slotdata.length;t++)
    {

        if(startDate==slotdata[t].slot)   
                {
            //slotsBookingsAlowed=slotdata[t].bookings
            var quantity=parseInt(slotdata[t].bookings)-1
            slotdata[t].bookings=quantity.toString()
        }  
    }
    SCHEDULE.update({slots : JSON.stringify(slotdata)}, {where :{userId:teacherId,dayParts:dayCount}})
}

const deduceTokenHistory = async function (userId,teacherId,status,token,tokenBalance,type)
{
    
    const usr = await userTokenHistory.create({
        senderId: userId,
        receiverId: teacherId,
        token : token,
        type: type,
        tokenBalance: tokenBalance,
        status: status,
        createdAt: Math.floor(new Date().getTime() / 1000)

    });

}
const addTokenHistory = async function (userId,teacherId,status,token,tokenBalance,type)
{
   
    const usr = await userTokenHistory.create({
        senderId: teacherId,
        receiverId: userId,
        token : token,
        type: type,
        tokenBalance: tokenBalance,
        status: status,
	modifiedAt:new Date(),
    createdAt: Math.floor(new Date().getTime() / 1000)

    });

}