const NOTIFICATION = db.models.notifications

const sequelize = require('sequelize')
var cron = require('node-cron');
var moment = require('moment')
const Op = require('sequelize').Op;

COMPANY.hasOne(COMISSION, { foreignKey: 'companyId' });
COMPANY.hasMany(COMISSIONHISTORY, { foreignKey: 'companyId' });


cron.schedule('30 06 * * *', async () => {
  console.log('running a task every 6:30 AM ');
  var days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat']

  var dayCount = days[new Date().getDay()]
  try {
    var findData = await SCHEDULE.findAll({ where: { dayParts: { [Op.not]: dayCount } } });
    findData = JSON.parse(JSON.stringify(findData))

    for (var t = 0; t < findData.length; t++) {
      SCHEDULE.update(
        { slots: findData[t].permanentSlots },
        { where: { id: findData[t].id } });
    }


    //Delete older Notifications

    NOTIFICATION.destroy({
      where: {
        createdAt: {
          [Op.lte]: moment().subtract(7, 'days').toDate()
        }
      }
    });


    //UPDate Vendors rating
    updateVendorsRating()
    updateAppRating()
   
    //Update Servcice RATINGS
    updateServiceRating()

    //UPdate Popularity

    updateServicePopularity()

    //Update Tiffin Popularity
    updateServiceTiffinPopularity()

    ////Update Tiffin Popularity
    updateTiffinRating()

    updateEmpRating()
    updateEmpPopularity()
    updateRestroPopularity()
    deleteChatMsgs();

    checkExpiryPlans()
    checkAdminExpiryPlans();
    //tranfer payments to vendors
   // transferCommission();
     // disabling the coupans and deals
     disableOffers();
     deleteActivity();
     deleteActionActivity();

     transferStaffSalary();
     staffEarningPerday();
     updateOffersExpiry()
     cancelPendignOrders()
     checkSetupChangesForCommission()


  } catch (e) {
    console.error(e.message)
  }

});


// cron.schedule('* * * * *',  async() => {
//   console.log('running a task every Mins============ ')
//   checkSetupChangesForCommission()
// });


// cron.schedule('*/60 * * * *',  async() => {
//   //console.log('running a task every 15  Mins============ ')

 
//     //console.log(response)
//   }).catch(e=>{
//     console.log(e)
//   });
// });







// cron.schedule('* * * * *', () => {
//   var newDate = moment(new Date()).subtract(10,'days');

//   console.log('Runing a job at 01:0`0 at America/Sao_Paulo timezone',newDate);

// }, {
//   scheduled: true,
//   timezone: "Asia/Kolkata"
// });


//Recent Added Company ande product Ratings

async function updateOffersExpiry()
{
  try {
    var newDate = moment(new Date()).format("YYYY/MM/DD hh:mm:ss");


    var services = await SERVICES.findAll({
      attributes: ['id', 'name', 'icon', 'thumbnail', 'validUpto', 'offer', 'offerName', 'price', 'originalPrice', 'unit','inventory','quantity','productAvailable'],
      where: {
        status: 1,
        validupto: {[Op.or]:{  [Op.lt]: newDate ,[Op.eq]:null  }
        },


       
      },
      order: [
        ['offer', 'DESC']
      ]
    })


    services = JSON.parse(JSON.stringify(services))
    for (var p = 0; p < services.length; p++) {

      SERVICES.update({
        price: services[p].originalPrice,
        offer: 0, offerName: '', validUpto: null
      },
        { where: { id: services[p].id } })

    }



  } catch (e) {
    console.error(e.message)
  }
}

async function updateServiceRating() {

  var products = await SERVICERATINGS.findAll({
    attributes: ['serviceId'],
    group: ['serviceId'],
    // where: {
    //   createdAt: { [Op.gte]: moment().subtract(2, 'days').toDate() }
    // }
  })




  if (products && products.length > 0) {
    products = JSON.parse(JSON.stringify(products))

    for (var k = 0; k < products.length; k++) {
      var rating = 0
      var count = 0

      var dataRating = await commonMethods.getServiceAvgRating(products[k].serviceId)
      if (dataRating && dataRating.dataValues && dataRating.dataValues.totalRating) {
        rating = dataRating.dataValues.totalRating
        count = dataRating.dataValues.totalNoRating
      }


      SERVICES.update({
        rating: rating,
        totalRatings: count
      },
        {
          where: {
            id: products[k].serviceId
          }
        });

    }
  }
}

async function deleteActivity()
{
   var newDate = moment(new Date()).subtract(14, 'days').format("YYYY-MM-DD");
  ACTIVITY.destroy({
    where: sequelize.where(sequelize.fn('date', sequelize.col('createdAt')), '<=', newDate)
  })
}


async function deleteActionActivity()
{
   var newDate = moment(new Date()).subtract(7, 'days').format("YYYY-MM-DD");
  ACTIONACTIVITY.destroy({
    where: sequelize.where(sequelize.fn('date', sequelize.col('createdAt')), '<=', newDate)
  })
}

async function staffEarningPerday()
{


  
  var allEMP = await EMPLOYEE.findAll({
    where: {
      status:1 ,
      deleted:0,
    }
  })


  //   var allEMP = await EMPLOYEE.findAll({                                                                                                                                                                                         
  //   where: {
  //     status:1 ,
  //     id:"2547f78e-fcc6-4c5b-9488-a48c0cd50323"
    
  //   }
  // })




  allEMP=JSON.parse(JSON.stringify(allEMP))

if(allEMP.length>0)
{
for(var h=0;h<allEMP.length;h++)
{


  var staffSettings = await STAFFSETTINGS.findOne({
    where: {
      companyId:allEMP[h].companyId
    }
  })




//check Scenario fro ewarning

if(staffSettings && staffSettings.dataValues)
{
  var earningScenario=staffSettings.dataValues.earningScenario
  var targetOrder=parseInt(staffSettings.dataValues.earningOrderTarget)
  var targetDistance=parseInt(staffSettings.dataValues.earningdistanceTarget)
  var orderBenefit=parseFloat(staffSettings.dataValues.earningOnOrder)
  var distanceBenefit=parseFloat(staffSettings.dataValues.earningOnDistance)
  var amountTobePaid=0
  var empOrderCount=0
  var ordersExtra=0
  var empdistanceCount=0
  var distanceExtra=0
  var orderTargetAchieved=0
  var distanceTargetAchieved=0
  var orderSum=0
  
  
  var assignment = await ASSIGNMENT.findOne({
    attributes:[[sequelize.fn('sum', sequelize.col('distanceTravelled')), 'sum'],
    [sequelize.fn('count', sequelize.col('id')), 'count'],
    [sequelize.fn('sum', sequelize.col('orderSum')), 'orderSum']
  
  ],
    where: {
      jobStatus:3,
      empId:allEMP[h].id,
      considerInTarget:"0"
    }
  })



  if(assignment&& assignment.dataValues && assignment.dataValues)
  {
    
    orderSum=assignment.dataValues.orderSum ? parseFloat(assignment.dataValues.orderSum):0
    empdistanceCount=assignment.dataValues.sum?parseInt(assignment.dataValues.sum):0
    empOrderCount=assignment.dataValues.count?parseInt(assignment.dataValues.count):0

  }



  if(earningScenario==0 && targetOrder>0 && empOrderCount>targetOrder) //Based on Number of orders
  {


ordersExtra=empOrderCount-targetOrder
amountTobePaid=ordersExtra*orderBenefit
orderTargetAchieved=1
  }
  

  if(earningScenario==1 && targetDistance>0 && empdistanceCount>targetDistance ) //Based on Number of orders
  {

distanceExtra=empdistanceCount-targetDistance
amountTobePaid=distanceExtra*distanceBenefit
distanceTargetAchieved=1

  }
  


  if(earningScenario==2 ) //Both distance and  number of orders
  {

  if(empdistanceCount>targetDistance && targetDistance>0) //check for distance taret
{

distanceExtra=empdistanceCount-targetDistance
amountTobePaid=distanceExtra*distanceBenefit
distanceTargetAchieved=1

}
 
if(empOrderCount>targetOrder && targetOrder>0 )  //check for number of order target
  {
ordersExtra=empOrderCount-targetOrder
amountTobePaid=amountTobePaid+(ordersExtra*orderBenefit)
orderTargetAchieved=1

  }

  }
  


// console.log(">>>>>>>>>>>>>>>>>>>>>>>4",targetOrder,empOrderCount,amountTobePaid)

  if(amountTobePaid>0)
  {

      var oldBalnce = allEMP[h].walletBalance
      var walletBalance = parseFloat(oldBalnce) + amountTobePaid
    EMPLOYEE.update({ walletBalance: walletBalance }, { where: { id: allEMP[h].id } })
    STAFFWALLET.create({ empId: allEMP[h].id, payType: 1, companyId: allEMP[h].companyId , amount: amountTobePaid,purpose:"Earning amount deposited by admin", orderId: "" })
    ASSIGNMENT.update({ considerInTarget: "1" }, { where: { empId: allEMP[h].id ,jobStatus:3} })
    TARGETHISTORY.create(
      {
         amount:amountTobePaid.toFixed(2),
         paidType:0,
         earningScenario:earningScenario,
         totalOrderCount:empOrderCount,
         totalOrderSum:orderSum,
         distanceTargetAchieved :distanceTargetAchieved,
         orderTargetAchieved :orderTargetAchieved,
         targetOrder:targetOrder,
         orderExtra:ordersExtra,
         targetDistance:targetDistance,
         distanceExtra:distanceExtra,
         empId:allEMP[h].id,
         companyId:allEMP[h].companyId 
       
     })
  
     EARNINGHISTORY.create(
      {
         amount:amountTobePaid.toFixed(2),
         description:"Admin has credited amount on achieving your target",
         paidType:0,
         charges:0,
         extraEarnings:amountTobePaid.toFixed(2),
         wagesType:0,
         orderId:"",
         totalOrders:empOrderCount,
         orderAmount:orderSum,
         empId:allEMP[h].id,
         companyId:allEMP[h].companyId 
       
     })


     
  }


}
}



}
}



async function transferStaffSalary()
{
  var allEMP = await EMPLOYEE.findAll({
    where: {
      status:1 ,
      deleted:0,

    }
  })


  allEMP=JSON.parse(JSON.stringify(allEMP))

if(allEMP.length>0)
{
for(var h=0;h<allEMP.length;h++)
{

  var staffWages = await STAFFWAGES.findOne({
    where: {
      empId:allEMP[h].id 
    }
  })

  var lastTransaction = await EARNINGHISTORY.findOne({
    where: {
      empId:allEMP[h].id 
    },
    order:[['createdAt','DESC']]
  })

if(staffWages && staffWages.dataValues)
{
  var amountTobePaid=0
  var type=staffWages.dataValues.wagesType
  var installments=staffWages.dataValues.installments
  var comissionPercentage=staffWages.dataValues.commissionPercentage

var lastTransactionDate=(lastTransaction&& lastTransaction.dataValues)?new Date(lastTransaction.dataValues.createdAt):staffWages.dataValues.updatedAt

var orderSum=0
var count=0
var orderAmount = await ORDERS.findOne({
  attributes:[[sequelize.fn('sum', sequelize.col('totalOrderPrice')), 'amount'],
  [sequelize.fn('count', sequelize.col('id')), 'count']

],
  where: {
    progressStatus:5,
   
  },
  include:[{model:ASSIGNMENT, 
    required:true,
    where:{ empId:allEMP[h].id,
    jobStatus:3,
    createdAt: { [Op.gte]: lastTransactionDate,[Op.lte]: new Date()}
  
  },
     attributes:['empId']}]
})


if(orderAmount && orderAmount.dataValues && orderAmount.dataValues.amount)
{orderSum=orderAmount.dataValues.amount
count=orderAmount.dataValues.count

}






  if(type==1) // If There is fixed amount
  {
 amountTobePaid=await calcualteWagesAmount(allEMP[h].id,lastTransactionDate,installments,parseFloat(staffWages.dataValues.wagesAmount),orderSum)
}

 else{ // If There is comission based charges

  checkChangesForUpdation(allEMP[h].id)

//amountTobePaid= await calculateComissionValue(allEMP[h].id,lastTransactionDate,installments,comissionPercentage,orderSum)

}


  if(amountTobePaid>0)
  {

      var oldBalnce = allEMP[h].walletBalance
      var walletBalance = parseFloat(oldBalnce) + amountTobePaid
    EMPLOYEE.update({ walletBalance: walletBalance }, { where: { id: allEMP[h].id } })
    STAFFWALLET.create({ empId: allEMP[h].id, payType: 1, companyId: allEMP[h].companyId , amount: amountTobePaid,purpose:"Salary amount deposited by admin", orderId: "" })
   
    EARNINGHISTORY.create(
      {
         amount:amountTobePaid.toFixed(2),
         paidType:installments,
         charges:comissionPercentage,
         extraEarnings:0,
         wagesType:type,
         orderId:"",
         description:"Wages salary was credited in your wallet",
         totalOrders:count,
         orderAmount:orderSum,
         empId:allEMP[h].id,
         companyId:allEMP[h].companyId 
       
     })


checkChangesForUpdation(allEMP[h].id)



  
  }





}



}
}


}

async function checkChangesForUpdation(emplId)
{

  var dataF=await FUTURECHANGES.findOne({
    where:{purpose:"wages",
    userId:emplId,
    status:1}
  })



if(dataF)
{

  dataF=JSON.parse(JSON.stringify(dataF))
var keysValues=dataF.keysValues

STAFFWAGES.update({
  wagesType: keysValues.wagesType,
  installments: keysValues.installments,
  commissionPercentage:keysValues.commissionPercentage,
  wagesAmount:keysValues.wagesAmount,
  empId:keysValues.empId},
{where:{empId:keysValues.empId}});

  FUTURECHANGES.destroy({
    where: {
      id: dataF.id
    }
    })  
      

}

}

async function checkSetupChangesForCommission()
{

  var dataF=await FUTURECHANGES.findAll({
    where:{purpose:"commissionSetup",
    status:1}
  })




for(var n=0;n<dataF.length;n++)
{
  dataF=JSON.parse(JSON.stringify(dataF[n]))
var keysValues=dataF.keysValues

//console.log("???",dataF)

 await COMISSION.update({
          chargesPercent:keysValues.chargesPercent,
          chargesAmount:keysValues.chargesPercent,
          chargesType:keysValues.chargesType,
          installments:keysValues.installments
        },{where:{companyId:keysValues.companyId}})

  FUTURECHANGES.destroy({
    where: {
      id: dataF.id
    }
    })  
      

}

}









async function updateEmpRating() {

  var products = await STAFFRATINGS.findAll({
    attributes: ['empId'],
    group: ['empId'],
    where: {
      createdAt: { [Op.gte]: moment().subtract(2, 'days').toDate() }
    }
  })




  if (products && products.length > 0) {
    products = JSON.parse(JSON.stringify(products))

    for (var k = 0; k < products.length; k++) {
      var rating = 0
      var count = 0

      var dataRating = await commonMethods.getEmpAvgRating(products[k].empId)
      if (dataRating && dataRating.dataValues && dataRating.dataValues.totalRating) {
        rating = dataRating.dataValues.totalRating
        count = dataRating.dataValues.totalNoRating
      }


      EMPLOYEE.update({
        rating: rating,
        totalRatings: count
      },
        {
          where: {
            id: products[k].empId
          }
        });

    }
  }
}


async function updateTiffinRating() {

  var products = await TIFFRATINGS.findAll({
    attributes: ['tiffinId'],
    group: ['tiffinId'],
    where: {
      createdAt: { [Op.gte]: moment().subtract(2, 'days').toDate() }
    }
  })




  if (products && products.length > 0) {
    products = JSON.parse(JSON.stringify(products))

    for (var k = 0; k < products.length; k++) {
      var rating = 0
      var count = 0

      var dataRating = await commonMethods.getTiffinAvgRating(products[k].tiffinId)
      if (dataRating && dataRating.dataValues && dataRating.dataValues.totalRating) {
        rating = dataRating.dataValues.totalRating
        count = dataRating.dataValues.totalNoRating
      }


      TIFFSERVICES.update({
        rating: rating,
        totalRatings: count
      },
        {
          where: {
            id: products[k].tiffinId
          }
        });

    }
  }
}




async function updateServicePopularity() {

  var products = await SUBORDERS.findAll({
    attributes: ['serviceId'],
    group: ['serviceId'],
    where: {
      createdAt: { [Op.gte]: moment().subtract(1, 'days').toDate() }
    }
  })


  products = JSON.parse(JSON.stringify(products))

  for (var k = 0; k < products.length; k++) {
    var popularityD = 0

    var dataPop = await SUBORDERS.findOne({ attributes: ['serviceId', [sequelize.fn('COUNT', sequelize.col('serviceId')), 'count']], where: { serviceId: products[k].serviceId } })
    if (dataPop && dataPop.dataValues && dataPop.dataValues.count)
      popularityD = parseInt(dataPop.dataValues.count)



    SERVICES.update(

      {
        popularity: popularityD
      },
      {
        where: { id: products[k].serviceId }

      }
    )
  }


}


async function updateEmpPopularity() {

  var products = await ASSIGNMENT.findAll({
    attributes: ['empId'],
    group: ['empId'],
    where: {
      createdAt: { [Op.gte]: moment().subtract(3, 'days').toDate() }
    }
  })



  products = JSON.parse(JSON.stringify(products))

  for (var k = 0; k < products.length; k++) {
    var popularityD = 0

    var dataPop = await ASSIGNMENT.findOne({ attributes: ['empId', [sequelize.fn('COUNT', sequelize.col('empId')), 'count']], where: { empId: products[k].empId, jobStatus: [1, 3] } })
    if (dataPop && dataPop.dataValues && dataPop.dataValues.count)
      popularityD = parseInt(dataPop.dataValues.count)

console.log(popularityD)
    EMPLOYEE.update(

      {
        totalOrders: popularityD
      },
      {
        where: { id: products[k].empId }

      }
    )
  }


}

async function updateServiceTiffinPopularity() {

  var products = await TIFFORDERS.findAll({
    attributes: ['tiffinId'],
    group: ['tiffinId'],
    where: {
      createdAt: { [Op.gte]: moment().subtract(1, 'days').toDate() }
    }
  })




  products = JSON.parse(JSON.stringify(products))


  for (var k = 0; k < products.length; k++) {
    var popularityD = 0

    var dataPop = await TIFFORDERS.findOne({ attributes: ['id', [sequelize.fn('COUNT', sequelize.col('id')), 'count']], where: { tiffinId: products[k].tiffinId } })
    if (dataPop && dataPop.dataValues && dataPop.dataValues.count)
      popularityD = parseInt(dataPop.dataValues.count)



    TIFFSERVICES.update(

      {
        popularity: popularityD
      },
      {
        where: { id: products[k].tiffinId }

      }
    )
  }


}


async function updateVendorsRating() {
  //RECENT added Ratings
  var vendors = await COMPANYRATING.findAll({
    attributes: ['companyId'],
    group: ['companyId'],

    // where: {
    //   createdAt: { [Op.gte]: moment().subtract(2, 'days').toDate() }
    // }
  })


  if (vendors) {
    vendors = JSON.parse(JSON.stringify(vendors))

    for (var k = 0; k < vendors.length; k++) {
      var rating = 0
      var fQlRating = 0
      var ppRating = 0
      var fQnRating = 0
      var count = 0

      var dataRating = await commonMethods.getCompAvgRating(vendors[k].companyId)
      if (dataRating && dataRating.dataValues && dataRating.dataValues.totalRating) {
        rating = dataRating.dataValues.totalRating
        count = dataRating.dataValues.totalNoRating
        fQlRating = dataRating.dataValues.foodQuality
        fQnRating = dataRating.dataValues.foodQuantity
        ppRating = dataRating.dataValues.packingPres
      }
      COMPANY.update({
        rating: rating,
        foodQualityRating: fQlRating,
        foodQuantityRating: fQnRating,
        packingPresRating: ppRating,
        totalRatings: count,
      },
        {
          where: {
            id: vendors[k].companyId
          }
        });


    }

  }






}


async function updateAppRating() {



  const dataRating = await APPRATINGS.findOne({
    attributes: [[sequelize.fn('avg', sequelize.col('rating')), 'totalRating'],
    [sequelize.fn('count', sequelize.col('rating')), 'totalNoRating']],
    where: {
      rating: { [Op.not]: '0' }
    }
  })




  if (dataRating && dataRating.dataValues && dataRating.dataValues.totalRating) {
    rating = dataRating.dataValues.totalRating
    count = dataRating.dataValues.totalNoRating

    COMPANY.update({
      rating: rating,
      totalRatings: count,
    },
      {
        where: {
          id: config.PARENT_COMPANY
        }
      });
  }







}





async function updateRestroPopularity() {

  var products = await ORDERS.findAll({
    attributes: ['companyId'],
    group: ['companyId'],
    where: {
      createdAt: { [Op.gte]: moment().subtract(5, 'days').toDate() }
    }
  })


  products = JSON.parse(JSON.stringify(products))

  for (var k = 0; k < products.length; k++) {
    var popularityD = 0
    var delivered = 0
    var popularityD24 = 0

    var dataPop = await ORDERS.findOne({ attributes: ['companyId', [sequelize.fn('COUNT', sequelize.col('companyId')), 'count']], where: { companyId: products[k].companyId } })
    if (dataPop && dataPop.dataValues && dataPop.dataValues.count)
      popularityD = parseInt(dataPop.dataValues.count)


      var dataDeliverPop = await ORDERS.findOne({ attributes: ['companyId', [sequelize.fn('COUNT', sequelize.col('companyId')), 'count']], where: { companyId: products[k].companyId,progressStatus:5 } })
      if (dataDeliverPop && dataDeliverPop.dataValues && dataDeliverPop.dataValues.count)
      delivered = parseInt(dataDeliverPop.dataValues.count)
  


    var dataPop24 = await ORDERS.findOne({
      attributes: ['companyId', [sequelize.fn('COUNT', sequelize.col('companyId')), 'count']],
      where: { companyId: products[k].companyId, createdAt: { [Op.gte]: moment().subtract(1, 'days').toDate() } }
    })
    if (dataPop24 && dataPop24.dataValues && dataPop24.dataValues.count)
      popularityD24 = parseInt(dataPop24.dataValues.count)



    COMPANY.update(

      {
        totalOrders: popularityD,
        totalOrders24: popularityD24,
        totalOrdersDelivered: delivered

      },
      {
        where: { id: products[k].companyId }

      }
    )
  }


}


async function deleteChatMsgs() {
  const groups = await groupa.findAll({
    attributes: ['id']
  });
  if (groups) {
    groups.map(async group => {
      var message = await chatMessages.findOne({
        attributes: ['id'],
        where: {
          [Op.and]: [
            {
              groupId: group.id
            },
            {
              createdAt: { [Op.lte]: moment().subtract(7, 'days').toDate() },
            }
          ]
        },
        order: [
          ['createdAt', 'DESC']
        ],
      });
      if (message) {
        chatMessages.destroy({
          where: {
            groupId: group.id
          }
        })
      }
    });
  }
}







async function checkExpiryPlans() {
  try {
    var newDate = moment(new Date()).format("YYYY-MM-DD");
    //Get Plan
    const getplan = await USERSUB.findAll({
      where: {
        status: '1',
        endDate: {
          [Op.lt]: newDate
        }
      }
    });
    var MainArray = [];
    for (var i = 0; i < getplan.length; i++) {
      var userId = users[i].UserId;
      var findData = await USER.findOne({ where: { id: userId } });
      if (findData) {
        MainArray.push(userId);
        //Send Notification
        var notifPushUserData = {
          title: "Subscription Expired",
          description: "Your Subscription has been expired.",
          token: findData.dataValues.deviceToken,
          platform: findData.dataValues.platform,
          userId: userId,
          role: 3,
          notificationType: "Subscription Expire",
          status: "Expire",
        }
        commonNotification.sendNotification(notifPushUserData)
        var msg = `Hi *${findData.dataValues.fullName}*,Your Subscription has been expired. Your account has been converted to a free account.
        More Details: `+config.WEBSITE_LINK
        commonNotification.sendWhatsapp(msg ,  findData.dataValues.countryCode+findData.dataValues.phoneNumber,"subexpired")
  



      }
    }
    if (MainArray.length > 0) {
      const updatedResponse = await USER.update({
        userType: '3'
      },
        {
          where: {
            id: {
              [Op.in]: MainArray
            }
          }
        });
      //User Plan
      const updatedplanResponse = await USERSUB.update({
        status: '0'
      },
        {

          where: {
            userId: {
              [Op.in]: MainArray
            }
          }
        });
    }
    console.log("Plan Expired");
  }
  catch (e) {
    console.error(e.message)
  }


}

async function cancelPendignOrders()
{

    var orders = await ORDERS.findAll({
      where: {
        serviceDateTime: { [Op.lt]: moment() },
        progressStatus:0
      }
    })

    orders= JSON.parse(JSON.stringify(orders))

for(var h=0;h<orders.length;h++)
{
    userData=JSON.parse(JSON.stringify(orders[h]))
    var findData = await USER.findOne({ where: { id: orders[h].userId } });

  var history=await commonMethods.addStatus(userData,4)

  //console.log(history[0])
   await ORDERS.update({
     progressStatus: 4,
    cancellationReason:" Not confirmed yet",
  statusHistory:JSON.stringify(history[0]),
  },
  
    {where: {id: orders[h].id}});


    var userDataForSMS = {
      phoneNumber : findData.dataValues.phoneNumber,
      countryCode : findData.dataValues.countryCode,
      orderNo : orders[h].orderNo,
      customerName : findData.dataValues.fullName,
      otp : orders[h].otp
    };
  commonMethods.sendCstmBodyMsg(4 , userDataForSMS);

  
 
}


}

async function checkAdminExpiryPlans() {
  try {
    var newDate = moment(new Date()).format("YYYY-MM-DD");
    //Get Plan
    const getplan = await TRIALSUB.findAll({
      where: {
        status: '1',
        endDate: {
          [Op.lt]: newDate
        }
      }
    });
    var MainArray = [];
    var EMailArray = [];
    for (var i = 0; i < getplan.length; i++) {
      var userId = getplan[i].adminId;
      var findData = await COMPANY.findOne({ where: { id: userId } });
      if (findData) {
        MainArray.push(userId);
        EMailArray.push(findData.dataValues.email);
        //Send Notification
        var notifPushUserData = {
          title: "Subscription/Trial Expired",
          description: "Your Subscription or trial has been expired.",
          token: findData.dataValues.deviceToken,
          platform: findData.dataValues.platform,
          userId: userId,
          notificationType: "Subscription Expire",
          status: "Expire",
        }
        commonNotification.insertNotification(notifPushUserData)
      }
    }
    if (MainArray.length > 0) {


      await COMPANY.update({
        status: 0
      },
        {
          where: {
            [Op.or]: [

              {
                id: {
                  [Op.in]: MainArray
                }
              },
              {
                parentId: {
                  [Op.in]: MainArray
                }
              }


            ]




          }
        });


      await USER.update({
        status: 0
      },
        {
          where: {

            companyId: {
              [Op.in]: MainArray
            }
          }
        });
        await TRIALS.update({
          accountStatus: 0
        },
        {
          where: {
            email: {
              [Op.in]: EMailArray
            }
          }
        });
      //User Plan
      const updatedplanResponse = await TRIALSUB.update({
        status: '0'
      },
        {

          where: {
            adminId: {
              [Op.in]: MainArray
            }
          }
        });





    }
    //console.log("Plan Expired");
  }
  catch (e) {
    console.error(e.message)
  }


}



async function transferCommission() {
  try {
    
    var companyCom = await COMPANY.findAll({
      attributes: ['id', 'createdAt'],
      where: { role: { [Op.ne]: [0,4] } },
      include: [{
        model: COMISSION
      }, {
        model: COMISSIONHISTORY,
        raw:true,
        nest:true,
        attributes: ['id', 'createdAt'],
        order: [
          ['createdAt', 'DESC'],  
      ],
      }]
    });
    companyCom = JSON.parse(JSON.stringify(companyCom));
  
    companyCom.map(async company => {
      if(company.comission){
      const payData = await PAYMENT.findOne({
        attributes: [[sequelize.fn('sum', sequelize.col("amount")), 'totalamount']],
        where: {
          paymentState: 1,
          transactionStatus: 1,
          companyId: company.id
        },
      });
      var amount = 0
     
      if (payData && payData.dataValues) {
         amount = payData.dataValues.totalamount?payData.dataValues.totalamount:0;
      } 
      var commission;
        if (company.comission && company.comission.chargesType == 1) {
          commission = ((amount * company.comission.chargesPercent) / 100).toFixed(2);
        } else if (company.comission && company.comission.chargesType == 0) {
          commission = company.comission.chargesAmount;
        } else {
          commission = 0;
        }
        if(company.comissionHistories.length>0)
        {
          lastCommisionDate = new Date(company.comissionHistories[0].createdAt)
        }
        else{
            lastCommisionDate = new Date(company.createdAt*1000)
        }
        let days=1
        let nextCommisionDate 
        const today = new Date()
   
        if(company.comission.installments==0) days= 1   // daily
        if(company.comission.installments==1) days= 7   // weekly
        if(company.comission.installments==2) days= Math.abs( moment.duration(moment().diff(moment().add(1, 'M'))).asDays());// monthly
        if(company.comission.installments==3) days= Math.abs( moment.duration(moment().diff(moment().add(3, 'M'))).asDays());  // quaterly

        nextCommisionDate=(new Date(( lastCommisionDate.getTime() + days * 86400000 )));      
        const diffDays = Math.ceil((nextCommisionDate - today) / (1000 * 60 * 60 * 24));

       
        if(!(typeof company.comission ==='undefined' )){
            if(diffDays<=0){
            updateVendorCommisionHistory(company.id,company.comission.installments,amount,commission,company.comission.chargesPercent?company.comission.chargesPercent:0.0,company.comission.chargesAmount?company.comission.chargesAmount:0, company.comission.chargesType)
          }
        }
      }
    });
   
  } catch (e) {
    console.error(e.message)
  } 
}

async function updateVendorCommisionHistory(company,installments,amount,commission,charge,planAmount,planType){
  let transferredAmount = parseFloat( amount )-parseFloat(commission )
  let commissionUpdated = await COMISSIONHISTORY.create({
    amount:amount,
    charges:commission,
    companyId:company,
    installment:installments, //weekly , monthly, quaterly
    chargesPercent: charge,   // if type is %, then 
    chargesAmount: planAmount, // the amount
    chargesType: planType,     // percentage or fixed
    transferredAmount: transferredAmount,
    status: transferredAmount>0?1:0
  })




  
  //checkSetupChangesForCommission(company)
  
    await PAYMENT.update(
      { transactionStatus: 2 },
      { where: { companyId: company,paymentState: 1 } });
      checkChangesForUpdation(company)

 
  return 1
}
//disabling offers ,deals and coupans
async function disableOffers(){
  await Promise.all([
    COUPAN.findAll({
    attributes: ['id','name','status','validupto'],
    where: {
      validupto: { [Op.lt]: moment().format('YYYY-MM-DD')},
      status:1
    }
  }),
  DEALS.findAll({
    attributes: ['id','status','validUpto'],
    where: {
      validUpto: { [Op.lt]: moment().format('YYYY-MM-DD')},
      status:1
    }
  })
])
.then(async values => {
if( values[0] ){

let findDatacoupan =  JSON.parse( JSON.stringify(values[0]))
  for (var t = 0; t < findDatacoupan.length; t++) {
    await COUPAN.update(
      { status: 0 },
      { where: { id: findDatacoupan[t].id } });
  }
}
if(values[1]){
  let findData = JSON.parse(JSON.stringify(values[1]))
  for (var t = 0; t < findData.length; t++) {
    await DEALS.update(
      { status: 0 },
      { where: { id: findData[t].id } });
  }
}
})
.catch(error => {
console.error(error.message)
});
}








