const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model = require("../models/index");
const jwt            = require('jsonwebtoken');
const helpers = require("../helpers");
const hashPassword   = require('../helpers/hashPassword');
const responseHelper = require("../helpers/responseHelper");
const common         = require('../helpers/common');

const moment   = require('moment');

const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  service: config.SMTPSER,
  auth: {
    user: config.SENDMAIL,
    pass: config.SENDPWD,
  }
});
module.exports = {

	/////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Packages list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	list: async (req, res) => {
	    try {
	    	var id = req.id;
	    	const userList =  await Packages.findAll({
	    		where: {
	    			userId: id
	    		}
	    	});
			return helpers.jsonResponse(res,true,userList,"Package list fetch successfully!", 200, 200);
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// Add Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	postAdd: async (req, res) => {
	    try {
			const data = req.body;
			const userDet = await Packages.create({
	            title: data.title,
	            userId: req.id,
	            description: data.description,
	            minute: data.minute,
	            price: data.credit,
	        });
	        return helpers.jsonResponse(res,true,{},"Package add successfully!", 200, 200);
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},

  	/////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// Delete Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	delete: async (req, res) => {
  	  try{
	// check if there is a appointment booking request on same package
			// return if appointment is present
			const findpresentBooking = await TeacherBooking.findOne({
				where:{ packageId:req.body.id,status:1 }
			})
			if(findpresentBooking){
		 return helpers.jsonResponse(res,true,{},appstrings.active_booking,400,200);
				//return helpers.jsonResponse(res, false, {}, {},appstrings.active_booking, 200, 400);
			}

const findPackage = await Packages.findOne({
where:{ id:req.body.id }

})
if(findPackage ){
        	const numAffectedRows = await Packages.destroy({
          	where: {
            	id: req.body.id
          	}
          	})  
           	return helpers.jsonResponse(res,true,{},"Package deleted successfully!", 200, 200);
}else{
return helpers.jsonResponse(res,true,{},"No Package found", 200, 200);

}

        }catch (e) {
           	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// View Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  	view: async (req, res) => {
  	  	try {
	      	const findData = await Packages.findOne({
		      where :{
		      	id: req.params.id
		      }
	      	});
	      	return res.render('pages/admin/packages/view',{data:findData});
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
    },

    /////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////// Update Package ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
    update:async (req, res) =>{
    	try {
		    const data = req.body;
		    const user = await Packages.findOne({
	      		attributes: ['id'],
		      	where: {
			        id: data.pid
		      	}
    		});
		    if (user) {
		      	const users = await Packages.update({
			        title: data.title,
		            description: data.description,
		            minute: data.minute,
		            price: data.price,
		       	},
		       	{
		       		where:{
		         		id: data.pid
		       		}
		       	});
		      	if (users) {
		        	return helpers.jsonResponse(res,true,{},"Package udpate successfully!", 200, 200);
	     	 	}
		     	else{
		     		return helpers.jsonResponse(res, false, {},"Unable to update package!", 400, 400);
		    	}
		    }
		    else{
		    	return helpers.jsonResponse(res, false, {},"Unable to update package!", 400, 400);
		    }
	  	} catch (e) {
	   		console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	  	}
    },



    /////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////Get Packages list ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
  		listPackageCustomer: async (req, res) => {
	    try {
	    	var id = req.params.id;
		// get the professional setting for time slot.
			let teacherScheduleset  = await scheduleSetting.findOne({
                where: {
                    professionalId: id,
                }
			});

			if(!teacherScheduleset)
			return helpers.jsonResponse(res,true,null,"Please setup schedule first!", 400, 200);

	    	var userList =  await Packages.findAll({
	    		where: {
	    			userId: id,
				minute: teacherScheduleset.dataValues.slotTime 
	    		},order: [
					['price', 'ASC']
				]

	    	});
	    	if(userList.length > 0)
	    	{
	    		return helpers.jsonResponse(res,true,userList,"Package list is fetched successfully!", 200, 200);
	    	}else{
	    		
                const Adminuser = await users.findOne({
                    where: {
                        role: '0'
                    }
                });
                var userList =  await Packages.findAll({
		    		where: {
		    			userId: Adminuser.dataValues.id
		    		},order: [
					['price', 'ASC']
				]
		    	});
		    	return helpers.jsonResponse(res,true,userList,"Package list fetch successfully!", 200, 200);
	    	}
			
	    } catch (e) {
	      	console.log('Error => ', e);
	      	return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
  	},
}	