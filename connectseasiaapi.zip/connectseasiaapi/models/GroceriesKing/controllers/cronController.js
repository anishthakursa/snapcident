var cron = require('node-cron');
const sequelize = require('sequelize');
var moment = require('moment');
const Op = require('sequelize').Op;
const model = require("../models/index");
const {RtcTokenBuilder, RtmTokenBuilder, RtcRole, RtmRole} = require('agora-access-token')
const nodemailer = require('nodemailer');
const common      = require('../helpers/common');
TeacherBooking.hasMany(SCHEDULE,{foreignKey: 'userId',sourceKey:"teacherId"})
SCHEDULE.belongsTo(TeacherBooking,{foreignKey: 'userId',targetKey:"teacherId"})
const transporter = nodemailer.createTransport({
  service: config.SMTPSER,
  auth: {
    user: config.SENDMAIL,
    pass: config.SENDPWD,
  }
});
/**
*@role Update Agora Access Token
*@Every Day At 12:00 AM
*/
cron.schedule('00 00 * * *',  async() => {
	try{
		var newDate = moment(new Date()).format("YYYY-MM-DD");
    	console.log(newDate);
    	const findData = await TeacherBooking.findAll({
	      	where: {
		        bookingDate: newDate,
		        status: "0",
	      	}
    	});
	 	const appID            = config.APPKEY;
        const appCertificate   = config.APPCERTIFICATE;
    	for (var i = 0; i < findData.length; i++) {
    		//Create Token
    		const currentTimestamp        = Math.floor(Date.now() / 1000)
	        var channelName               = findData[i].channelName;
	       	var Id                        = findData[i].id;
	        const uid                     = 0;
	        const account                 = "0";
	        const role                    = RtcRole.PUBLISHER;
	        const expirationTimeInSeconds = 3600;
	        const privilegeExpiredTs      = currentTimestamp + expirationTimeInSeconds;
	        const tokenA                  = RtcTokenBuilder.buildTokenWithUid(appID, appCertificate, channelName, uid, role, privilegeExpiredTs);
	    	var updatetoken = await TeacherBooking.update(
                {
                    accessToken: tokenA
                },
                {
                    where:
                    { 
                    	id: Id
                    }
                }
            )
    	}
    	checkExpiryPlans();
      checkAdminExpiryPlans();

      var date = new Date();
  var res = date.setTime(date.getTime() - (7 * 24 * 60 * 60 * 1000));
  

  //Delete old notifications
  Notification.destroy({
    where: {
      createdAt: {
        [Op.lte]: res
      }
    }
  });
	} catch (e) {
		console.error(e.message)
	}

});

cron.schedule('* * * * *',  async() => {
	try{
		var newDate = moment(new Date()).format("YYYY-MM-DD");
    	var momentObj =  moment(new Date()).add(20,'m').format("hh:mm A");
    	
    	const findData = await TeacherBooking.findAll({
	      	where: {
		        bookingDate: newDate,
		        timeSlot: momentObj,
		        status: "0",
	      	}
    	});

    	for (var i = 0; i < findData.length; i++) {
    		var email = [];
    		var teacherId = findData[i].teacherId;
    		//Teacher User Details
    		const teacherdetails = await user.findOne({
                attributes: ['id','email'],
                where: {
                   id: teacherId
                }
            });
    		email.push(teacherdetails.dataValues.email);
            //Student User Details
    		var studentId = findData[i].userId;
    		const studentdetails = await user.findOne({
                attributes: ['id','email'],
                where: {
                   id: studentId
                }
            });
    		email.push(studentdetails.dataValues.email);
            //var array = email.split(',');
            console.log(email);
    		var htmldata =
            '<p>Hi</p>' +
          	'<p>We will send you a reminder email before the Tutoring to make sure you are logged in.</p>' +
          	'<p>Thanks,</p>' +
          	'<p>info@k12superhero.com</p>' +
          	'<p>--------</p>' +
          	'<p>This is an automated email. Please do not reply to it.</p>' +
          	'<p>In case of any help, kindly reach us at - please reach us at info@k12superhero.com" for any help" etc.</p>';
            var subject = "Schedule Reminder!";
            var mailOptions = {
              from: "info@k12superheroes.com",
              to: email,
              subject: subject,
              html: htmldata
            };
            transporter.sendMail(mailOptions, function(error, info){
                if (error) {
                    console.log("error",error)
                    //return helpers.jsonResponse(res, false, {}, "error", 400,400);
                }
            });
    	}
    	 // check for the expired current booking // when call is not started because of some reasons
       getRefundExpiredBookings()

	} catch (e) {
		console.error(e.message)
	}

});




async function checkAdminExpiryPlans() {
  try {
    var newDate = moment(new Date()).format("YYYY-MM-DD");
    //Get Plan
    const getplan = await TRIALSUB.findAll({
      where: {
        status: '1',
        endDate: {
          [Op.lt]: newDate
        }
      }
    });
    var MainArray = [];
    var EMailArray = [];
    for (var i = 0; i < getplan.length; i++) {
      var userId = getplan[i].adminId;
      var findData = await COMPANY.findOne({ where: { id: userId } });
      if (findData) {
        MainArray.push(userId);
        EMailArray.push(findData.dataValues.email);
        //Send Notification
        var notifPushUserData = {
          title: "Subscription/Trial Expired",
          description: "Your Subscription or trial has been expired.",
          token: findData.dataValues.deviceToken,
          platform: findData.dataValues.platform,
          userId: userId,
          notificationType: "Subscription Expire",
          status: "Expire",
        }
        commonNotification.insertNotification(notifPushUserData)
      }
    }
    if (MainArray.length > 0) {


      await COMPANY.update({
        status: 0
      },
        {
          where: {
          

              
                id: {
                  [Op.in]: MainArray
                }
              }


            




          
        });


      await users.update({
        status: 0
      },
        {
          where: {

            companyId: {
              [Op.in]: MainArray
            }
          }
        });
        await TRIALS.update({
          accountStatus: 0
        },
        {
          where: {
            email: {
              [Op.in]: EMailArray
            }
          }
        });
      //User Plan
      const updatedplanResponse = await TRIALSUB.update({
        status: '0'
      },
        {

          where: {
            adminId: {
              [Op.in]: MainArray
            }
          }
        });

    }
    //console.log("Plan Expired");
  }
  catch (e) {
    console.error(e.message)
  }


}
async function getRefundExpiredBookings(){
 
  var newDate = moment(new Date()).format("YYYY-MM-DD");
  // var momentObj =  moment(new Date()).add(20,'m').format("hh:mm A");
  var weekDayName =  moment(newDate).format('dddd');
  // console.log(weekDayName)
  
  // console.log('current time',moment(newDate).format("hh:mm a"))
  // console.log('current tiume-->',moment().format("hh:mm a"))

  const findData = await TeacherBooking.findAll({
    attributes: ['bookingDate','teacherId', 'userId','credit','timeSlot','status','bookingId', 
    [sequelize.literal('schedules.timeInterval'), 'timeInterval']
  ],
    where: {
      bookingDate: newDate,
      status:[0,1]
      // timeSlot: {
      //   [Op.gte]:  [sequelize.fn('COALESCE', sequelize.col('bookings.timeSlot'), sequelize.col('schedules.interval'))]
      // }
    },
    raw:false,
    nest:true,
    include:[{
      model:SCHEDULE,
      attributes:[ 'dayParts','timeInterval','slots' ],
      where:{
        
        dayParts:weekDayName
      }
    }]
  });

  if(findData){
    for(let i=0;i<findData.length;i++){
      // console.log(JSON.parse(JSON.stringify( findData[i] )))
      let currentTime =moment(new Date()).format("hh:mm a")
      // console.log( 'interval-->',findData[i].dataValues.timeInterval )
      // console.log( 'timeslot-->',findData[i].dataValues.timeSlot )
    
     let permittedDelay = parseFloat(findData[i].dataValues.timeInterval)*.40
     //console.log( 'permittedDelay',permittedDelay )
    
    let timeSlot =  moment(findData[i].dataValues.timeSlot, 'hh:mm a')
    let permittedtimeSlot = timeSlot.add(permittedDelay, 'minutes').format("hh:mm a")
    // console.log('prevtimeslot',prevtimeSlot)

    //  console.log( permittedtimeSlot.add(permittedDelay, 'minutes').format("hh:mm a") )
    //  console.log('curretn',currentTime,'permitted',permittedtimeSlot)
      // console.log(findData[i].dataValues)
      // console.log('params-->',findData[i].dataValues.bookingId, findData[i].dataValues.credit,findData[i].dataValues.credit,findData[i].dataValues.userId,findData[i].dataValues.teacherId)
      if(moment(permittedtimeSlot, 'hh:mm a').isBefore(moment(currentTime, 'hh:mm a')))
        {
           
           if(findData[i].dataValues.bookingId){// console.log('time is up processing funds  ',findData[i].dataValues.bookingId)
         cancelAndRefundBooking( findData[i].dataValues.bookingId, findData[i].dataValues.credit,findData[i].dataValues.userId,findData[i].dataValues.teacherId)
       }
 }
        
    }
  }
  // console.log('displaying the scehdulers')
  // console.log(JSON.parse(JSON.stringify(findData)))

}
async function cancelAndRefundBooking( bookingId, credit,userId,teacherId){
  // credit restore
  // console.log('details--->',bookingId, credit,userId,teacherId)

 let  teacherdetails = await userDetail.findOne({
    attributes: ['fName', 'lName','userId','rememberToken','deviceToken'],
    where: {
        userId: teacherId
    }
  });
  let  studentdetails = await userDetail.findOne({
    attributes: ['fName', 'lName','userId','rememberToken','deviceToken'],
    where: {
        userId: userId
    }
  });
  let teacherToken = parseInt(teacherdetails.dataValues.rememberToken) - parseInt(credit)
    const teacherCredit = await userDetail.update({
      rememberToken: teacherToken
    }, {
        where: {
            userId: teacherId
        }
    })
    let studetnToken = parseInt(studentdetails.dataValues.rememberToken) + parseInt(credit)
    const userCredit = await userDetail.update({
      rememberToken: studetnToken
      }, {
          where: {
              userId: userId
          }
      })

  // remove booking notification 
  // update status
  await bookingNotification.destroy({
    where: {
        bookId: bookingId,
        // teacherId: {
        //    [Op.ne]:  formData.teacherId
        // }
    } 
  })  
  //status:4
const bookings = await TeacherBooking.update({
 status:3
 }, {
     where: {
         bookingId: bookingId
     }
 })
//  sendNotification
//await common.addNotification(teacherId,userId,'Booking has been cancelled and refund is processed','Booking Cancelled');
//common.sendNotification(teacherdetails.dataValues.deviceToken,'Booking has been cancelled and refund is processed','Booking Cancelled')
//common.sendNotification(studentdetails.dataValues.deviceToken,'Booking has been cancelled and refund is processed','Booking Cancelled')
 let studentName = studentdetails.dataValues.fName+' '+studentdetails.dataValues.lName
 let teacherName = teacherdetails.dataValues.fName +' '+ teacherdetails.dataValues.lName
 let description = studentName +"'s"+' booking with '+teacherName+ " has been cancelled and refund is processed"
 let udescritpion = `Booking with ${teacherName} has been cancelled and refund is processed`
 let tdesciption = `Booking with ${studentName} has been cancelled and refund is processed`
//  sendNotification
await common.addNotification(teacherId,userId,description,'Booking Cancelled');
common.sendNotification(teacherdetails.dataValues.deviceToken,udescritpion,'Booking Cancelled')
common.sendNotification(studentdetails.dataValues.deviceToken,tdesciption,'Booking Cancelled')
}


async function checkExpiryPlans()
{
  try{
    var newDate = moment(new Date()).format("YYYY-MM-DD");
    
    console.log("check plan expire");
    //Get Plan
    const getplan = await USERSUB.findAll({
      where: {
        status: '1',
        endDate: {
          [Op.lt]: newDate
        }
      }
    });
    var MainArray = [];
    for (var i = 0; i < getplan.length; i++) {
      var userId = users[i].UserId;

      //Get Teacher UserDetails
      var userdetails = await userDetail.findOne({
          attributes: ['fName','lName','deviceToken'],
          where :{
              userId: userId
          },
          include: [{
              model: user,
              attributes: ['email']
          }]
      })

      var description ="Your Subscription has been expired.";
      if(userdetails)
      {
        MainArray.push(userId);
        if(userdetails.dataValues.deviceToken != "")
        { 

          var token = userdetails.dataValues.deviceToken;
          var requestType = "Subscription Expired";
          common.sendNotification(token,description,requestType);
          await Notification.create({
            senderId: userId,
            reciverId: userId,
            message : description,
            createdAt: Math.floor(new Date().getTime() / 1000)

          });
        }
      }
    }
    if(MainArray.length > 0)
    {
      //  const updatedResponse = await USER.update({
      //   userType: '3'
      //   }, 
      //   {
      //   where : { 
      //     id: {
      //       [Op.in]: MainArray
      //     }
      //   }
      // });

       //User Plan
      const updatedplanResponse = await USERSUB.update({
        status: '0'
        }, 
        {
        where : { 
          userId: {
            [Op.in]: MainArray
          }
        }
      });
    }
         console.log("Plan Expired");
  }
  catch (e) {
    console.error(e.message)
  }
}