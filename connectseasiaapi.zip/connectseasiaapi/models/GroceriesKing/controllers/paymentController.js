
const model = require("../models/index");
const helpers = require("../helpers");
const { createToken } = require("../middleware");
const handleError = helpers.handleError;
const Stripe = require('stripe');
const stripe = Stripe('sk_test_51IbQEZSF00mhLIsZiT8ZcRD49yVISAkqjdlAU0C2xmaZRkEUI4DEO7iqvvoYfTf0eutsoURrZpVekLHGCcfBqis000j9pI7ZaY');
module.exports = {
  /***************************************************/
  /******* Create Payment Intent *********************/
  /**************************************************/
  createephemeralKeys: async function(req, res) {
    const params = req.body;
    try {
      const ChckEmail = await userDetail.findOne({
        where: {
          userId: req.id
        }
      }) 
      if (ChckEmail) 
      {
        if(ChckEmail.dataValues.stripeCustomerId == "")
        {

          const userdetails = await user.findOne({
              attributes: ['id','email'],
              where: {
                 id: req.id
              }})

          stripe.customers.create({
            name: ChckEmail.dataValues.fName + ' '+ ChckEmail.dataValues.lName,
            email: userdetails.dataValues.email,
            description: 'Customer for '+ userdetails.dataValues.email,
            phone: ChckEmail.dataValues.phoneNo
           
          }, async function (err, customer) {
            if (typeof customer !== 'undefined' && customer) {
              var response = await userDetail.update({
                stripeCustomerId: customer.id
              },{
                where: {
                  userId: req.id
                }
              });
              var key = await stripe.ephemeralKeys.create(
                {customer: customer.id},
                {apiVersion: params.apiversion}
              );
              // return helpers.jsonResponse(
              //   res,
              //   true,
              //   key,
              //   appstrings.empherial_key,
              //   200,
              //   200
              // );
              return res.json(key);
            } else {
              return helpers.jsonResponse(res, false, {}, err, 400, 400);
            }
          });
        }
        else {
          var key = await stripe.ephemeralKeys.create(
            {customer: ChckEmail.dataValues.stripeCustomerId},
            {apiVersion: params.apiversion}
          );
          // return helpers.jsonResponse(
          //   res,
          //   true,
          //   key,
          //   appstrings.empherial_key,
          //   200,
          //   200
          // );
          return res.json(key);
        }
      }
      else{
        return helpers.jsonResponse(res, false, {},appstrings.oops_something,400, 400);
      }
  
    }
    catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /***************************************************/
  /******* Create Payment Intent *********************/
  /**************************************************/
  createpaymentIntents: async function(req, res) {
    const params = req.body;
    try {
      const ChckEmail = await userDetail.findOne({
        where: {
          userId: req.id
        }
      })
      const paymentIntent = await stripe.paymentIntents.create({
        amount: parseInt(params.amount) *10,
        currency: params.currency,
        description: 'Software development services',
        payment_method: params.paymentMethodId,
        customer: ChckEmail.dataValues.stripeCustomerId,
        confirm:true,
      });
        return helpers.jsonResponse(
          res,
          true,
          paymentIntent,
          appstrings.payment_intent_success,
          200,
          200
        );
    }
    catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  }
};