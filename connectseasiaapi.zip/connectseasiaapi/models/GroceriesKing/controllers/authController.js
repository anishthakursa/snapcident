
const jwt = require("jsonwebtoken");
const sequelize = require('sequelize');
const moment = require('moment');
var  months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
module.exports = {
  //////============================= Login Function ===============================//////
  login: async (req, res) => {
    try {
       if(req.session.userData){
         return res.redirect('/super/home');
      }
      return res.render('pages/super/login',{});
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  ///////////////////////// Admin Post Login /////////////////////////////
  postLogin: async (req, res) => {
    try {
      const data = req.body;
    
      const user = await COMPANY.findOne({
         where: {
           email: data.email,
           role:1
         }
       });
	  
      if (user) {
        const getUser = user.toJSON();
	    //const match = await hashPassword.comparePass(data.password, getUser.password);
     const match=true
        // compare pwd
        if (!match) {
          return helpers.jsonResponse(res, false, {}, appstrings.invalid_password, 400, 400);
        }
        // getUser.credit       = getUser.rememberToken;
        req.session.userData = getUser;
		    req.session.email    = getUser.email;
        req.session.roleType = "Super";
        req.session.userData.roleType ="Super-Administrator"
        const credentials = {
          id: getUser.id,
          email: getUser.email,
        };
      
        const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256', expiresIn: config.authTokenExpiration });
        const refreshToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256', expiresIn: config.refreshTokenExpiration });
        getUser.authToken = authToken;
        getUser.refreshToken = refreshToken;
        // return res.redirect('/super/home');
        return helpers.jsonResponse(res, true, {}, appstrings.login_success, 200, 200);
      }
      return helpers.jsonResponse(res, false, {}, appstrings.invalid_credentials, 400, 400);
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  postLoginTrial: async (req, res) => {
    try {
      const data = req.body;
    
      const codeData = await COMPANY.findOne({ where: {code: params.code}});

if(codeData)
{
      const user = await COMPANY.findOne({
         where: {
           email: data.email,
           role:1,
           companyId:codeData.dataValues.id

         }
       });



	  
      if (user) {
        const getUser = user.toJSON();
	    //const match = await hashPassword.comparePass(data.password, getUser.password);
     const match=true
        // compare pwd
        if (!match) {
          return helpers.jsonResponse(res, false, {}, appstrings.invalid_password, 400, 400);
        }
        // getUser.credit       = getUser.rememberToken;
        req.session.userData = getUser;
		    req.session.email    = getUser.email;
        req.session.roleType = "Super";
        req.session.userData.roleType ="Super-Administrator"
        const credentials = {
          id: getUser.id,
          email: getUser.email,
        };
      
        const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256', expiresIn: config.authTokenExpiration });
        const refreshToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256', expiresIn: config.refreshTokenExpiration });
        getUser.authToken = authToken;
        getUser.refreshToken = refreshToken;
        // return res.redirect('/super/home');
        return helpers.jsonResponse(res, true, {}, appstrings.login_success, 200, 200);
      }
      else return helpers.jsonResponse(res, false, {}, appstrings.invalid_credentials, 400, 400);
    }
  
  else return responseHelper.post(res, appstrings.code_invalid, null, 400);

  }
    catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }





  },
//   /////////////////////////// Admin Dashboard ////////////////////
home: async (req, res) => {
    try {
       if(req.session.userData){
            return res.render('pages/super/dashboard',{});
      }
      return res.render('pages/super/login');
    } catch (e) {
      console.log('Error => ', e);
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
  /* forget password */
   ////////////////////////////////////////////////////////////
  ///////////// Forgot PAge //////////////////////////////////
  ////////////////////////////////////////////////////////////
  forgotPassword:  async (req, res, next) => {
    try {
      console.log('--1')
      return res.render('pages/super/forgotPassword');
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  ///////////////////////////////////////////////
  /////////// Post Forgot Password //////////////
  //////////////////////////////////////////////
  postforgotPassword: async (req, res, next) => {
   
      var params=req.body
      let responseNull= commonMethods.checkParameterMissing([params.email])
      if(responseNull) return responseHelper.post(res, appstrings.required_field,null,400);
          try{
                 userData = await COMPANY.findOne({
                where: {
                    email: params.email,
                  }
                  })   
                  if(userData)
                 {
                    userData= JSON.parse(JSON.stringify(userData))
                      var number= Math.floor(Math.random()*(10000000-0+1)+10000000 )+"";
                      const newPassword = await hashPassword.generatePass(number);
                      var dataEmail={name: userData.companyName,password: number,app_name:config.APP_NAME}
                      commonNotification.sendForgotPasswordMail(userData.email,dataEmail,userData,req.id)
                      await COMPANY.update({ password: newPassword}, {where: { id: userData.id}}) ;
                   return responseHelper.post(res, appstrings.password_reset_success,null,200, )}  
                 
                     else    
                  {  
                      return responseHelper.post(res, appstrings.no_record,null,204);
                  }
    
                     
      }catch (e) {
          console.log(e)
            return responseHelper.error(res, e.message);
    
      }
    
    },
  //   /////////////////////////// Admin Logout ////////////////////
  logout: async(req, res) => {
    req.session.destroy((err) => {
    if(err) {
      return console.log(err);
    }
    return res.redirect('/super/');
    });
  },

  ////////////////////////////////////////////////////////////
  ///////////// Forgot PAge //////////////////////////////////
  ////////////////////////////////////////////////////////////
  changePassword:  async (req, res, next) => {
    try {
      console.log('---->123');
      return res.render('pages/super/changePassword');
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

   ////////////////////////////////////////////////////////////
  ///////////// Post Change Password //////////////////////////////////
  ////////////////////////////////////////////////////////////
  postChangePassword:  async (req, res, next) => {
    try {
      const params = req.body;
      const userData = await COMPANY.findOne({
        where: {
          id: req.id,
        }
      })  
      if(userData)
      {
        const match = await hashPassword.comparePass(params.oldPassword,userData.dataValues.password);
        if (!match) {
          return helpers.jsonResponse(
            res,
            true,
            {},
            appstrings.inccorect_oldpass,
            204,
            204
          );
        }else{
          const newPassword = await hashPassword.generatePass(params.npassword);
          await COMPANY.update({ password: newPassword}, {where: { id: req.id}}) ;
          return helpers.jsonResponse(
            res,
            true,
            {},
            appstrings.password_change_success,
            200,
            200
          ); 
          
        }
      }  
      else    
      { 
       return helpers.jsonResponse(res, false, {},appstrings.no_record, 204, 204);
      }
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },
//     newdashboard:async(req,res)=>{
//     try{

//     const companyId = req.session.userData.id;
//     //Avg Renve

//     //Total Revnue
//     const totalRevenue = await TeacherBooking.findOne({
//     attributes: [
//     [sequelize.fn('sum', sequelize.col('credit')), 'totalAmount'],
//     ],
//     where:{
//     companyId: companyId
//     }
//     })

//     //Total Booking
//     var totalBooking = await bookingNotification.findAll({
//     where:{
//     companyId: companyId
//     }
//     });

//     //Top 5 Professional
//     var where={
//     role: '2',
//     companyId: companyId
//     }

//     var limit  = 5;
//     var offset = 0;
//     const MainArray = [];

//     //Get Free Delivery Restuarant
//     var featured = await subject.findAll({
//     attributes: ['id','name','image'],
//     where:{
//     companyId: companyId
//     }
//     });

//     for (var i = 0; i < featured.length; i++) 
//     {
//     var array = {};
//     var id = featured[i].id;
//     var name = featured[i].name;
//     array.type = name;
//     array.categoryId = id;
//     var restDetails = await USER.findAll({
//     attributes: ['id','email',[sequelize.literal('(SELECT ROUND(AVG(rating),1) FROM ratings where teacherId = users.id)'), 'totalRating']],
//     where: {
//     role : '2',
//     companyId: companyId
//     },
//     order: sequelize.literal(`totalRating DESC`),
//     include: [
//     {
//         model: teacherSubject,
//         required: true,
//         attributes: [],
//         where: { 
//             subjectId: id
//         }
//     },
//     {
//         model: userDetail,
//         attributes: ['fName','lName','dob','image','uniqueId'],
//         required: true,
//         where: {
//             status: '1'
//         } 
//     }
//     ],
//     offset: offset, 
//     limit: limit,
//     });
//     array.professional = restDetails;
//     if(restDetails.length > 0)
//     {
//     MainArray.push(array);
//     }
//     }

//     var MainArrayN = JSON.parse(JSON.stringify(MainArray));

//     const userData = await USER.findAll({
//     attributes: ['id','email',
//     [sequelize.literal('(SELECT ROUND(AVG(rating),0) FROM ratings where teacherId = users.id)'), 'totalRating']],
//     where: where,
//     order: sequelize.literal(`totalRating DESC`),
//     include: [{
//     model: userDetail,
//     attributes: ['fName','lName','status']
//     }],
//     limit:5, offset:0
//     }); 

//     //Total Categories
//     var totalCategory = await subject.findAll({
//     where:{
//     companyId: companyId
//     }
//     });

//     //Total Customer
//     var totalCustomers = await USER.findAll({
//     where: {
//     role: '1',
//     companyId: companyId
//     }
//     });

//     //TotalProfessional
//     var totalProfessional = await USER.findAll({
//     where: {
//     role: '2',
//     companyId: companyId
//     }
//     });

//     //Get Recent Bookings
//     var newDate = moment(new Date()).format("YYYY-MM-DD");
//     const usr = await bookingNotification.findAll({
//     attributes: ['bookId','teacherId','description','status'],
//     where:{
//     companyId: companyId
//     },
//     include: [{
//     model: StudentbookingDetail,
//     attributes: ['id','studentId','bookingDate','timeSlot'],
//     required: true,
//     where: {
//     bookingDate: newDate
//     },
//     include: [{
//     model: userDetail,
//     attributes: ['fName','lName','image']
//     }]
//     }]
//     });
//     console.log(usr)
//     var usrArray = [];
//     for(var k=0;k<usr.length;k++)
//     {
//     var array = {};

//     array.bookingDate  = usr[k].bookingDetail.bookingDate;
//     array.timeSlot     = usr[k].bookingDetail.timeSlot;
//     //Get Student Name
//     var stuentNmae = await userDetail.findOne({
//     attributes: ['fName','lName'],
//     where: {
//     userId: usr[k].bookingDetail.studentId
//     }
//     });
//     array.sName     = stuentNmae.dataValues.fName+ ' ' +stuentNmae.dataValues.lName;
//     //Get Teacher Details
//     var teacherName = await userDetail.findOne({
//     attributes: ['fName','lName'],
//     where: {
//     userId: usr[k].teacherId
//     }
//     });
//     array.tName     = teacherName.dataValues.fName+ ' ' +teacherName.dataValues.lName;
//     //Get Category Details
//     var categoryName = await subject.findOne({
//     attributes: ['id','name','image'],
//     where:{
//     companyId: companyId
//     }
//     });
//     array.category     = categoryName.dataValues.name;
//     usrArray.push(array);
//     }

//     //Get Revenue All Categories
//     var data = {};
//     data.totalCustomers = totalCustomers;
//     data.totalProfessional = totalProfessional;
//     data.totalCategory = totalCategory;
//     data.totalBooking = totalBooking;
//     data.userData = userData;
//     data.CategoryProfessional = MainArrayN;
//     data.totalRevenue = totalRevenue.dataValues.totalAmount;
//     return res.render('pages/admin/dashboard',{data,usrArray,moment});
//     } catch (e) {
//     console.log('Error => ', e);
//     return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
//     }
//     },

//   ////////////////////////////////////////////////////////////
//   ///////////// Forgot PAge //////////////////////////////////
//   ////////////////////////////////////////////////////////////
//   forgotPassword:  async (req, res, next) => {
//     try {
//       return res.render('pages/admin/forgotPassword');
//     } catch (e) {
//       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
//     }
//   },

//   ///////////////////////////////////////////////
//   /////////// Post Forgot Password //////////////
//   //////////////////////////////////////////////
//   postforgotPassword: async (req, res, next) => {
   
//       var params=req.body
//       let responseNull= commonMethods.checkParameterMissing([params.email])
    
//       if(responseNull) return responseHelper.post(res, appstrings.required_field,null,400);
    
//           try{
//                  userData = await COMPANY.findOne({
//                 where: {
//                     email: params.email,
//                   }
//                   })  
                    
//                   if(userData)
//                  {
    
                  
//                     userData= JSON.parse(JSON.stringify(userData))
    
    
//                       var number= Math.floor(Math.random()*(10000000-0+1)+10000000 )+"";
//                       const newPassword = await hashPassword.generatePass(number);
//                      var dataEmail={name: userData.companyName,password: number,app_name:config.APP_NAME}
//                      commonNotification.sendForgotPasswordMail(userData.email,dataEmail,userData,req.id)
//                       await COMPANY.update({ password: newPassword}, {where: { id: userData.id}}) ;
    
//                    return responseHelper.post(res, appstrings.password_reset_success,null,200, )}  
                 
//                      else    
//                   {  
//                       return responseHelper.post(res, appstrings.no_record,null,204);
//                   }
    
                  
    
    
                         
//       }catch (e) {
//           console.log(e)
//             return responseHelper.error(res, e.message);
    
//       }
    
//     },

//     ////////////////////////////////////////////////////////////
//   ///////////// Forgot PAge //////////////////////////////////
//   ////////////////////////////////////////////////////////////
//   changePassword:  async (req, res, next) => {
//     try {
//       return res.render('pages/admin/changePassword');
//     } catch (e) {
//       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
//     }
//   },

//    ////////////////////////////////////////////////////////////
//   ///////////// Post Change Password //////////////////////////////////
//   ////////////////////////////////////////////////////////////
//   postChangePassword:  async (req, res, next) => {
//     try {
//       const params = req.body;
//       const userData = await COMPANY.findOne({
//         where: {
//           id: req.id,
//         }
//       })  
//       if(userData)
//       {
//         const match = await hashPassword.comparePass(params.oldPassword,userData.dataValues.password);
//         if (!match) {
//           return helpers.jsonResponse(
//             res,
//             true,
//             {},
//             appstrings.inccorect_oldpass,
//             204,
//             204
//           );
//         }else{
//           const newPassword = await hashPassword.generatePass(params.npassword);
//           await COMPANY.update({ password: newPassword}, {where: { id: req.id}}) ;
//           return helpers.jsonResponse(
//             res,
//             true,
//             {},
//             appstrings.password_change_success,
//             200,
//             200
//           ); 
          
//         }
//       }  
//       else    
//       { 
//        return helpers.jsonResponse(res, false, {},appstrings.no_record, 204, 204);
//       }
//     } catch (e) {
//       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
//     }
//   },

//   ////////////////////////////////////////////////////////////
//   ///////////// View Profile //////////////////////////////////
//   ////////////////////////////////////////////////////////////
//   viewProfile:  async (req, res, next) => {
//     try {
//       const user = await COMPANY.findOne({
//          where: {
//            id: req.id
//          }
//        });
//       return res.render('pages/admin/profile',{user});
//     } catch (e) {
//       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
//     }
//   },


//    ////////////////////////////////////////////////////////////
//   ///////////// Post Change Password //////////////////////////////////
//   ////////////////////////////////////////////////////////////
//   updateProfile:  async (req, res, next) => {
//     try {
//       const params = req.body;
//       const userData = await COMPANY.findOne({
//         where: {
//           id: req.id,
//         }
//       })  
//       if(userData)
//       {
//         var icon = "";
//             if (req.files) {
//                 ImageFile = req.files.image;  
//                 if(ImageFile)
//                 {
//                     icon = Date.now() + '_' + ImageFile.name;
//                     ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
//                         //upload file
//                         if (err)
//                         return helpers.jsonResponse(res, false, {}, err.message, 400);
//                     });
//                 }
//             }

//         await COMPANY.update({ 
//           address: params.address1,
//           longitude: params.longitude,
//           latitude: params.latitude,
//           fName: params.firstName,
//           lName: params.lastName,
//           image: (icon != "") ? icon : userData.dataValues.image
//         }, {
//           where: { 
//             id: req.id
//           }
//         }) ;

//  	req.session.userData.fName =params.firstName
//             	let img =(icon != "") ? icon : userData.dataValues.image
//         	req.session.userData.image = '/images/'+img

//         return helpers.jsonResponse(
//           res,
//           true,
//           {},
//           appstrings.success,
//           200,
//           200
//         );
//       }  
//       else    
//       { 
//        return helpers.jsonResponse(res, false, {},appstrings.no_record, 204, 204);
//       }
//     } catch (e) {
//       return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
//     }
//   },
  
};
