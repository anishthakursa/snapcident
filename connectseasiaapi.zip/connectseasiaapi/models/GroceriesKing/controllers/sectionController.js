const model = require("../models/index");
const sequelize = model.sequelize;
const { createToken } = require("../middleware");
const helpers = require("../helpers");
const handleError = helpers.handleError;

module.exports = {


//////////////////////////////////////////////////////////////////////////////////
///////////////////////// get section based on the classs   /////////////////////
//////////////////////////////////////////////////////////////////////////////// 
    
section: async function(req, res) {
    try {
        const sec = await section.findAll({
            attributes: ['id', 'name'],
            where: {
                status: 1,                    /// only active
                classId: req.params.classId           
            }
        });
        if (sec) {
            return helpers.jsonResponse(res,true,sec,"List", 200, 200);
        }

    } catch (e) {
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
    },

   
};
