const express = require('express');
const app = express();
const db = require('../../db/db');
const weight = db.models.weight;


app.get('/getWeightList', checkAuth, async (req, res, next) => {
  try {
    var weightData = await weight.findAll({
      attributes: ['id', 'name'],
      where: {
        status: 1
      }
    })

    if (weightData) {
      if (weightData.length > 0) return responseHelper.post(res, appstrings.success, weightData)
      else
        return responseHelper.post(res, appstrings.no_record, null, 204);

    }
    else return responseHelper.post(res, appstrings.no_record, null, 204);

  }
  catch (e) {
    return responseHelper.error(res, e.message, 400);
  }
});

app.post('/addWeight', checkAuth, async (req, res, next) => {
    var data = req.body;
    let responseNull = commonMethods.checkParameterMissing([data.name])
    if (responseNull) return responseHelper.post(res, appstrings.required_field, null, 400);
    try {
      var weightData = await weight.findOne({
          where: {
              name: data.name
          }
      })
  
      if (!weightData) {
        var createData = await weight.create({
            name: data.name
        
        })
        if(createData)
            return responseHelper.post(res, appstrings.success, createData)  ;
        else    
            return responseHelper.error(res, "Unable to insert!", 402);
      }
      else return responseHelper.post(res, "Weight with this name already exists!", null, 204);
  
    }
    catch (e) {
      return responseHelper.error(res, e.message, 400);
    }
  });




module.exports = app;