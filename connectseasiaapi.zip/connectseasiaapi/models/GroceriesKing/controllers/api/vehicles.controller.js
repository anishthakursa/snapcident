const express = require('express');
const app = express();
const db = require('../../db/db');
const vehicle = db.models.vehicle;
const weight = db.models.weight;
const Op = require('sequelize').Op;

app.get('/getList', checkAuth, async (req, res, next) => {
  try {
    var vehicleData = await vehicle.findAll({
      attributes: ['id', 'name', 'icon', 'price'],
      where: {
        status: 1
      }
    });
    var weightData = await weight.findAll({
      attributes: ['id', 'name', 'price', 'icon'],
      where: {
        status: 1
      },
      order: [
        ['orderBy', 'ASC'],
      ],
    });
    var bannersData = await BANNERS.findAll({
      attributes: ['id', 'name', 'icon', 'thumbnail', 'code', 'discount', 'validupto', 'description'],
      where: {
        companyId: req.companyId,
        status: 1
      }
    })
    var adsData = await ADS.findAll({
      attributes: ['id', 'name', 'url'],
      where: {
        companyId: req.companyId,
        status: 1
      }
    })
     //Offers
    //  var newDate = moment(new Date()).format("MM/DD/YYYY");
    //  const coupon = await COUPAN.findAll({
    //    attributes: ['id', 'name', 'icon', 'thumbnail', 'code', 'discount', 'validupto', 'description'],
    //    where: {
    //      status: 1,
    //      companyId: req.companyId,
    //      validupto: {
    //        [Op.gte]: new Date()
    //      }
    //    }
    //  })
    const deliveryOption = await DELIVERYOPTION.findAll({
    })
    
    bannersData = JSON.parse(JSON.stringify(bannersData));
    // couponData = JSON.parse(JSON.stringify(coupon));
    adsData = JSON.parse(JSON.stringify(adsData));
    var offerData = [];
    'id', 'name', 'icon', 'thumbnail', 'code', 'discount', 'validupto', 'description'
    bannersData.map(data=>{
      var obj = {
        id: data.id,
        type: "banner",
        icon: data.icon,
        thumbnail: data.thumbnail,
        name: data.name,
        code: data.code,
        discount: data.discount,
        validupto: data.validupto,
        description: data.description
      }
      offerData.push(obj)
    });
    // console.log('====bannersData', bannersData)
    // couponData.map(data=>{
    //   var obj = {
    //     id: data.id,
    //     type: "coupon",
    //     icon: data.icon,
    //     thumbnail: data.thumbnail,
    //     name: data.name,
    //     code: data.code,
    //     discount: data.discount,
    //     validupto: data.validupto,
    //     description: data.description
    //   }
    //   offerData.push(obj)
    // })

    adsData = [];
    adsData.map(data=>{
      var obj = {
        id: data.id,
        type: "ads",
        icon: data.url,
        thumbnail: data.url,
        name: data.name,
        code: "",
        discount: "",
        validupto: "",
        description: ""
      }
      offerData.push(obj)
    });
    var com = await COMPANY.findOne({attributes:['countryCode','phoneNumber','custPhoneNumber'], where:{id: req.companyId}})

    var preSetData = await commonMethods.getLinks(req.companyId);
    var referredByPoint = 0; referredToPoint=0;

    if (preSetData && preSetData.dataValues && preSetData.dataValues.loyalityPoints) {
      referredByPoint = Number(preSetData.dataValues.loyalityPoints);
      referredToPoint = Number(preSetData.dataValues.loyalityPointsTo);
      
    }
    //Comleted Order
    var empData = await getRecentComletedOrder(req.id);

    var responseData = {
      vehicleData : vehicleData ? vehicleData : [],
      weightData : weightData ? weightData : [],
      deliveryOptionData: deliveryOption ? deliveryOption : [],
      bannersData: offerData,
      adminNumber: com.dataValues.custPhoneNumber,
      referredToPoint: referredToPoint,
      referredByPoint: referredByPoint,
      completedorder: empData,
      androidLink: preSetData && preSetData.dataValues ? preSetData.dataValues.androidLink : "https://www.cerebruminfotech.com/",
      iosLink: preSetData && preSetData.dataValues ? preSetData && preSetData.dataValues.iosLink : "https://www.cerebruminfotech.com/"
  }
    
    if (responseData) {
    
      return responseHelper.post(res, appstrings.success, responseData)

    }
    else return responseHelper.post(res, appstrings.no_record, null, 204);

  }
  catch (e) {
    return responseHelper.error(res, e.message, 400);
  }
});


async function getRecentComletedOrder(userId) {


  var empData = {}
  var completedtOrder = await ORDERS.findOne({
    attributes: ['id', 'companyId','createdAt'],
    where: { userId: userId, progressStatus: 7, userShow: [0,2] },
    include: [{
      model: ASSIGNMENT, attributes: ['empId'],where: { jobStatus: 4 },
      include: [{ model: EMPLOYEE, attributes: ['firstName', 'lastName', 'phoneNumber', 'image'] }],

    }],
    order: [
      ['createdAt', 'DESC']],
  });
console.log("=====completedtOrder====", completedtOrder)
  if (completedtOrder && completedtOrder.dataValues && completedtOrder.dataValues.assignedEmployees.length > 0) {
    empData.empId = completedtOrder.dataValues.assignedEmployees[0].empId
    empData.companyId = completedtOrder.dataValues.companyId
    empData.orderId = completedtOrder.dataValues.id
    var empDetails = completedtOrder.dataValues.assignedEmployees[0].employee;
    if(empDetails){
      empData.firstName = empDetails.firstName
      empData.lastName = empDetails.lastName
      empData.image = empDetails.image
    }
    
    ORDERS.update({ userShow: 1 }, { where: { id: completedtOrder.dataValues.id } });

  }

  return empData



}

module.exports = app;