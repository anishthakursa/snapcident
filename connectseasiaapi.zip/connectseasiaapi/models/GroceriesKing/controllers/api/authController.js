const express = require('express');

const app = express();
const bcrypt = require('bcryptjs');
const v = require('node-input-validator');
const hashPassword = require('../../helpers/hashPassword');

const jwt = require('jsonwebtoken');
const util = require('util');
const mysql = require('mysql2/promise');
var countryTelData = require('country-telephone-data')
var cc = require('iso-country-currency');
var countries = countryTelData.allCountries

require('dotenv').config({
    path: `../env-files/${process.env.NODE_ENV || 'development'}.env`,
});
var randomEmail = require('random-email');

USER = db.models.users
    // Generate Hash
const createHash = password => {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(10), null);
};



app.post('/logout', checkAuth, async(req, res, next) => {
    const params = req.body;
    try {

        const updatedResponse = await USER.update({
            sessionToken: "",
            deviceToken: "",
        }, {
            where: {
                id: req.id,
                companyId: req.myCompanyId
            }
        });



        if (updatedResponse) {
            return responseHelper.post(res, 'Logout Successfully');
        } else
            return responseHelper.post(res, 'Logout Successfully');


    } catch (e) {
        return responseHelper.error(res, e.message, 400);
    }




})



app.post('/signup', async(req, res) => {
    try {
        const data = req.body;


        let responseNull = commonMethods.checkParameterMissing([data.phoneNumber, data.countryCode, data.companyId, data.firstName, data.email, data.password])
        if (responseNull) return responseHelper.post(res, appstrings.required_field, null, 400);


        const user = await USER.findOne({
            attributes: ['phoneNumber'],
            where: {
                phoneNumber: data.phoneNumber,
                companyId: data.companyId

            }
        });



        if (!user) {
            const pswd = await hashPassword.generatePass(data.password);
            data.password = pswd;



            const users = await USER.create({
                firstName: data.firstName,
                fullName: params.firstName,
                email: data.email,
                address: data.address,
                phoneNumber: data.phoneNumber,
                countryCode: data.countryCode,
                password: pswd,
                deviceToken: data.deviceToken,
                platform: data.platform,
                companyId: data.companyId
            });


            if (users) {
                const userId = users.dataValues.id;
                data.userId = userId;
                const credentials = {
                    phoneNumber: users.dataValues.phoneNumber,
                    companyId: users.dataValues.companyId,
                    countryCode: users.dataValues.countryCode,
                    userType: 1,
                    id: userId,
                    exp: Math.floor(Date.now() / 1000) + 8640000*2,
                };



                const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });
                const refreshToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256'});
                const userDetail = {};
                userDetail.email = users.dataValues.email;
                userDetail.firstName = users.dataValues.firstName;
                userDetail.lastName = users.dataValues.lastName;
                userDetail.image = '';
                // userDetail.deviceToken = users.dataValues.deviceToken;
                userDetail.sessionTken = authToken;
                userDetail.refreshToken = refreshToken;
                userDetail.id = userId;


                const updateDevicetoken = await USER.update({
                    sessionToken: authToken,
                    platform: data.deviceToken,
                    deviceToken: data.deviceToken,
                }, {
                    where: {
                        id: users.dataValues.id
                    }
                });
                return responseHelper.post(res, appstring.success, userDetail);
            }

        } else {
            responseHelper.error(res, appstrings.already_exists, 409);
        }

    } catch (e) {
        return responseHelper.error(res, appstrings.oops_something, e.message);
    }

})


app.post('/login', async(req, res, next) => {
    const params = req.body;


    let responseNull = commonMethods.checkParameterMissing([params.phoneNumber, params.countryCode, params.companyId])
    if (responseNull) return responseHelper.post(res, appstrings.required_field, null, 400);


    var countryCode = params.countryCode.replace("+", "")
    let obj = countries.find(o => o.dialCode === countryCode);

    var currency = "Rs"
    var currencyName = "inr"

    if (obj) {
        var currencyData = cc.getAllInfoByISO(obj.iso2)
        currency = currencyData.symbol
        currencyName = currencyData.currency
    }

    try {
        const userData = await USER.findOne({
            where: {
                phoneNumber: params.phoneNumber,
                countryCode: countryCode

            }
        })

        if (userData) {


            let token = jwt.sign({
                    phoneNumber: params.phoneNumber,
                    myCompanyId: userData.dataValues.companyId,
                    countryCode: countryCode,
                    userType: 1,
                    currency: currency,
                    parentCompany: userData.dataValues.companyId,
                    id: userData.dataValues.id,
                    exp: Math.floor(Date.now() / 1000) + 8640000*2,

                },
                config.jwtToken, { algorithm: 'HS256' }
            );



            const updatedResponse = await USER.update({
                sessionToken: token,
                platform: params.platform,
                deviceToken: params.deviceToken,
                currency:currency,
                currencyName:currencyName,
            }, {
                where: {
                    id: userData.dataValues.id
                }
            });



            if (updatedResponse) {
                // if (params.referralCode && params.referralCode != "")
                //   setReferralPoints(params.referralCode, userData.dataValues.id, params.companyId, userData.dataValues.lPoints)

                userData.dataValues.sessionToken = token
                userData.dataValues.platform = params.platform
                userData.dataValues.deviceToken = params.deviceToken
                userData.dataValues.isFirst = false
                var btype = await commonMethods.getBusinessType(params.companyId)
                if (btype && btype.dataValues && btype.dataValues.type) userData.dataValues.btype = btype.dataValues.type
                else userData.dataValues.btype = 0

                return responseHelper.post(res, 'Login Successfully', userData);
            }
        } else {


            const users = await USER.create({
                firstName: params.firstName,
                lastName: params.lastName,
                email: params.email,
                fullName: params.firstName + " " + params.lastName,
                address: params.address,
                phoneNumber: params.phoneNumber,
                countryCode: countryCode,
                deviceToken: params.deviceToken,
                platform: params.platform,
                currency:currency,
                currencyName:currencyName,
                companyId: params.companyId,


            });


            if (users) {
                const userId = users.dataValues.id;
                params.userId = userId;


                const credentials = {
                    phoneNumber: users.dataValues.phoneNumber,
                    myCompanyId: users.dataValues.companyId,
                    parentCompany: users.dataValues.companyId,
                    countryCode: users.dataValues.countryCode,
                    currency: users.dataValues.currency,
                    userType: 1,
                    id: userId,
                    exp: Math.floor(Date.now() / 1000) + 8640000*2,
                };



                const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });
                const refreshToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });

                // if (params.referralCode && params.referralCode != "") setReferralPoints(params.referralCode, userId, params.companyId, users.dataValues.lPoints)



                var referralCode = "USERDELC" + userId.substring(1, 7).toUpperCase()


                const updateDevicetoken = await USER.update({
                    sessionToken: authToken,
                    platform: params.deviceToken,
                    deviceToken: params.deviceToken,
                    refreshToken: refreshToken,
                    currency:currency,
                    currencyName:currencyName,
                    referralCode: referralCode

                }, {
                    where: {
                        id: users.dataValues.id
                    }
                });

                const userData = await USER.findOne({
                    where: {
                        id: users.dataValues.id,

                    }
                })

                var btype = await commonMethods.getBusinessType(params.companyId)
                if (btype && btype.dataValues && btype.dataValues.type) userData.dataValues.btype = btype.dataValues.type
                else userData.dataValues.btype = 0
                if (userData) {
                    userData.dataValues.isFirst = true











                    return responseHelper.post(res, 'User Detail', userData);
                } else return responseHelper.post(res, 'Something Error', null, 400);

            }
        }


    } catch (e) {
        return responseHelper.error(res, e.message, 400);
    }

})


async function newUser(params, req, res, isNew, countryCode, companyId) {


    let obj = countries.find(o => o.dialCode === countryCode);

    var currency = "Rs"
    var currencyName = "inr"
    if (obj) {
        var currencyData = cc.getAllInfoByISO(obj.iso2)
        currency = currencyData.symbol
        currencyName = currencyData.currency
    }

    const users = await USER.create({
        firstName: params.firstName,
        fullName: params.firstName,
        email: params.email,
        address: params.address,
        deviceUniqueId: params.deviceId,
        phoneNumber: params.phoneNumber,
        countryCode: countryCode,
        deviceToken: params.deviceToken,
        platform: params.platform,
        companyId: companyId,
        currency: currency,
        currencyName: currencyName,
        code: params.code
    });


    if (users) {
        const userId = users.dataValues.id;
        params.userId = userId;


        //Remove guest user 



        const credentials = {
            phoneNumber: users.dataValues.phoneNumber,
            myCompanyId: users.dataValues.companyId,
            parentCompany: users.dataValues.companyId,
            currency: users.dataValues.currency,
            countryCode: users.dataValues.countryCode,
            userType: 1,
            id: userId,
            exp: Math.floor(Date.now() / 1000) + 8640000*2,
        };


        const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });
        const refreshToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });

        // if (params.referralCode && params.referralCode != "") 
        // setReferralPoints(params.referralCode, userId, params.companyId, users.dataValues.lPoints)



        var referralCode = "USERDELC" + userId.substring(1, 7).toUpperCase()


        const updateDevicetoken = await USER.update({
            sessionToken: authToken,
            platform: params.deviceToken,
            deviceToken: params.deviceToken,
            refreshToken: refreshToken,
            referralCode: referralCode

        }, {
            where: {
                id: users.dataValues.id
            }
        });

        const userData = await USER.findOne({
            where: {
                id: users.dataValues.id,

            }
        })

        var btype = await commonMethods.getBusinessType(users.dataValues.companyId)
        if (btype && btype.dataValues && btype.dataValues.type) userData.dataValues.btype = btype.dataValues.type
        else userData.dataValues.btype = 0
        if (userData) {
            userData.dataValues.isFirst = isNew

            userData.dataValues.parentCompany = userData.dataValues.companyId
            userData.dataValues.companyRole = 3


            var welcomeMsg = `Hi *${users.dataValues.fullName}*,Thanks for signing up to keep in touch with *${config.APP_NAME}*  from now on , you will get regular updates and special offers.Here's to the start of a healthy digital relationship, Cheers!!
      More Details: ` + config.WEBSITE_LINK
            commonNotification.sendWhatsapp(welcomeMsg, userData.dataValues.countryCode + userData.dataValues.phoneNumber, "register")




            return responseHelper.post(res, 'User Detail', userData);
        } else return responseHelper.post(res, 'Something Error', null, 400);

    }
}
app.post('/loginTrial', async(req, res, next) => {
    const params = req.body;

    let responseNull = commonMethods.checkParameterMissing([params.phoneNumber, params.countryCode])
    if (responseNull) return responseHelper.post(res, appstrings.required_field, null, 400);
    var countryCode = params.countryCode.replace("+", "")

    try {

        var code = params.code ? params.code : "ADMGHI"
        const codeData = await COMPANY.findOne({ where: { code: code } });

        if (codeData) {



            const userData = await USER.findOne({
                where: {
                    phoneNumber: params.phoneNumber,
                    countryCode: countryCode,
                    companyId: codeData.dataValues.id

                }
            })

            if (userData) {
                let obj = countries.find(o => o.dialCode === countryCode);

                var currency = "Rs"
                var currencyName = "INR"

                if (obj) {
                    var currencyData = cc.getAllInfoByISO(obj.iso2)


                    currency = currencyData.symbol
                    currencyName = currencyData.currency
                }




                let token = jwt.sign({
                        phoneNumber: params.phoneNumber,
                        myCompanyId: userData.dataValues.companyId,
                        countryCode: countryCode,
                        userType: 1,
                        currency: currency,
                        currencyName: currencyName,
                        parentCompany: userData.dataValues.companyId,
                        id: userData.dataValues.id,
                        exp: Math.floor(Date.now() / 1000) + 8640000*2,

                    },
                    config.jwtToken, { algorithm: 'HS256' }
                );


                const updatedResponse = await USER.update({
                    sessionToken: token,
                    platform: params.platform,
                    currency: currency,
                    currencyName: currencyName,
                    deviceToken: params.deviceToken,
                }, {
                    where: {
                        id: userData.dataValues.id
                    }
                });



                if (updatedResponse) {
                    // if (params.referralCode && params.referralCode != "")
                    // setReferralPoints(params.referralCode, userData.dataValues.id,  userData.dataValues.companyId, userData.dataValues.lPoints)

                    userData.dataValues.sessionToken = token
                    userData.dataValues.parentCompany = userData.dataValues.companyId
                    userData.dataValues.platform = params.platform
                    userData.dataValues.deviceToken = params.deviceToken
                    userData.dataValues.isFirst = false
                    userData.dataValues.companyRole = codeData.dataValues.role


                    var btype = await commonMethods.getBusinessType(userData.dataValues.id)
                    if (btype && btype.dataValues && btype.dataValues.type) userData.dataValues.btype = btype.dataValues.type
                    else userData.dataValues.btype = 0

                    return responseHelper.post(res, 'Login Successfully', userData);
                }
            } else {


                newUser(params, req, res, true, countryCode, codeData.dataValues.id)

            }
        } else return responseHelper.post(res, appstrings.code_invalid, null, 400);




    } catch (e) {
        console.log(e)
        return responseHelper.error(res, e.message, 400);
    }

})

app.post('/guestUser', async(req, res, next) => {
    const params = req.body;

    let responseNull = commonMethods.checkParameterMissing([params.deviceId])
    if (responseNull) return responseHelper.post(res, appstrings.required_field, null, 400);

    try {




        const userData = await USER.findOne({
            where: {
                deviceUniqueId: params.deviceId,
                loginType: "guest"
            }
        })

        if (userData) {


            let token = jwt.sign({
                    phoneNumber: params.phoneNumber,
                    myCompanyId: userData.dataValues.companyId,
                    countryCode: params.countryCode,
                    userType: 1,
                    currency: userData.dataValues.currency,
                    parentCompany: userData.dataValues.companyId,
                    id: userData.dataValues.id,
                    exp: Math.floor(Date.now() / 1000) + 8640000*2,

                },
                config.jwtToken, { algorithm: 'HS256' }
            );


            const updatedResponse = await USER.update({
                sessionToken: token,
                platform: params.platform,
                currency: "Rs",
                currencyName: "INR",
                deviceToken: params.deviceToken,
            }, {
                where: {
                    id: userData.dataValues.id
                }
            });



            if (updatedResponse) {
                // if (params.referralCode && params.referralCode != "")
                // setReferralPoints(params.referralCode, userData.dataValues.id,  userData.dataValues.companyId, userData.dataValues.lPoints)

                userData.dataValues.sessionToken = token
                userData.dataValues.parentCompany = userData.dataValues.companyId
                userData.dataValues.platform = params.platform
                userData.dataValues.deviceToken = params.deviceToken
                userData.dataValues.isFirst = false
                var btype = await commonMethods.getBusinessType(userData.dataValues.id)
                if (btype && btype.dataValues && btype.dataValues.type) userData.dataValues.btype = btype.dataValues.type
                else userData.dataValues.btype = 0

                return responseHelper.post(res, 'Login Successfully', userData);
            }
        } else {



            const users = await USER.create({
                firstName: "Guest",
                fullName: "User",
                phoneNumber: "",
                countryCode: "",
                deviceToken: params.deviceToken,
                platform: params.platform,
                currency: "Rs",
                currencyName: "INR",
                companyId: config.PARENT_COMPANY,
                loginType: "guest",
                deviceUniqueId: params.deviceId ? params.deviceId : "",
                code: config.STATIC_ADMIN_CODE
            });


            if (users) {
                const userId = users.dataValues.id;
                params.userId = userId;


                const credentials = {
                    phoneNumber: users.dataValues.phoneNumber,
                    myCompanyId: users.dataValues.companyId,
                    parentCompany: users.dataValues.companyId,
                    countryCode: users.dataValues.countryCode,
                    currency: users.dataValues.currency,
                    userType: 1,
                    id: userId,
                    exp: Math.floor(Date.now() / 1000) + 8640000*2,
                };



                const authToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });
                const refreshToken = jwt.sign(credentials, config.jwtToken, { algorithm: 'HS256' });

                // if (params.referralCode && params.referralCode != "") 
                // setReferralPoints(params.referralCode, userId, params.companyId, users.dataValues.lPoints)



                var referralCode = "USERDELC" + userId.substring(1, 7).toUpperCase()


                const updateDevicetoken = await USER.update({
                    sessionToken: authToken,
                    platform: params.deviceToken,
                    deviceToken: params.deviceToken,
                    refreshToken: refreshToken,
                    referralCode: referralCode

                }, {
                    where: {
                        id: users.dataValues.id
                    }
                });

                const userData = await USER.findOne({
                    where: {
                        id: users.dataValues.id,

                    }
                })

                var btype = await commonMethods.getBusinessType(users.dataValues.companyId)
                if (btype && btype.dataValues && btype.dataValues.type) userData.dataValues.btype = btype.dataValues.type
                else userData.dataValues.btype = 0
                if (userData) {
                    userData.dataValues.isFirst = true

                    userData.dataValues.parentCompany = userData.dataValues.companyId

                    return responseHelper.post(res, 'User Detail', userData);
                }
            } else return responseHelper.post(res, 'Something Error', null, 400);


        }





    } catch (e) {
        console.log(e)
        return responseHelper.error(res, e.message, 400);
    }

})







app.post('/useReferral', checkAuth, async(req, res, next) => {
    const params = req.body;

    var userId = req.id
    let responseNull = commonMethods.checkParameterMissing([params.referralCode, params.companyId])
    if (responseNull) return responseHelper.post(res, appstrings.required_field, null, 400);




    try {
        const userData = await USER.findOne({
            where: {
                referralCode: params.referralCode,

            }
        });

        const myData = await USER.findOne({
            where: {
                id: userId,

            }
        });


        if (userData) {


            const referData = await DOCUMENT.findOne({
                attributes: ['id', 'lpReferral1', 'lpReferral2'],
                where: {
                    companyId: params.companyId,

                }
            });
            var points = 50
            var points1 = 25

            if (referData && referData.dataValues && referData.dataValues.lpReferral1)
                points = referData.dataValues.lpReferral1

            if (referData && referData.dataValues && referData.dataValues.lpReferral2)
                points1 = referData.dataValues.lpReferral2


            if (userData && userData.dataValues != "") {

                var newPoints = parseInt(userData.dataValues.lPoints) + parseInt(points)
                var newPoints1 = parseInt(myData.dataValues.lPoints) + parseInt(points1)

                USER.update({ lPoints: newPoints1 }, { where: { id: userId } })
                USER.update({ lPoints: newPoints }, { where: { id: userData.dataValues.id } })



                var name1 = (myData.dataValues && myData.dataValues.fullName && myData.dataValues.fullName != "") ? ":" + myData.dataValues.fullName : ""
                var name2 = (userData.dataValues && userData.dataValues.fullName != "") ? userData.dataValues.fullName : "your friend"

                if (parseInt(points1) > 0) {
                    LPHISTORY.create({
                            userId: userId,
                            payType: 1,
                            orderId: "",
                            points: points1,
                            purpose: "Referred Point",
                            createdAt: new Date(),

                            description: "Points added to your account by using " + name2 + "'s referral code ",

                            referredId: userData.dataValues.id
                        }) //Credited


                    var notifPushUserData1 = {
                        title: "Congratulations " + points1 + " points added to your account",
                        description: "Congratulations " + points1 + " points added to your account by using referral code",
                        token: myData.dataValues.deviceToken,
                        platform: myData.dataValues.platform,
                        userId: myData.dataValues.id,
                        role: 3,
                        notificationType: "REFERRAL_REWARD",
                        status: 1,
                    }
                    commonNotification.insertNotification(notifPushUserData1)
                    commonNotification.sendNotification(notifPushUserData1)


                }
                if (parseInt(points) > 0) {
                    LPHISTORY.create({
                            userId: userData.dataValues.id,
                            payType: 1,
                            orderId: "",
                            points: points,
                            createdAt: new Date(),

                            description: "Points added to your account as your friend " + name1 + " used your referral code ",

                            purpose: "Referral Point",
                            referredId: userId
                        }) //Credited


                    var notifPushUserData = {
                        title: "Congratulations " + points + " points added to your account",
                        description: "Congratulations " + points + " points added to your account. Your friend " + myData.dataValues.firstName + " has used your referral code",
                        token: userData.dataValues.deviceToken,
                        platform: userData.dataValues.platform,
                        userId: userData.dataValues.id,
                        role: 3,
                        notificationType: "REFERRAL_REWARD",
                        status: 1,
                    }

                    commonNotification.insertNotification(notifPushUserData)
                    commonNotification.sendNotification(notifPushUserData)

                }

                return responseHelper.post(res, appstrings.success, null, 200);


            }


        } else

            return responseHelper.post(res, appstrings.invalid_referral, null, 400);







    } catch (e) {
        return responseHelper.error(res, e.message, 400);
    }

})

async function setReferralPoints(referralCode, userId, parentCompany, myLPoints) {
    try {
        const userData = await USER.findOne({
            where: {
                referralCode: referralCode,

            }
        });

        const myData = await USER.findOne({
            where: {
                id: userId,

            }
        });


        if (userData) {


            const referData = await DOCUMENT.findOne({
                attributes: ['id', 'lpReferral1', 'lpReferral2'],
                where: {
                    companyId: parentCompany,

                }
            });
            var points = 50
            var points1 = 25

            if (referData && referData.dataValues && referData.dataValues.lpReferral1)
                points = referData.dataValues.lpReferral1

            if (referData && referData.dataValues && referData.dataValues.lpReferral2)
                points1 = referData.dataValues.lpReferral2


            if (userData && userData.dataValues != "") {

                var newPoints = parseInt(userData.dataValues.lPoints) + parseInt(points)
                var newPoints1 = parseInt(myLPoints) + parseInt(points1)

                USER.update({ lPoints: newPoints1 }, { where: { id: userId } })


                USER.update({ lPoints: newPoints }, { where: { id: userData.dataValues.id } })





                var notifPushUserData = {
                        title: "Congratulations " + points + " points added to your account",
                        description: "Congratulations " + points + " points added to your account. Your friend " + myData.dataValues.firstName + " has used your referral code",
                        token: userData.dataValues.deviceToken,
                        platform: userData.dataValues.platform,
                        userId: userData.dataValues.id,
                        role: 3,
                        notificationType: "REFERRAL_REWARD",
                        status: 1,
                    }
                    // referral bonus
                LPHISTORY.create({
                        userId: userData.dataValues.id,
                        createdAt: new Date(),

                        referredId: myData.dataValues.id,
                        payType: 1,
                        orderId: "",
                        points: points,
                        purpose: "Reffered Point"
                    }) //Debited




                var notifPushUserData1 = {
                        title: "Congratulations " + points1 + " points added to your account",
                        description: "Congratulations " + points1 + " points added to your account by using referral code",
                        token: myData.dataValues.deviceToken,
                        platform: myData.dataValues.platform,
                        userId: myData.dataValues.id,
                        role: 3,
                        notificationType: "REFERRAL_REWARD",
                        status: 1,
                    }
                    // registration reward
                LPHISTORY.create({ userId: myData.dataValues.id, payType: 1, orderId: "", points: points1, purpose: "Refferral Point", createdAt: new Date() }) //Debited





                commonNotification.insertNotification(notifPushUserData)
                commonNotification.sendNotification(notifPushUserData)

                commonNotification.insertNotification(notifPushUserData1)
                commonNotification.sendNotification(notifPushUserData1)



            }
        }

    } catch (e) {
        console.log(e)
    }



}
app.post('/createephemeralKeys', checkAuth, async(req, res, next) => {

    const params = req.body;
    var email = randomEmail({ domain: 'yopmail.com' });

    let responseNull = commonMethods.checkParameterMissing([params.apiVersion])
    if (responseNull) return responseHelper.post(res, appstrings.required_field, null, 400);



    stripe = Stripe(req.secretKey);
    try {
        var ChckEmail = await USER.findOne({
            where: {
                id: req.id
            },
            include: [{ model: ADDRESS, as: 'useraddress' }]
        })
        if (ChckEmail) {
            ChckEmail = JSON.parse(JSON.stringify(ChckEmail))



            if (ChckEmail.stripeCustomerId == "" || ChckEmail.prevSecretKey != req.secretKey) {


                stripe.customers.create({
                    name: !(/^\s*$/.test(ChckEmail.fullName)) ? ChckEmail.fullName : "New Customer",
                    email: (ChckEmail.email && ChckEmail.email != "") ? ChckEmail.email : email,
                    address: {
                        line1: 'line1',
                        postal_code: '98140',
                        city: 'city',
                        state: 'CA',
                        country: 'US',
                    },
                    description: '<%-config.APP_NAME%> Customer with email ' + ChckEmail.email,
                    phone: ChckEmail.phoneNumber

                }, async function(err, customer) {



                    if (typeof customer !== 'undefined' && customer) {


                        var response = await USER.update({
                            stripeCustomerId: customer.id,
                            prevSecretKey: req.secretKey
                        }, {
                            where: {
                                id: req.id
                            }
                        });

                        var key = await stripe.ephemeralKeys.create({ customer: customer.id }, { apiVersion: params.apiVersion });
                        // return responseHelper.post(res, appstrings.success, key,200);

                        return res.json(key);
                    } else {
                        return res.json({ code: 400, message: err });
                    }
                });
            } else {

                var key = await stripe.ephemeralKeys.create({ customer: ChckEmail.stripeCustomerId }, { apiVersion: params.apiVersion });
                // return responseHelper.post(res, appstrings.success, key,200);

                return res.json(key);

            }


        } else {
            return responseHelper.unauthorized(res, "");
        }

    } catch (e) {
        return responseHelper.error(res, e.message, 400);
    }

});


module.exports = app;



//Edit User Profile