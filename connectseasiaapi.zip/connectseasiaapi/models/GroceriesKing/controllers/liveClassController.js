const config = require("config");
const model = require("../models/index");
const helpers = require("../helpers");
const common = require('../helpers/common');
const { Op } = require("sequelize");
const handleError = helpers.handleError;


module.exports = {

    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////// start class by teacher  ///////////////////////////
    //////////////////////////////////////////////////////////////////////////////// 
    start: async function (req, res) {
        try {
            const validations = {
                classId: "required",
                subjectId: "required",
                topicId: "required",
                userId: "required",
                sectionId:"required"
            };
            const formData = req.body;
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }
            // const cls = await liveClass.create({
            //     where: {
            //         classId: formData.classId,
            //         subjectId: formData.subjectId,
            //         topicId: formData.topicId,
            //         teacherId: formData.userId,
            //         sectionId:formData.sectionId
            //     }, defaults: {
            //         classId: formData.classId,
            //         subjectId: formData.subjectId,
            //         topicId: formData.topicId,
            //         teacherId: formData.userId,
            //         sectionId:formData.sectionId
            //     }
            // })
            const cls = await liveClass.create({
               
                    classId: formData.classId,
                    subjectId: formData.subjectId,
                    topicId: formData.topicId,
                    teacherId: formData.userId,
                    sectionId:formData.sectionId
                }
            )
            if (cls) {
   
                // const update = await liveClass.update(
                //     {
                //         status: 1
                //     },
                //     {
                //         returning: true,
                //         where:
                //             { id: cls[0].dataValues.id }
                //     }
                // )
                return helpers.jsonResponse(res,true,cls,"Success",200,200);
            }
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    //////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////// stop class by teacher  ///////////////////////////
    //////////////////////////////////////////////////////////////////////////////// 

    stop: async function (req, res) {
        try {

            const cls = await liveClass.update(
                {
                    status: req.body.status
                },
                {
                    returning: true,
                    where:
                        { id: req.params.streamId }
                }
            )
            if (cls) {
                return helpers.jsonResponse(res,true,{},"Success",200,200);
            }
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////// update thumb of class  ///////////////////////////
    //////////////////////////////////////////////////////////////////////////////// 

    updateThumb: async function (req, res) {
        try {
            const thumb = req.body.thumb.replace(/^data:image\/png;base64,/, "");
            const thumbName = `${common.timestamp()}.png`;
            require("fs").writeFile(`${ config.streamThumb}${thumbName}`, thumb, 'base64', async function (err) {
                const cls = await liveClass.update(
                    {
                        thumb: `${ config.streamDbPath}${thumbName}`
                    },
                    {
                        returning: true,
                        where:
                        {
                            id: req.params.streamId
                        }
                    }
                )
                if (cls) {
                    return helpers.jsonResponse(res, true, {}, "Success", 200, 200);
                }
            }) 
              }catch (e) {
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
      
    },

    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// get classes which are live now  ///////////////////////
    //////////////////////////////////////////////////////////////////////////////// 

    list: async function (req, res) {
        try {
            const cls = await liveClass.findAll({
                attributes: ['id', 'thumb'],
                where: {
                    status: 1,                    /// only live
                },
                include: [{
                    attributes: ['fName', 'lName'],
                    model: userDetail
                }, {
                    attributes: ['name'],
                    model: subject
                }, {
                    attributes: ['name'],
                    model: topics
                }]
            });
            if (cls) {
                return helpers.jsonResponse(res,true,cls,"List",200,200);
            }
        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// get Recording  ///////////////////////
    //////////////////////////////////////////////////////////////////////////////// 

    listRecording: async function (req, res) { 
        try {
            const student = await stdntInfo.findOne({
                attributes: ['id','classId','sectionId'],
                where: {
                    studentId: req.params.studentId        
                }
            });
            if(student)
            {
                let classId   = student.dataValues.classId;
                let sectionId = student.dataValues.sectionId;
                const cls = await liveClass.findAll({
                    attributes: ['id','classId','sectionId','recording'],
                    where: {
                        classId: classId,
                        sectionId: sectionId,
                        recording: {
                            [Op.ne]: ""
                        }
                    },
                    include: [{
                        attributes: ['fName', 'lName'],
                        model: userDetail
                    }, {
                        attributes: ['name'],
                        model: subject
                    }, {
                        attributes: ['name'],
                        model: topics
                    }]
                });
                if (cls) {
                    return helpers.jsonResponse(res,true,cls,"List",200,200);
                }
            }else{
                return helpers.jsonResponse(res, false, {},"Student Does not exist", 400, 400);
            }
            
        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////
    //////// Save Recording /////////////////////////
    /////////////////////////////////////////////////
    saveRecording : async function(req, res) {   
        const timestamp = Math.round(new Date().getTime()/1000);
     
        var ImageFile1  = req.files.file;
        ImageFile1.mv('public/recordings/'+timestamp + '.webm', async function (err) {
            if (err)
                console.log(err);
            else {
                const cls = await liveClass.update(
                    {
                        recording: `recordings/${timestamp}.webm`
                    },
                    {
                        returning: true,
                        where:
                        {
                            id: req.body.streamId
                        }
                    }
                )
            }
        });
   
        return helpers.jsonResponse(res, true, {}, "Success", 200, 200);
    },
};
