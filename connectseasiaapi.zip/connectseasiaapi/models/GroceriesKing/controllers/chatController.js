const model = require("../models/index");
const sequelize = model.sequelize;
const helpers = require("../helpers");
const chat = model.chats,
      handleError = helpers.handleError;

module.exports = {


//////////////////////////////////////////////////////////////////////////////////
///////////////////////// get chat based on the roomid   /////////////////////
//////////////////////////////////////////////////////////////////////////////// 
    
get: async function(req, res) {
    try {
        const chatList = await chat.findAll({
            attributes: ['senderId', 'roomId','type','message','thumb'],
            where: {
                roomId: req.params.roomId,                 
            },
            include: [{
                attributes: ['fName', 'lName'],
                model: userDetail
            }],
            order: [
                ['createdAt', 'ASC']
            ]
        });
        if (chatList) {
            return helpers.jsonResponse(res,true,chatList,"List", 200, 200);
        }

    } catch (e) {
        return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
    },

   
};
