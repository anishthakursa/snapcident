const model = require("../models/index");
const helpers = require("../helpers");
const { createToken } = require("../middleware");
const handleError = helpers.handleError;
const nodemailer = require('nodemailer');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const common              = require('../helpers/common');
const moment   = require('moment');

const transporter = nodemailer.createTransport({
  service: config.SMTPSER,
  auth: {
    user: config.SENDMAIL,
    pass: config.SENDPWD,
  }
});
module.exports = {

	/*************** Logout User *****************/
	getColourCode: async (req, res, next) => {
	    try
	    {
			const obj = {
				colorCode: "#373E80",
                colorCode2: "#E3AC51"
			};
	      	return helpers.jsonResponse(
				res,
				true,
				obj,
				appstrings.success,
				200,
				200
			);
	      	
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},











	/*************** Logout User *****************/
	logout: async (req, res, next) => {
	    const params = req.body;
	    try
	    {
			
	      	const updatedResponse = await userDetail.update({
				  userToken:"",
				  deviceToken: "",
				  authToken:""
	        },
	        {
	          	where : {
	            	userId:params.userId
	        	}
			  });
		     // destroy the old token
	      	return helpers.jsonResponse(
						res,
						true,
						{},
						"Logout Successfully",
						200,
						200
					);
	      	
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},
	loginTrial: async function(req, res) {
		try {
			const validations = {
				email: "required|email",
				password: "required",
				code: "required"
			};
			const matched = await helpers.validate(req.body, validations);
			if (!matched.status) {
				if(matched.data.email && matched.data.email.rule == 'email') {
				throw new handleError("must be email", 422);
				}
				throw new handleError("email_password_validation", 400);
			}

			
			const codeData = await COMPANY.findOne({ where: {code: req.body.code}});


			console.log(">>>>>>>>>>>",codeData)
			if(codeData)
			{
	

			// Verify User
			let verifyUser = await user.findOne({
				attributes: ['id','email','password','role'],
				where: {
					email: req.body.email,
					
				},
				include: [{
					model: userDetail,
					required:true,
					attributes:['fName','lName','status','image','referralCode','status']
				}]
			});


			if (verifyUser) {





				

				if(parseInt(verifyUser.dataValues.userDetail.dataValues.status)==0){
					return helpers.jsonResponse(res, false, {}, "Your account is inactive please wait for admin approval.", 402, 400);
				}	

				let comparePass = await helpers.comparePassword(
					req.body.password,
					verifyUser.dataValues.password
				);
				//let comparePass = true
				if (comparePass) {

						const  isUserLoggedIn = await userDetail.findOne({
							where:{ userToken:{ [Op.ne]: '' },
							userId:verifyUser.dataValues.id
						}
						});
			
					
					// Create JWT Token
					const token = await createToken(verifyUser.dataValues);
					if(verifyUser.dataValues.userDetail.dataValues.image != "")
					{
						var imageurl = config.BASEURL+"images/"+verifyUser.dataValues.userDetail.dataValues.image;
					}else{
						var imageurl = "";
					}
					// Make Response
					const response = {
						userName: verifyUser.dataValues.userDetail.dataValues.fName+' '+verifyUser.dataValues.userDetail.dataValues.lName,
						image: imageurl,
						status: verifyUser.dataValues.userDetail.dataValues.status,
						userId: verifyUser.dataValues.id,
						authToken: token,
						referralCode: verifyUser.dataValues.userDetail.dataValues.referralCode,
						email:verifyUser.dataValues.email,
						type:verifyUser.dataValues.role,
						colorCode: "#373E80",
						companyId:codeData.dataValues.id
					};
				
					return helpers.jsonResponse(
						res,
						true,
						response,
						appstrings.login_success,
						200,
						200
					);
				} else {
					return helpers.jsonResponse(
						res,
						true,
						{},
						appstrings.invalid_password,
						402,
						402
					);
				}
			} else {
				return helpers.jsonResponse(
					res,
					true,
					{},
					appstrings.invalid_email,
					402,
					402
				);
			}
		
		
		
		
		} 
	
		else return responseHelper.post(res, appstrings.code_invalid, null, 400);

	}
		catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},
	login: async function(req, res) {
		try {
			const validations = {
				email: "required|email",
				password: "required"
			};
			const matched = await helpers.validate(req.body, validations);
			if (!matched.status) {
				if(matched.data.email && matched.data.email.rule == 'email') {
				throw new handleError("must be email", 422);
				}
				throw new handleError("email_password_validation", 400);
			}

			// Verify User
			let verifyUser = await user.findOne({
				attributes: ['id','email','password','role'],
				where: {
					email: req.body.email,
					
				},
				include: [{
					model: userDetail,
					required:true,
					attributes:['fName','lName','status','image','referralCode','status']
				}]
			});


			if (verifyUser) {

				if(parseInt(verifyUser.dataValues.userDetail.dataValues.status)==0){
					return helpers.jsonResponse(res, false, {}, "Your account is inactive please wait for admin approval.", 402, 400);
				}	

				let comparePass = await helpers.comparePassword(
					req.body.password,
					verifyUser.dataValues.password
				);
				//let comparePass = true
				if (comparePass) {

						const  isUserLoggedIn = await userDetail.findOne({
							where:{ userToken:{ [Op.ne]: '' },
							userId:verifyUser.dataValues.id
						}
						});
			
					
					// Create JWT Token
					const token = await createToken(verifyUser.dataValues);
					if(verifyUser.dataValues.userDetail.dataValues.image != "")
					{
						var imageurl = config.BASEURL+"images/"+verifyUser.dataValues.userDetail.dataValues.image;
					}else{
						var imageurl = "";
					}
					// Make Response
					const response = {
						userName: verifyUser.dataValues.userDetail.dataValues.fName+' '+verifyUser.dataValues.userDetail.dataValues.lName,
						image: imageurl,
						status: verifyUser.dataValues.userDetail.dataValues.status,
						userId: verifyUser.dataValues.id,
						authToken: token,
						referralCode: verifyUser.dataValues.userDetail.dataValues.referralCode,
						email:verifyUser.dataValues.email,
						type:verifyUser.dataValues.role,
						colorCode: "#373E80"
					};
				
					return helpers.jsonResponse(
						res,
						true,
						response,
						appstrings.login_success,
						200,
						200
					);
				} else {
					return helpers.jsonResponse(
						res,
						true,
						{},
						appstrings.invalid_password,
						402,
						402
					);
				}
			} else {
				return helpers.jsonResponse(
					res,
					true,
					{},
					appstrings.invalid_email,
					402,
					402
				);
			}
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
		}
	},








	test: async function (req,res){
		try
	    {
	      	const cls = []
	      	return helpers.jsonResponse(res, true, cls, "Success", 200, 200);
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},
	
	updateprofile: async function(req, res) {
		try {
			let userId = req.id

            const validations = {
               // companyId: "required",
                fName:"required",
                lName:"required",
                dob:"required",
                phoneNo: "required",
                email:"required|email",
			};
           
			let matched = await helpers.validate(req.body, validations);
			if (!matched.status) {
            
         
                // if (matched.data.companyId) {
                //     throw new handleError(appstrings.company_required, 422);
                // }
                if (matched.data.fName) {
                    throw new handleError(appstrings.fName_required, 422);
                }
                if (matched.data.lName) {
                    throw new handleError(appstrings.lName_required, 422);
                }
				if (matched.data.dob) {
                    throw new handleError(appstrings.dob_required, 422);
                }
                if (matched.data.email) {
                    throw new handleError(appstrings.email_required, 422);
                }
                
                if (matched.data.phoneNo) {
                    throw new handleError(appstrings.phone_required, 422);
                }

                let ifemailtaken = await user.findOne({
                    where: {
                        email: req.body.email,
						id:{[Op.ne]:req.id},
						role:req.role
                    }
                });

                if (ifemailtaken) {
                    throw new handleError(appstrings.email_exists, 422);
                }
            }
            
            const formdata = req.body;
            let verifyUser = await user.findOne({
                where: {
                    id: req.id,
                }
            });
            if(verifyUser){

                var icon = "";
                if (req.files) {
                    ImageFile = req.files.image; 
                    if(ImageFile)
                    {
                      icon = Date.now() + '_' + ImageFile.name.replace(/\s/g, "");
                   
                      ImageFile.mv(config.UPLOAD_DIRECTORY +"images/"+ icon, function (err) {
                          //upload file
                          if (err)
                          return helpers.jsonResponse(res, false, {}, err.message, 400);
                          
                      });
                    }
                }

                    // update email
                let udpatedemail = await userDetail.update({ email :formdata.email},{where:{
                        id:userId
                    }
                })


                if(icon == "")
                {
                    var updateuserDetail = await userDetail.update({
                    fName: formdata.fName,
                    lName: formdata.lName,
		            dob : moment(formdata.dob,"YYYY-MM-DD").add(0, 'day').format('YYYY-MM-DD'),
                    info: formdata.info,
                    grade: formdata.grade,
                    needed: formdata.needed, 
                    help: formdata.help,
                    superhero: formdata.superhero,
					summery: formdata.summery,
					languages:formdata.languages,
                    phoneNo: formdata.phoneNo,
                    hours: formdata.hours,
                    superPower: formdata.superPower,
                    address: formdata.address,
                    education: formdata.education,
                    age:formdata.age
                },
                {
                    where : {
                        userId: userId
                    }
                });
                }else{
                    var updateuserDetail = await userDetail.update({
                    fName: formdata.fName,
                    lName: formdata.lName,
		    dob : moment(formdata.dob,"YYYY-MM-DD").add(0, 'day').format('YYYY-MM-DD'),
                    info: formdata.info,
                    grade: formdata.grade,
                    needed: formdata.needed, 
                    help: formdata.help,
                    superhero: formdata.superhero,
					summery: formdata.summery,
					languages:formdata.languages,
					age:formdata.age,
                    phoneNo: formdata.phoneNo,
                    hours: formdata.hours,
                    superPower: formdata.superPower,
                    address: formdata.address,
                    image: icon,
                    education: formdata.education
                },
                {
                    where : {
                        userId: userId
                    }
                });
                }

                const userBankDet = await bankDetail.update({
                    bankName: formdata.bankName,
                    userName: formdata.userName,
                    ifcCode: formdata.ifcCode,
                    accountNumber: formdata.accountNumber,
                }, { 
                	where: {
                		userId: userId
                	}
                });
                
                //Update Teacher Subject
                await teacherSubject.update({
                    subjectId: formdata.subjects,
                    subCategoryId: formdata.grade
                }, { 
                	where: {
                		teacherId: userId
                	}
                })

                const userDetails  = await userDetail.findOne({
                   where: {
                     userId : userId
                   }
                 })
                return helpers.jsonResponse(
                    res,
                    true,
                    userDetails,
                    appstrings.profile_update_success,
                    200,
                    200
                );
            }else{
                return helpers.jsonResponse(res, false, {}, appstrings.user_not_exists,'', 206);
            } 
		}
		catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
		}
	},


	getFaqs: async (req, res, next) => {
		try{
		  var params=req.query
		  var page =1
		  var limit =50
		  var filterCat=""
		  var type=[1,2]

		  var where={companyId :req.parentCompany}
		  if(params.page) page=params.page
		  if(params.category) filterCat=params.category
		  if(params.limit) limit=parseInt(params.limit)
		  if(params.type) type=[params.type]

		  var offset=(page-1)*limit
		 
	
		  if(filterCat!="")
		 where.faqCategory=filterCat

		 where.type=type

		  //Get All Categories
		  var findData=await FAQ.findAll({
			attributes:['id','question','answer','status','type'],
			where :where,
			order: [
			  ['createdAt','DESC']
			],      
			offset: offset, 
			limit: limit,
	
			
		  })
		  var category=await FAQCATEGORY.findAll({attributes:['id','catName'],where:{companyId:req.parentCompany}})
	
	var dataToSend={}
	dataToSend.category=category
	dataToSend.data=findData
	
	return helpers.jsonResponse(res, true, dataToSend, "List Fetch Successfully", 200, 200);
	
	 }
	  catch (e) {
		return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	}
		  
	
	},
	updatechangepassword: async function(req, res) {
		try {
			
			const validations = {
				oldPassword: "required",
				newPassword: "required"
			};
			const formdata = req.body;
			var userId      = formdata.userId;
			var newpassword = formdata.newPassword; 
			var oldpassword = formdata.oldPassword;
			// Call Translate
			const matched = await helpers.validate(req.body, validations);
			if (!matched.status) {
				return helpers.jsonResponse(res, false, {}, "Invalid old password!",206, 206);
			}
			let verifyUser = await user.findOne({
				where: {
					id: req.id,
				}
			});
			if(verifyUser){
					   let compare = await helpers.comparePassword(oldpassword,verifyUser.dataValues.password);
					   if(compare == false)
						  {
							return helpers.jsonResponse(res, false, {}, "Invalid old password!",206, 206);
						  }
				
					   var password = await helpers.cryptPassword(newpassword);
					   const updatePassword = await user.update({
							password : password,
						  },
						  {
							where : {
							id: req.id
						  }
						  });
						return helpers.jsonResponse(
								res,
								true,
								{},
								"password update successfully",
								200,
								200
							);
			}else{
				return helpers.jsonResponse(res, false, {}, "User does not exist",206, 206);
				
			}
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
		}
	},
	forgotPassword: async function(req, res) {
		try {
			const validations = {
				email: "required",
			};
			const formdata = req.body;
			var email      = formdata.email;
			// Call Translate
			const matched = await helpers.validate(req.body, validations);
			if (!matched.status) {
				if(matched.data.email && matched.data.email.rule == 'email') {
				throw new handleError("must be email", 422);
				}

				throw new handleError("email_validation", 206);
			}
			let verifyUser = await user.findOne({
				where: {
					email: formdata.email,
				}
			});
			if(verifyUser){
			    var text = "";
				var char_list = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
				for(var i=0; i < 6; i++ )
				{
				  text += char_list.charAt(Math.floor(Math.random() * char_list.length));
				}
				var password = await helpers.cryptPassword(text);
				const updatePassword = await user.update({
					password : password,
				  },
				  {
					where : {
					
					email: formdata.email,
				  }
				  });
			    var htmldata =
				  '<p>You have requested to change your password.Please use the below password.</p>' +
				  '<p><b>New Passoword :</b> ' +
				  text +
				  '</p>'+
				  '<p>Thanks & Regards</p>'+
				  '<p>Online Team</p>';
			    var subject = "Passoword Reset - cereconsult";
                const companyId = config.STATIC_COMPANYID;
                common.sendMail(formdata.email,htmldata,companyId,subject);
                
				return helpers.jsonResponse(
					res,
					true,
					{},
					appstrings.password_reset_success,
					200,
					200
				);
			}else{
				return helpers.jsonResponse(res, false, {}, "User does not exist",'', 206);
				
			}
		} catch (e) {
			return helpers.jsonResponse(res, false, {}, e.message, e.code, 200);
		}
	},

	//////////////////////////////////////////////////
    //////// Save Recording /////////////////////////
    /////////////////////////////////////////////////
    saveImage : async function(req, res) {   
        const timestamp = Math.round(new Date().getTime()/1000);
     
        var ImageFile1  = req.files.file;
        ImageFile1.mv('public/images/'+timestamp + '.jpg', async function (err) {
            if (err)
                console.log(err);
            else {
                const cls = await privateClass.update(
                    {
                        recording: `images/${timestamp}.jpg`
                    },
                    {
                        returning: true,
                        where:
                        {
                            id: req.body.streamId
                        }
                    }
                )
            }
        });
   
        return helpers.jsonResponse(res, true, {}, "Success", 200, 200);
    },

    /////////////////////////////////////////////////
    //////// Update Device Token ////////////////////
    /////////////////////////////////////////////////
    updateDeviceToken : async function(req, res) {   
        try{
		
        	const formData  = req.body;
        	const validations = {
                deviceToken: "required",
               
            };
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }
            //Update Device Token
            await userDetail.update(
                {
                    deviceToken: formData.deviceToken
                },
                {
                    where:
                    {
                        userId: req.id
                    }
                }
            )
            return helpers.jsonResponse(res, true, {}, "Success", 200, 200);
        }catch (e){
        	console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /////////////////////////////////////////////////
    //////// getSubCategory ////////////////////
    /////////////////////////////////////////////////
    getSubCategory : async function(req, res) {   
        try{
		

        	const formData  = req.body;
        	const validations = {
                categoryId: "required",
            };
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }
            //Update Device Token
            const cls = await SubCategory.findAll({
                attributes: ['id', 'name','image'],
                where: {
                    status: 1,
					isDeleted:0,
                    subjectId: formData.categoryId
                }
            });
            return helpers.jsonResponse(res, true, cls, "Success", 200, 200);
        }catch (e){
        	console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    /*************** Setting User *****************/
	settingAPI: async (req, res, next) => {
	    try
	    {
	      	const cls = await Setting.findOne({
	      		where: {
	      			companyId: req.parentCompany ? req.parentCompany :config.STATIC_COMPANYID
	      		}
	      	});


	      	//Get Professional Setting
	      	const pro  = await scheduleSetting.findOne({
		      	where: {
		        	professionalId: req.id,
		      	}
		    }); 
		    if(pro)
		    {
		    	cls.dataValues.professionalSetting = pro;
		    	if(cls)
		      	{
		      		var array  = [];
		      		var time   = cls.dataValues.timeslots;
		      		let result = time.replace('[', '');
		      		result     = result.replace(']', '');
   					result     = result.toString();
		      		time       = result.split(',');
		      		let selectTime = pro.dataValues.slotTime;
		      		for(var i = 0; i < time.length; i++)
		      		{
		      			let times = time[i];
		      			let object = {};
		      			if(selectTime == times)
		      			{
		      				object.slot = times;
		      				object.status = '1';
		      			}else{
		      				object.slot = times;
		      				object.status = '0';
		      			}
		      			array.push(object);
				    }
				    cls.dataValues.timeInterval = array;
		      	}
		    }else{
		    	cls.dataValues.professionalSetting = {};
		    	var array  = [];
	      		var time   = cls.dataValues.timeslots;
	      		let result = time.replace('[', '');
	      		result     = result.replace(']', '');
				result     = result.toString();
	      		time       = result.split(',');
	      		for(var i = 0; i < time.length; i++)
	      		{
	      			let times = time[i];
	      			let object = {};
      				object.slot = times;
      				object.status = '0';
	      			array.push(object);
			    }
			   cls.dataValues.timeInterval = array;
		    }

		    const users = await SCHEDULE.findAll({
                where: {
                    userId : req.id
                } 
            });
            var mainArray =[];
            for (var i = 0; i < users.length; i++) {
                let name = users[i].dayParts;
                mainArray.push(name);
            }
            cls.dataValues.days = mainArray;
	      	return helpers.jsonResponse(res, true, cls, "Success", 200, 200);
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},

	/*************** Setting User *****************/
	getNotificationList: async (req, res, next) => {
	    try
	    {
            const id = req.id;
	      	const cls = await Notification.findAll({
	      		where: {
	      			reciverId: id
	      		},
	      		order: [
	                ['createdAt', 'DESC']
	            ], 
	      	});
	      	
	      	var mainArray  = [];
	        for (var i = 0; i < cls.length; i++) {
	            var theDate = new Date( cls[i].createdAt * 1000);
	            var dateString = await common.formatAMPM(theDate);
	            cls[i].dataValues.createdAt    = dateString; 
	        }

	      	return helpers.jsonResponse(res, true, cls, "List Fetch Successfully", 200, 200);
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},

	/*************** checkPhoneNumber *****************/
	checkPhoneNumber: async (req, res, next) => {
	    try
	    {
	    	const validations = {
				phoneNumber: "required"
			};

			const matched = await helpers.validate(req.body, validations);
			if (!matched.status) {
				throw new handleError("Fields Required", 400);
			}
	      	// Verify User
			let verifyUser = await userDetail.findOne({
				where: {
					phoneNo: req.body.phoneNumber,
				}
			});

			if (verifyUser) {
				return helpers.jsonResponse(
					res,
					true,
					{},
					"Phone number already exist.",
					206,
					206
				);
			}else{
				return helpers.jsonResponse(
					res,
					true,
					{},
					"Phone number available.",
					200,
					200
				);
			}
	      	
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},

	/*************** check Emauk *****************/
	checkEmail: async (req, res, next) => {
	    try
	    {
		    const validations = {
				email: "required|email"
			};

			const matched = await helpers.validate(req.body, validations);
			
			if (!matched.status) {
				if(matched.data.email && matched.data.email.rule == 'email') {
				throw new handleError("must be email", 422);
				}

				throw new handleError("email_validation", 206);
			}
	   		// Verify User
			let verifyUser = await user.findOne({
				attributes: ['id','email','password','role'],
				where: {
					email: req.body.email,
				}
			});

			if (verifyUser) {
				return helpers.jsonResponse(
					res,
					true,
					{},
					"Email address already exist.",
					206,
					206
				);
			}else{
				return helpers.jsonResponse(
					res,
					true,
					{},
					"Email address available.",
					200,
					200
				);
			}
	    }
	    catch (e) {
	      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
	    }
	},
};
