const config         = require('config');
const sequelize      = require('sequelize');
const Op             = require('sequelize').Op;
const model = require("../models/index");
const jwt            = require('jsonwebtoken');
const helpers = require("../helpers");
const hashPassword   = require('../helpers/hashPassword');
const responseHelper = require("../helpers/responseHelper");
const common         = require('../helpers/common');

const moment   = require('moment');

const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  service: config.SMTPSER,
  auth: {
    user: config.SENDMAIL,
    pass: config.SENDPWD,
  }
});

SUBSCRIPTION.hasMany(SUBDURATION, {foreignKey: 'subId'});
SUBSCRIPTION.hasOne(USERSUB, {foreignKey: 'subscriptionId'});
module.exports = {

  list: async (req, res) => {
    try {
      const params = req.params;
      const findData = await SUBSCRIPTION.findAll({
        where :{
          status:1,
          companyId: req.parentCompany
        },
        include:[
        {
          model:SUBDURATION,
          required:true,
          attributes:['id','price','duration']
        },
        {
          model:USERSUB,
          where:{
            status:1,
            userId:params.id
          },
          required:false,
          attributes:['id','amount','duration','durationId','startDate','endDate']
        },
      ]
      });
      if(findData.length>0){
        return helpers.jsonResponse(
          res,
          true,
          findData,
          "List fetch successfully",
          200,
          200
        );
      }else{
        return helpers.jsonResponse(res, false, {}, "No record found",'', 206);
      } 
    } catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

  /**
  *userId,subscriptionId,durationId,amount
  *
  */
  purchasePlan: async (req, res) => {
    const data = req.body;
    try{
      var existData= await USERSUB.findOne({
        where:{
          userId:data.userId,
          status:1
        }
      })
      var duration=0
      var durationData= await SUBDURATION.findOne({where:{id:data.durationId}})  
  if(durationData && durationData.dataValues)
  {
    duration=durationData.dataValues.duration
    var newDate = moment(new Date()).format("YYYY-MM-DD");
    var enddate = moment(new Date()).add(parseInt(duration), 'M').format("YYYY-MM-DD");
    //Create Plan 

    var users=null
      if(!existData)
      {
       users = await USERSUB.create({
        subscriptionId: data.subscriptionId,
        userId: data.userId,
        startDate: newDate,
        endDate: enddate,
        duration:duration,
        durationId:data.durationId,
        amount: data.amount,
        status: '1'
      });
    }
    else{
      users = await USERSUB.update({
        subscriptionId: data.subscriptionId,
        userId: data.userId,
        startDate: newDate,
        endDate: enddate,
        duration:duration,
        amount: data.amount,
        durationId:data.durationId,
      },{
        where:{
          id:existData.dataValues.id
        }
      });
    }
    var findData =await SUBSCRIPTION.findOne({where:{id:data.subscriptionId}});
    if(findData)
    {
      // const updatedResponse = await USER.update({
      //   userType: 4
      //   }, 
      //   {
      //   where : { 
      //     id: req.id
        
      //   }
      // });
      return helpers.jsonResponse(
        res,
        true,
        {},
        "Plan purchased successfully",
        200,
        200
      );
    }
    else
      return helpers.jsonResponse(res, false, {}, "No record found",'', 206);
    }
    else
      return helpers.jsonResponse(res, false, {}, "No record found",'', 206);
    }
    catch (e) {
      return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
    }
  },

}