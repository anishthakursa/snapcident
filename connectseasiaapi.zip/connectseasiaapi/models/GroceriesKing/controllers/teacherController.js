const model = require("../models/index");
const sequelize = model.sequelize;
const helpers = require("../helpers");
const { createToken } = require("../middleware");
const multer = require('multer');
const fs = require('fs');
var ejs = require('ejs');
var moment = require('moment');
const common              = require('../helpers/common');

var storage1 =   multer.diskStorage({
    destination: function (req, file, callback) {
      fs.mkdir('./uploads', function(err) {
          if(err) {
              console.log(err.stack)
          } else {
              callback(null, './uploads');
          }
      })
    },
    filename: function (req, file, callback) {
      callback(null, file.fieldname + '-' + Date.now());
    }
  });

const {RtcTokenBuilder, RtmTokenBuilder, RtcRole, RtmRole} = require('agora-access-token')
const { Op } = require('sequelize');
const user = model.users,
    bankDetail = model.bankDetail,
    document = model.documents,
    bookingDetail = model.bookingDetails;
    
   bookingNotification.belongsTo(bookingDetail,{foreignKey:'bookId',targetKey:'id'})
const handleError = helpers.handleError;
const nodemailer = require('nodemailer');
const transporter = nodemailer.createTransport({
  service: config.SMTPSER,
  auth: {
    user: config.SENDMAIL,
    pass: config.SENDPWD,
  }
});
module.exports = {

    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////// get registeration screen dropdown /////////////////////
    //////////////////////////////////////////////////////////////////////////////// 

    registerList: async function (req, res) {
        try {


            const fac = await faculty.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1                     /// only active
                }
            });
            const desgntn = await designation.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1                     /// only active
                }
            });
            const sub = await subject.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1                     /// only active
                }
            });
            const data = {};
            data.faculty = fac;
            data.designation = desgntn;
            data.subject = sub;
            return helpers.jsonResponse(
                res,
                true,
                data,
                "List",
                200,
                200
            );


        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////// get stream screen dropdown ////////////////////////
    //////////////////////////////////////////////////////////////////////////////// 

    streamOptions: async function (req, res) {
        try {


            const cls = await classes.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1                     /// only active
                }
            });
           
            const sub = await subject.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1                     /// only active
                }
            });
            const data = {};
            data.class = cls;
            data.subject = sub;
            return helpers.jsonResponse(
                res,
                true,
                data,
                "List",
                200,
                200
            );


        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////// get topic based on subject and class //////////////
    //////////////////////////////////////////////////////////////////////////////// 

    listTopic: async function (req, res) {
        try {

            const topic = await topics.findAll({
                attributes: ['id', 'name'],
                where: {
                    status: 1,                     /// only active
                    classId: req.params.classId,
                    subjectId: req.params.subjectId
                }
            });
            if (topic) {
            
                return helpers.jsonResponse(
                    res,
                    true,
                    topic,
                    "List",
                    200,
                    200
                );
            }

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    feedbackToStudent: async function (req, res) {
        let transaction;
        let formData = req.body;
        
        var subject = "Feedback";
        var index = fs.readFileSync('html/feedback-email.html', 'utf8');
        var renderedHtml = ejs.render(index, 
        formData); 
        var mailOptions = {
            from: 'info@k12superheroes.com',
            to: formData.parentEmail,
            subject: subject,
             // forceEmbeddedImages: true,
            html: renderedHtml
        };
        transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
              return false;
            }
              return true;
        });
        transaction = await sequelize.transaction();
        const userDet = await feedbacks.create({
            parentName: formData.parentName,
            subject: formData.subject,
            datetime: formData.datetime,
            tutorName: formData.tutorName,
            step1: formData.step1,
            step2: formData.step2,
            step3: formData.step3,
            step4: formData.step4,
            rememberThings: formData.rememberThings,
            progress: formData.progress,
            learned: formData.learned,
            rating: formData.rating,
            excercises: formData.excercises,
            tips: formData.tips,
            amount: formData.amount,
            studentEmail: formData.studentEmail,
            parentEmail: formData.parentEmail,
            studentName: formData.studentName,
            userId: formData.userId,
        }, { transaction })
        await transaction.commit();
        
        return helpers.jsonResponse(
            res,
            true,
            "successfull_feedback",
            200,
            200
        );


    },
    //////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////// register /////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////   

    register: async function (req, res) {

        console.log("......",req.body)
        console.log(".......",req.files)
        let transaction;
        try {
            const validations = {
                email: "required|email",
                password: "required|minLength:4",
                lName: "required|minLength:2",
                fName: "required|minLength:2",
                teacherId: "required|minLength:4",
                dob: "required|dateFormat:YYYY-MM-DD",
                subjects: "required",
                faculty: "required",
                designation: "required"
            };
            const formData = req.body;
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                if (matched.data.email && matched.data.email.rule == 'email') {
                    throw new handleError("must be email", 422);
                }
                console.log(matched)
                throw new handleError("Fields Required", 400);
            }

            // Verify User
            let verifyUser = await user.findOne({
                where: {
                    email: formData.email,
                }
            });

            if (verifyUser) {
                return helpers.jsonResponse(res, false, {}, "Email Already Exist", 400, 400);
            } else {
                const password = formData.password;

                transaction = await sequelize.transaction();

                const usr = await user.create({
                    email: formData.email,
                    password: password,
                    companyId: config.STATIC_COMPANYID,
                }, { transaction });

                await JSON.parse(formData.subjects).map(async sub => {
                    await teacherSubject.create({
                        teacherId: usr.dataValues.id,
                        subjectId: sub
                    }, { transaction })              
                })
                
                const userDet = await userDetail.create({
                    fName: formData.fName,
                    lName: formData.lName,
                    dob : moment(formData.dob,"YYYY-MM-DD").add(0, 'day').format('YYYY-MM-DD'),
                    userId: usr.dataValues.id,
                    uniqueId: formData.teacherId
                }, { transaction })

                //Send Mail
                var htmldata =
                  '<p>Hi ' + formData.fName + '</p>' +
                  '<p>You account has been created successfully. Please wait for verification for starting with K12 Superhero. Below are the login Credentails:- </p>' +
                  '<p>Email Id:  '+formData.email+'</p>  ' +
                  '<p>Password:  '+formData.password+' </p>' +
                  '<p>Thanks,</p>' +
                  '<p>Team iCampus</p>' +
                  '<p>--------</p>' +
                  '<p>This is an automated email. Please do not reply to it.</p>' +
                  '<p>In case of any help, kindly reach us at - please reach us at info@iCampus.com" for any help" etc.</p>';
                var subject = "iCampus Signup Successfully!";
                var mailOptions = {
                  from: "info@iCampus.com",
                  to: formData.email,
                  subject: subject,
                  html: htmldata
                };
                transporter.sendMail(mailOptions, function(error, info){
                 if (error) {
                    console.log(error);
                    return false;
                  }
                    return true;
                });

		let description = 'New professional signup request has been received from '+userDet.dataValues.fName+ ' '+userDet.dataValues.lName;
                await addNotification(userDet.dataValues.userId,'',description,"New Signup");

                await transaction.commit();
                const result = {
                    userName: userDet.dataValues.fName,
                    userId: userDet.dataValues.userId,
                    authToken: await createToken(usr.dataValues),
                    type:2
                };
                    return helpers.jsonResponse(
                	res,
                	true,
                	result,
                	"successfull_signup",
                	200,
                	200
                );
            }
        } catch (e) {
            if (transaction) await transaction.rollback();
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    contactus: async function (req, res) {
        try {
            const data  = req.body;
		const usr = await contactus.create({
                phoneNumber: data.phoneNumber,
                query: data.query,
                email: data.email,
                name: data.name,
                type:2,
                companyId:req.parentCompany
            });
            //Send Mail
                var htmldata =
                  '<p>Hi Admin</p>' +
                  '<p>'+data.name+' has sent a query:- </p>' +
                  '<p>'+data.message+'</p>  ' +
                  '<p>Thanks,</p>' +
                  '<p>'+data.name+'</p>' +
                  '<p>'+data.email+'</p>' +
                  '<p>--------</p>' +
                  '<p>This is an automated email. Please do not reply to it.</p>' +
                  '<p>In case of any help, kindly reach us at - please reach us at '+config.SENDER_EMAIL+'" for any help" etc.</p>';
                var subject = "Let’s Discuss Requirement";
                var mailOptions = {
                  from: config.SENDER_EMAIL,
                  to: data.email,
                  subject: subject,
                  html: htmldata
                };
           
            return helpers.jsonResponse(
                res,
                    true,
                    {},
                    "Success",
                    200,
                    200
                );
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    signup: async function (req, res) {
        let transaction;
        let Files=req.files;
        
        try {


            const validations = {
                email: "required|email",
                password: "required|minLength:4",
                lName: "required|minLength:2",
                fName: "required|minLength:2",
                address: "required|minLength:4",
                education: "required|minLength:2",
                grade: "required|minLength:1",
                //teacherId: "required|minLength:4",
                //dob: "required|dateFormat:YYYY-MM-DD",
                subjects: "required"
                //faculty: "required",
                //designation: "required"
            };
            const formData = req.body;


            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                if (matched.data.email && matched.data.email.rule == 'email') {
                    throw new handleError("must be email", 422);
                }
         throw new handleError("Fields Required", 400);
            }

            const codeData = await COMPANY.findOne({ where: {code: (formData.code?formData.code:config.STATIC_CODE)}});

            if(codeData)
            {

            // Verify User
            let verifyUser = await user.findOne({
                where: {
                    email: formData.email,
                }
            });

            if (verifyUser) {
                return helpers.jsonResponse(res, false, {}, "Email Already Exist", 400, 400);
            } else {
                var lPoints = '0';
                let refreeUser = formData.referralCode ? formData.referralCode : "";
                if(refreeUser != "")
                {
                    var checkRefrr = await userDetail.findOne({
                        where: {
                            referralCode: refreeUser,
                        }
                    });
                    if(checkRefrr)
                    {
                        var lPoints = '50';
                        await userDetail.update({ lPoints: lPoints }, { where: { userId: checkRefrr.dataValues.userId } });
                    }else{
                        return helpers.jsonResponse(res, false, {}, "Invalid referral code", 400, 400);
                    }
                }
                


                const timestamp = Math.round(new Date().getTime()/1000);
                var ImageFile1  = req.files.license;
                licenseFilename = Date.now() + '_' + ImageFile1.name.replace(/\s/g, "");

                ImageFile1.mv('public/document/'+licenseFilename, async function (err) {
                if(!err){

                    var ImageFile2  = req.files.cv;
                    cvFilename = Date.now() + '_' + ImageFile2.name.replace(/\s/g, "");

                 ImageFile2.mv('public/document/'+cvFilename, async function (err) {

                



                    if(!err){

                        
                        var ImageFile3  = req.files.report;
                        reportFilename = Date.now() + '_' + ImageFile3.name.replace(/\s/g, "");;




                        ImageFile3.mv('public/document/'+reportFilename, async function (err) {
                        if(!err){
                            var ImageFile4  = req.files.documents;
                            let io=0;
                            var icon = Date.now() + '_' + ImageFile4.name.replace(/\s/g, "");
                            ImageFile4.mv('public/document/'+icon, async function (err) {
                                if(!err){
                                    //const timestamp = Math.round(new Date().getTime()/1000);
                                    let images        = icon;
                                    const password = formData.password;
                                    //Convert password
                                    const pswd = await helpers.cryptPassword(password);
                                    var newpassword = pswd;
                                    transaction = await sequelize.transaction();

                                    const usr = await user.create({
                                        email: formData.email,
                                        companyId: codeData.dataValues.id,
                                        password: newpassword
                                    }, { transaction });

                                    // await JSON.parse(formData.subjects).map(async sub => {
                                    //     await teacherSubject.create({
                                    //         teacherId: usr.dataValues.id,
                                    //         subjectId: sub
                                    //     }, { transaction })              
                                    // })
                                    await teacherSubject.create({
                                        teacherId: usr.dataValues.id,
                                        subjectId: formData.subjects,
                                        subCategoryId: formData.grade
                                    }, { transaction });



                                    let nameUser  = usr.dataValues.id;
                                    let code = "USERDELC" + nameUser.substring(1, 7).toUpperCase();
                                    const userDet = await userDetail.create({
                                        fName: formData.fName,
                                        lName: formData.lName,
                                        address: formData.address,
                                        grade: "",
                                        education: formData.education,
                                        arrested: formData.arrested,
                                        arrestedDetails: formData.arrestedDetails,
                                        charged: formData.charged,
                                        chargedDetails: formData.chargedDetails,
                                        hours: formData.hours,
                                        dob : moment(formData.dob,"YYYY-MM-DD").add(0, 'day').format('YYYY-MM-DD'),

                                        userId: usr.dataValues.id,
                                        over18: formData.over18,
                                        phoneNo: formData.phoneNo,
                                        superPower: formData.superPower,
                                        languages:formData.languages,
                                        rememberToken: '0',
                                        status: '0',
                                        referralCode: code,
                                        lPoints: lPoints,
                                        age: formData.age
                                    }, { transaction })

                                    const userBankDet = await bankDetail.create({
                                        bankName: formData.bankName,
                                        userName: formData.userName,
                                        ifcCode: formData.ifcCode,
                                        userId: usr.dataValues.id,
                                        accountNumber: formData.accountNumber,
                                    }, { transaction })

                                    const documnets = await document.create({
                                        name: licenseFilename,
                                        type: 'license',
                                        userId: usr.dataValues.id
                                    }, { transaction })

                                    const documnets2 = await document.create({
                                        name: cvFilename,
                                        type: 'cv',
                                        userId: usr.dataValues.id
                                    }, { transaction })

                                    const documnets3 = await document.create({
                                        name: reportFilename,
                                        type: 'report',
                                        userId: usr.dataValues.id
                                    }, { transaction })

                                    await document.create({
                                        name: images,
                                        type: 'document',
                                        userId: usr.dataValues.id
                                    }, { transaction })
                                    /*await images.map(async subim => {
                                        await document.create({
                                            name: subim,
                                            type: 'document',
                                            userId: usr.dataValues.id
                                        }, { transaction })              
                                    })*/
                                    

                                    //Send Mail
                                    var htmldata =
                                    '<p>Hi ' + formData.fName + '</p>' +
                                    '<p>You account has been created successfully. Please wait for verification for starting with K12 Superhero. Below are the login Credentails:- </p>' +
                                    '<p>Email Id:  '+formData.email+'</p>  ' +
                                    '<p>Password:  '+formData.password+' </p>' +
                                    '<p>Thanks,</p>' +
                                    '<p>Team k12superhero</p>' +
                                    '<p>--------</p>' +
                                    '<p>This is an automated email. Please do not reply to it.</p>' +
                                    '<p>In case of any help, kindly reach us at - please reach us at info@k12superhero.com" for any help" etc.</p>';
                                    var subject = "k12superhero Signup Successfully!";
                                    var mailOptions = {
                                        from: "info@k12superheroes.com",
                                        to: formData.email,
                                        subject: subject,
                                        html: htmldata
                                    };
                                    transporter.sendMail(mailOptions, function(error, info){
                                     if (error) {
                                        console.log(error);
                                        return false;
                                      }
                                        return true;
                                    });


                                    await transaction.commit();
                                    if(refreeUser != "")
                                    {
                                        //Refree User
                                        var message = "Points added to your account by using "+checkRefrr.dataValues.fName+"'s referral code";
                                        common.addLoyality(userDet.dataValues.userId,checkRefrr.dataValues.userId,message,lPoints);

                                        //Own User
                                        var message = "Points added to your account as your friend "+formData.fName+" used your referral code";
                                        common.addLoyality(checkRefrr.dataValues.userId,userDet.dataValues.userId,message,lPoints);
                                    }
                                    
                                    const result = {
                                        userName: userDet.dataValues.fName,
                                        userId: userDet.dataValues.userId,
                                        authToken: await createToken(usr.dataValues),
                                        status: userDet.dataValues.status,
                                        type:2,
                                        referralCode:code,
                                        colorCode: "#373E80"
                                    };

                                    /**upload file
                                     * 
                                     */
                                    return helpers.jsonResponse(
                                        res,
                                        true,
                                        result,
                                        "successfull_signup",
                                        200,
                                        200
                                    );
                                }else{
                                    return helpers.jsonResponse(
                                        res,
                                        true,
                                        {},
                                        "unable to signup",
                                        200,
                                        200
                                    );
                                }
                            });
                        
                        }else{

                        }
                        });
                    } else {

                    }
                });
                } else {
                }
                });
            }
            
        }
        else return responseHelper.post(res, appstrings.code_invalid, null, 400);

                /***end */
                    
        } catch (e) {
            if (transaction) await transaction.rollback();
            console.log(e.message)

            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    

     //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////// get All Booking //////////////
    //////////////////////////////////////////////////////////////////////////////// 

    listBooking: async function (req, res) {
        try {
            const id = req.id;
            var newDate = moment(new Date()).format("YYYY-MM-DD");
		const totalRequests =  await bookingNotification.count({
                where: {
                    seen: {  [Op.eq]: 0 },
                    teacherId:id
                  }
            })
 let slotWise = new Date().toTimeString().slice(0,8)
            const topic = await TeacherBooking.findAll({
                attributes: ['id','bookingDate','userId','timeSlot','channelName','accessToken','status','slot'],
  		group:['bookingDate','slot'],
                where: {
                    teacherId:id,
                    status: {
                        [Op.notIn]:[ 2, 3,4] 
    
               },
                    bookingDate: {
                    	[Op.gte]: newDate
                    }
                },
                include: [{
                    model: user,
                    attributes: ['email'],
                },{
                    model: userDetail,
                    attributes: ['fName','lName','dob','uniqueId','image'],
                },{
                    model: Packages
                },{
                    model: subjectDetail
                },{
                    model: subCategory
                }],
		order: [
                    ['bookingDate', 'ASC'],
			['slot','ASC']
                                        ],
            });
            if (topic) {
                var array=[]
                for(var k=0;k<topic.length;k++)
                {
                    var d1 = new Date();
                    var d3 = new Date(topic[k].bookingDate +" "+topic[k].timeSlot);
                    var same1 = d1.getTime() <d3.getTime();


                   if(same1) array.push(topic[k])
                }
            
                return helpers.jsonResponseWithCount(
                    res,
                    true,
                    array,
			totalRequests,
                    "List",
                    200,
                    200
                );
            }

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    addSchudletest: async function (req, res) {
        try {
            const data = req.body;
            var slots=[]
            var slotsRemaining=[]

            var leave=""

            if(typeof data.slotsTime=='string') {
                data.slotsTime=[data.slotsTime]
                data.slotsQuantity='1'
                data.slotsQuantity1='1'
            } 
            var sldayst = JSON.parse(data.slotsTime);
            for(var k=0;k<sldayst.length;k++ )
            {
                var slot=sldayst[k]
                slots.push({'slot': slot,'bookings' :'1'})
                slotsRemaining.push({'slot': slot,'bookings' :'1'})
            }
            var sldays = JSON.parse(data.slotsday);
            for(var k=0;k<sldays.length;k++ )
            {
                var slotday = sldays[k];
                await addupate(slotday,data,slots,slotsRemaining,req,res)
            }
            return helpers.jsonResponse(res,true,{},"Schedule successfully",200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    
        addSchudle: async function (req, res) {
        try {
            const data = req.body;
            var slots=[]
            var slotsRemaining=[]
            var leave="";

       
            //Check Slot Booking
            var topic = await TeacherBooking.findOne({
                where: {
 			//userId:req.id
                    teacherId:req.id,
                    status: [0,1],
                    slotDuration: {[Op.ne]:parseInt( data.timeInterval ) }   
                
                }
            });
            if(topic)
            {
                return helpers.jsonResponse(res,false,{},"Sorry! you cant update your schedule. Kindly complete your accepted session.",400,200);
            }


//Check for day







/*********Check for dates */
var days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

var booking = await TeacherBooking.findAll({
    attributes:['bookingDate','timeSlot'],
    where: {
 //userId:req.id
        teacherId:req.id,
        status: [0,1],
        bookingDate: { [Op.gte]: new Date()}

       
    }})

var match=0
var slotsDay=data.slotsday
if(typeof data.slotsDay=='string') slotsDay=[data.slotsday]

for(var n=0;n<booking.length;n++)
{

    var d1 = new Date(booking[n].bookingDate +" "+data.startTime);
    var d2 = new Date(booking[n].bookingDate +" "+data.endTime);

    var d3 = new Date(booking[n].bookingDate +" "+booking[n].timeSlot);
    var same1 = d1.getTime()>d3.getTime();
    var same2 = d2.getTime()<d3.getTime();

if(same1)
{
    return helpers.jsonResponse(res,false,{},"Sorry! you cant update start time. Kindly complete your accepted session",400,200);

}



if(same2)
{
    return helpers.jsonResponse(res,false,{},"Sorry! you cant update end time. Kindly complete your accepted session",400,200);

}



    var date=new Date(booking[n].bookingDate)
    var dayCount=days[date.getDay()]
    if(!(slotsDay.includes(dayCount))) match++


}




if(match>0)
return helpers.jsonResponse(res,false,{},"Sorry! you cant update your schedule. Kindly complete your accepted session.",400,200);


/***************//************/ 


            await SCHEDULE.destroy({
                where: {
                    userId: req.id
                }
            }) 
            if(typeof data.slotsTime=='string') {
                data.slotsTime=[data.slotsTime]
                data.slotsQuantity='1'
                data.slotsQuantity1='1'
            }
            var sldayst = data.slotsTime;


            for(var k=0;k<sldayst.length;k++ )
            {
                var slot=sldayst[k]
                slots.push({'slot': slot,'bookings' :'1'})
                slotsRemaining.push({'slot': slot,'bookings' :'1'})
            }
            var sldays = data.slotsday;
            for(var k=0;k<sldays.length;k++ )
            {
                var slotday = sldays[k];
                await addupate(slotday,data,slots,slotsRemaining,req,res)
            }
if(data.hours)
	 	await updateWorkinghours(data.hours,req.id)

            return helpers.jsonResponse(res,true,{},"Schedule successfully",200,200);
        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
   //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////// get topic based on subject and class //////////////
    //////////////////////////////////////////////////////////////////////////////// 

    getAllTeachers: async function (req, res) {
        try {
           
            const params = req.body;
            const validations = {
                categoryId: "required",
            };
            // Call Translate
            const matched = await helpers.validate(params, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }


            var CategoryId    = params.categoryId;
            var subCategoryId = params.subCategoryId;
            var where={
                subjectId: CategoryId
            }
            //Filter With address
            // if(subCategoryId != "")
            // {
            //     where.subCategoryId = subCategoryId;
            // }
            const allTeachers = await teacherSubject.findAll({
                where: where
            })

            var teacherArray = [];
            for (var i = 0; i < allTeachers.length; i++) 
            {
                var subCateId = JSON.parse(allTeachers[i].subCategoryId);

                if(subCategoryId != "")
                {
                    if(subCateId.indexOf(subCategoryId) > -1)
                    {
                        var serviceId = allTeachers[i].teacherId;
                        teacherArray.push(serviceId);
                    }
                }else{
                    var serviceId = allTeachers[i].teacherId;
                    teacherArray.push(serviceId);
                }
                                
            } 
           
            const users = await user.findAll({
                attributes: ['id','email',[sequelize.literal('(SELECT AVG(rating) FROM ratings where teacherId = users.id)'), 'totalRating']],
                where: {
                    role : '2',
                    companyId: req.parentCompany,
                    id: {
                        [Op.in]: teacherArray
                    }
                },
                include: [{
                    model: userDetail,
                    attributes: ['fName','lName','dob','image','uniqueId','languages'],
                    required: true,
                    where: {
                        status: '1'
                    } 
                }],
order: sequelize.literal('totalRating DESC')
            });
            if (users) {
            
                return helpers.jsonResponse(
                    res,
                    true,
                    users,
                    "List",
                    200,
                    200
                );
            }

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////// get topic based on subject and class //////////////
    //////////////////////////////////////////////////////////////////////////////// 

    getAllSchedule: async function (req, res) {
        try {
            const id = req.id;

            const users = await SCHEDULE.findAll({
                attributes: ['fromDate','toDate'],
                where: {
                    userId : id
                },
                group: ['fromDate', 'toDate'], 
            });
            if (users) {
            
                return helpers.jsonResponse(
                    res,
                    true,
                    users,
                    "List",
                    200,
                    200
                );
            }

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////// get topic based on subject and class //////////////
    //////////////////////////////////////////////////////////////////////////////// 

    getScheduleDetails: async function (req, res) {
        try {
            const data = req.body;

            const users = await SCHEDULE.findAll({
                where: {
                    userId : req.id,
                    //fromDate: data.fromDate,
                    //toDate: data.toDate,
                } 
            });
            var mainArray =[];
            for (var i = 0; i < users.length; i++) {
                var array = {};
                array.name = users[i].dayParts;
                array.timeInterval = users[i].timeInterval;
                var slotdata = JSON.parse(users[i].slots);
                array.slots = slotdata;
                mainArray.push(array);
            }
            if (users) {
                return helpers.jsonResponse(
                    res,
                    true,
                    mainArray,
                    "List",
                    200,
                    200
                );
            }

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    //////////////////////////////////////////////////////////////////
    /////////////////////////Token History Teacher//////////////////
    //////////////////////////////////////////////////////////////////
    tTokenHistory:  async function (req, res) {
        const id = req.id;
        //Check User Token
        var datat = await userTokenHistory.findAll({
            attributes: ['senderId','receiverId','token','tokenBalance','status','type','createdAt'],
            where :{
                senderId: id,
                status: '1'
            },
            order: [
                ['id', 'DESC']
            ], 
        })
        var mainArray  = [];
        for (var i = 0; i < datat.length; i++) {
try{
 var array = {};
            var token = datat[i].token;
            var tokenBalance = datat[i].tokenBalance;
            var status = datat[i].status;
             
            var userdetails = await userDetail.findOne({
                where :{
                    userId: datat[i].receiverId
                }
            })
           
            
            var type = "Credited from " + userdetails.dataValues.fName + ' ' +userdetails.dataValues.lName;
           
            if(datat[i].type=="Transferred")
             type = "Trasferred to bank account";
            

            array.token        = token;
            array.tokenBalance = tokenBalance;
            array.type         = type;
            var theDate = new Date( datat[i].createdAt * 1000);
            var dateString = await common.formatAMPM(theDate);
            //alert(dateString );
            array.createdAt    = dateString; 
            mainArray.push(array);

 } catch (e) {
            continue;        }
           
        }
        return helpers.jsonResponse(res,true,mainArray,"Success",200,200);
    },

    /////////////////////////////////////////////////////////////////
    /////////////////////////Create Channel//////////////////
    //////////////////////////////////////////////////////////////////
    createChannel:  async function (req, res) {
        try {
            const validations = {
                teacherId: "required",
                studentId: "required",
                channelName: "required",
                token: "required",
            };
            const formData = req.body;
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }
            const usr = await videoClasses.create({
                teacherId: formData.teacherId,
                studentId: formData.studentId,
                channelName: formData.channelName,
                token: formData.token,
            });
            return helpers.jsonResponse(res,true,{},"Success",200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
    generateToken : function(req, resp){
        //Send Mail
        var htmldata =
          '<p>Hi ff</p>' +
          '<p>You account has been created successfully. Below are the login Credentails:- </p>' +
          '<p>Email Id:  goyalraghav</p>  ' +
          '<p>Password:  goyalraghav </p>' +
          '<p>Thanks,</p>' +
          '<p>Team k12superhero</p>' +
          '<p>--------</p>' +
          '<p>This is an automated email. Please do not reply to it.</p>' +
          '<p>In case of any help, kindly reach us at - please reach us at info@k12superhero.com" for any help" etc.</p>';
        var subject = "k12superhero Signup Successfully!";
        var mailOptions = {
          from: "info@k12superheroes.com",
          to: "goyalraghav@yopmail.com",
          subject: "Test",
          html: htmldata
        };
        transporter.sendMail(mailOptions, function(error, info){
         if (error) {
            console.log(error);
            return false;
          }
            return true;
        });
        const currentTimestamp = Math.floor(Date.now() / 1000)
		const appID = '9879e59357c04f4cb1a94f8f0fb9ba68';
        const appCertificate = 'ade367270eff4fdf9ea38664c982adf9';
        const channel = currentTimestamp+'_secretname';
        const uid = 0;
        const account = "0";
        const role = RtcRole.PUBLISHER;
        const expirationTimeInSeconds = 3600
        const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds
        const tokenA = RtcTokenBuilder.buildTokenWithUid(appID, appCertificate, channel, uid, role, privilegeExpiredTs);
        return resp.json({
            status: 200,
            message: "Agora Token Generated Successfully!",
            token: tokenA
        })

    },
    /////////////////////////////////////////////////////////////////
    /////////////////////////Teacher Accept/Reject API//////////////////
    //////////////////////////////////////////////////////////////////
    changeStatusNew:  async function (req, res) {
        try {
            const validations = {
                status: "required",
                bookingId: "required",
                teacherId: "required"
            };
            const formData = req.body;
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }
            const checkBokk = await bookingNotification.findOne({
                where: {
                    bookId: formData.bookingId,
                    teacherId: formData.teacherId,
                }
            })
            if(checkBokk)
            {   
                //Get User Details
                var Bookdetails = await bookingDetail.findOne({
                    where :{

                        id: formData.bookingId
                    }
                });

		 //Get subject, and sub-category details
                    let subNameDe = await common.getSubjectDetails(checkBokk.dataValues.subjectId);
                    let selectedSubDetails = await common.getSubCategoryName(checkBokk.dataValues.subCategoryId)

                if(formData.status == '1')
                {
                    //Check Already Accepted Request
                    var bookingstatus = await TeacherBooking.findOne({
                        where :{

                            teacherId: formData.teacherId,
                            bookingDate: Bookdetails.dataValues.bookingDate,
                            timeSlot: Bookdetails.dataValues.timeSlot,
                            status:[1]
                        }
                    });

                    if(bookingstatus)
                    {
                        return helpers.jsonResponse(res,true,{},"Sorry! You have already booked a slot. Please reject this request",200,200); 
                    }

			  // check for the previous booking SLOT on the booking Date
                     var schedules= await SCHEDULE.findOne({where :{userId: formData.teacherId}})
                     var previousBookingStatus = await TeacherBooking.findOne({
                        where :{

                            id: formData.bookingId,
                            slotDuration:{
 [Op.ne]:schedules.dataValues.timeInterval } // if other than current slot
                        }
                        });
                        if(previousBookingStatus){
                            return helpers.jsonResponse(res,true,{},appstrings.old_booking_reject,400,200);
                        }
                    

                }
                const teacherUpdate = await bookingNotification.update({
                    status: formData.status
                }, {
                    where: {
                        bookId: formData.bookingId,
                        teacherId: formData.teacherId,
                    }
                })
		        var teacherdetails = await userDetail.findOne({
                        attributes: ['fName','lName','rememberToken'],
                        where :{

                            userId: formData.teacherId
                        }
                    })


                    const companyId = req.parentCompany ? req.parentCompany : config.STATIC_COMPANYID;
                    var userdetails = await userDetail.findOne({
                        attributes: ['rememberToken','deviceToken','fName','lName'],
                        where :{

                            userId: Bookdetails.dataValues.studentId
                        }
                    })
			        var token = Bookdetails.dataValues.totalCredit;//get the discounted credit



 //Create Token
 var zoomMeetingId =''
 const currentTimestamp = Math.floor(Date.now() / 1000)
 var channelName        = currentTimestamp+'_'+teacherdetails.dataValues.fName + '_'+Bookdetails.dataValues.studentId;
 const appID            = '9879e59357c04f4cb1a94f8f0fb9ba68';
 const appCertificate   = 'ade367270eff4fdf9ea38664c982adf9';
 const uid = 0;
 const account = "0";
 const role = RtcRole.PUBLISHER;
 const expirationTimeInSeconds = 3600;
 const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
 const tokenA = RtcTokenBuilder.buildTokenWithUid(appID, appCertificate, channelName, uid, role, privilegeExpiredTs);
 const slot = await common.changeHourFormat(Bookdetails.dataValues.timeSlot)




                if(formData.status == '1')
                {
                    

                    //Get User Details
                    
                   //  var token = Bookdetails.dataValues.credit;
                    //Deduce User Credit
                    const userUpdate = await userDetail.update({
                        rememberToken: parseInt(userdetails.dataValues.rememberToken) - parseInt(token)
                    }, {
                        where: {
                            userId: Bookdetails.dataValues.studentId
                        }
                    })
                    //User Token Histiry Create
                    var usertokenBalance =  parseInt(userdetails.dataValues.rememberToken) - parseInt(token);
                    await deduceTokenHistory(Bookdetails.dataValues.studentId,formData.teacherId,0,token,usertokenBalance,"Out Bound");
                    //Credit Teacher Credit
                      const teacherUpdate = await userDetail.update({
                        rememberToken: sequelize.literal('rememberToken + '+parseInt(token))
                    }, {
                        where: {
                            userId: formData.teacherId
                        }
                    })


                    console.log("//////////////////////////////////////////////////////////////////////////////")
                    console.log(teacherdetails.dataValues,token)

                    //Teacher Token Histoy Create
                     var tokenBalance =  parseInt(teacherdetails.dataValues.rememberToken) + parseInt(token);
                    await addTokenHistory(Bookdetails.dataValues.studentId,formData.teacherId,1,token,tokenBalance,"In Bound");

                   
                    //get the zoom meet id

 		    let timeSchedule = Bookdetails.dataValues.bookingDate+' '+Bookdetails.dataValues.slot
                    let start_time = new Date(timeSchedule)
                    let meetId = await common.getZoomMeetingId(start_time,Bookdetails.dataValues.slotDuration)
                    if(meetId.status==200){
                        zoomMeetingId = meetId.join_url
                    }

	var description = teacherdetails.dataValues.fName+' '+teacherdetails.dataValues.lName+" has accepted "+ subNameDe+" appointment request from "+userdetails.dataValues.fName+' '+userdetails.dataValues.lName +" for " +selectedSubDetails;
                    var requestType = "Session Accept";
                    if(userdetails.dataValues.deviceToken != "")
                    {
                        var tokenstudent  = userdetails.dataValues.deviceToken;
                        common.sendNotification([tokenstudent],description,requestType);
                    }
                    await addNotification(formData.teacherId,Bookdetails.dataValues.studentId,description,requestType);
                    const usr = await TeacherBooking.create({
                        userId: Bookdetails.dataValues.studentId,
                        companyId: companyId,
                        teacherId: formData.teacherId,
                        bookingDate : Bookdetails.dataValues.bookingDate,
                        timeSlot: Bookdetails.dataValues.timeSlot,
                        subjectId: checkBokk.dataValues.subjectId,
                        subCategoryId: checkBokk.dataValues.subCategoryId,
                        packageId: Bookdetails.dataValues.packageId,
                        credit: token,
                        channelName: channelName,
                        accessToken: tokenA,
                        zoomMeetId: zoomMeetingId, 
                        bookingId:Bookdetails.dataValues.id,
                        slot:slot,
                        status:1,
			            slotDuration: Bookdetails.dataValues.slotDuration 
                    });

                    //Check Admin User and Send to Admin from customer
                    const Adminuser = await user.findOne({
                        where: {
                            role: '0'
                        }
                    });
                    const AdminuserDetails = await userDetail.findOne({
                        attributes: ['fName', 'lName','userId','rememberToken'],
                        where: {
                            userId: Adminuser.dataValues.id
                        }
                    });
                    const AdminHistoryUpdate = await userDetail.update({
                        rememberToken: sequelize.literal('rememberToken + '+parseFloat(token).toFixed(1))
                    }, {
                        where: {
                            userId: Adminuser.dataValues.id
                        }
                    });
                     var creditBalance =  (parseFloat(AdminuserDetails.dataValues.rememberToken)+ parseFloat(token)).toFixed(1);
                    await addCreditToAdmin(usr.dataValues.id,Bookdetails.dataValues.studentId,formData.teacherId,checkBokk.dataValues.subjectId,token,creditBalance,companyId);

                    //Delete All notifications
                    await bookingNotification.destroy({
                        where: {
                            bookId: formData.bookingId,
                            teacherId: {
                               [Op.ne]:  formData.teacherId
                            }
                        }
                    })  



                    //GEt all teh booking that is not acceptd by teache for same slot

                    var bookingData = await TeacherBooking.findAll({
                        where :{

                            teacherId: formData.teacherId,
                            bookingDate: Bookdetails.dataValues.bookingDate,
                            timeSlot: Bookdetails.dataValues.timeSlot,
                            bookingId: {
                                [Op.ne]:  formData.bookingId
                             }
                        }
                    });

if(bookingData.length>0)
{

    var ids=bookingData.map(user => user.bookingId);



      await TeacherBooking.update({status: 4}, { where: {bookingId: ids}})
await bookingNotification.update({status: 2}, {where: {bookId: ids}})


                }





                    
 		// cancel all the request for same booking date and slot for that professional
		    let currentBookingId = formData.bookingId
                     await cancelOtherSlotRequest(
                               formData.teacherId,
                                Bookdetails.dataValues.bookingDate,
                                 Bookdetails.dataValues.timeSlot,
                                teacherdetails.dataValues.fName,
                                 subNameDe,
				 currentBookingId
                                ) 
                    //subtractBookingsCount(slotdata,params.date,dayCount,params.teacherId,startDate);
                    return helpers.jsonResponse(res,true,{},appstrings.booking_accepted,200,200);
                }else{

                    //Get Studenr details
                    var studentuserdetails = await userDetail.findOne({
                        attributes: ['fName','lName','deviceToken'],
                        where :{

                            userId: Bookdetails.dataValues.studentId
                        }
                    })
                    //let subNameDe = await common.getSubjectDetails(checkBokk.dataValues.subjectId);
                   // var description = teacherdetails.dataValues.fName+" has rejected appointment request for "+subNameDe;
                   var description = teacherdetails.dataValues.fName+' '+teacherdetails.dataValues.lName+" has rejected "+subNameDe+" appointment request from "+studentuserdetails.dataValues.fName+' '+studentuserdetails.dataValues.lName+" for "+selectedSubDetails;
                    var requestType = "Session Reject";
                    //var description = "Your booking has been rejected.";
                    if(studentuserdetails.dataValues.deviceToken != "")
                    {
                        var tokenstudent  = studentuserdetails.dataValues.deviceToken;
                        common.sendNotification(tokenstudent,description,requestType);
                    }
                    
                    await addNotification(formData.teacherId,Bookdetails.dataValues.studentId,description,requestType);
                     await bookingNotification.destroy({
                         where: {
                            bookId: formData.bookingId,
                            teacherId: {
                                [Op.ne]:  formData.teacherId
                             }
                         }
                     })  


               await TeacherBooking.create({
                    userId: Bookdetails.dataValues.studentId,
                    companyId: companyId,
                    teacherId: formData.teacherId,
                    bookingDate : Bookdetails.dataValues.bookingDate,
                    timeSlot: Bookdetails.dataValues.timeSlot,
                    subjectId: checkBokk.dataValues.subjectId,
                    subCategoryId: checkBokk.dataValues.subCategoryId,
                    packageId: Bookdetails.dataValues.packageId,
                    credit: token,
                    channelName: channelName,
                    accessToken: tokenA,
                    zoomMeetId: zoomMeetingId, 
                    bookingId:Bookdetails.dataValues.id,
                    slot:slot,
                    status:4,
                    slotDuration: Bookdetails.dataValues.slotDuration 
                });


                    return helpers.jsonResponse(res,true,{},appstrings.booking_rejected,200,200);
                }
                
            }
            else{
                return helpers.jsonResponse(res,true,{},appstrings.booking_already_accepted,200,200);
            }
            
        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    /////////////////////////////////////////////////////////////////
    /////////////////////////Teacher Accept/Reject API//////////////////
    //////////////////////////////////////////////////////////////////
    changeStatus:  async function (req, res) {
        try {
            const validations = {
                status: "required",
                bookingId: "required",
                teacherId: "required"
            };
            const formData = req.body;
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }
            const checkBokk = await bookingNotification.findOne({
                where: {
                    bookId: formData.bookingId,
                    teacherId: formData.teacherId,
                }
            })
            if(checkBokk)
            {   
                //Get User Details
                var Bookdetails = await bookingDetail.findOne({
                    where :{
                        id: formData.bookingId
                    }
                });
                if(formData.status == '1')
                {
                    //Check Already Accepted Request
                    var bookingstatus = await TeacherBooking.findOne({
                        where :{
                            teacherId: formData.teacherId,
                            bookingDate: Bookdetails.dataValues.bookingDate,
                            timeSlot: Bookdetails.dataValues.timeSlot
                        }
                    });
                    if(bookingstatus)
                    {
                        return helpers.jsonResponse(res,true,{},"Sorry! You have already booked a slot. Please reject this request",200,200); 
                    }
                }
                const teacherUpdate = await bookingNotification.update({
                    status: formData.status
                }, {
                    where: {
                        bookId: formData.bookingId,
                        teacherId: formData.teacherId,
                    }
                })
                if(formData.status == '1')
                {
                    
                    //Get User Details
                    var userdetails = await userDetail.findOne({
                        attributes: ['rememberToken','deviceToken'],
                        where :{
                            userId: Bookdetails.dataValues.studentId
                        }
                    })

                    var token = Bookdetails.dataValues.credit;
                    //Deduce User Credit
                    const userUpdate = await userDetail.update({
                        rememberToken: parseInt(userdetails.dataValues.rememberToken) - parseInt(token)
                    }, {
                        where: {
                            userId: Bookdetails.dataValues.studentId
                        }
                    })
                    //User Token Histiry Create
                    var usertokenBalance =  parseInt(userdetails.dataValues.rememberToken) - parseInt(token);
                    await deduceTokenHistory(Bookdetails.dataValues.studentId,formData.teacherId,0,token,usertokenBalance,"Out Bound");
                    //Credit Teacher Credit
                    //Teacher Token Histoy Create
                    var teacherdetails = await userDetail.findOne({
                        attributes: ['fName','rememberToken'],
                        where :{
                            userId: formData.teacherId
                        }
                    }) 
                     const teacherUpdate = await userDetail.update({
                        rememberToken: sequelize.literal('rememberToken + '+parseInt(token))
                    }, {
                        where: {
                            userId: formData.teacherId
                        }
                    })
                    //Teacher Token Histoy Create

                    var tokenBalance =  parseInt(teacherdetails.dataValues.rememberToken) + parseInt(token);
                    await addTokenHistory(Bookdetails.dataValues.studentId,formData.teacherId,1,token,tokenBalance,"In Bound");

                    //Create Token
                    const currentTimestamp = Math.floor(Date.now() / 1000)
                    var channelName        = currentTimestamp+'_'+teacherdetails.dataValues.fName + '_'+Bookdetails.dataValues.studentId;
                    const appID            = '9879e59357c04f4cb1a94f8f0fb9ba68';
                    const appCertificate   = 'ade367270eff4fdf9ea38664c982adf9';
                    // create a buffer
                    // const buff = Buffer.from(channel, 'base64');
                    // // decode buffer as UTF-8
                    // const channelName = buff.toString('utf-8');
                    const uid = 0;
                    const account = "0";
                    const role = RtcRole.PUBLISHER;
                    const expirationTimeInSeconds = 3600;
                    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;
                    const tokenA = RtcTokenBuilder.buildTokenWithUid(appID, appCertificate, channelName, uid, role, privilegeExpiredTs);
                    

                    //Get Studenr details
                    var description = "Booking request has been accepted by "+teacherdetails.dataValues.fName+'.';
                    if(userdetails.dataValues.deviceToken != "")
                    {
                        var tokenstudent  = userdetails.dataValues.deviceToken;
                        
                        var message = {
                            to: tokenstudent,
                            notification: { 
                                "title": "Booking Accept", 
                                "body": description
                            },
                            priority: "high",
                            data: { 
                                "title": "Booking Accept", 
                                "body": description
                            }
                        };
                        fcm.send(message, function (err, response) {
                            if (err) {
                                console.log(err);
                                console.log("Error >>>>>>>>>> " + err);
                            } else {
                                console.log("Success >>>>>>>>>> " + response);
                            }
                        });
                    }
                    let requestType = "Booking Accept";
                    await addNotification(formData.teacherId,Bookdetails.dataValues.studentId,description,requestType);
                    const usr = await TeacherBooking.create({
                        userId: Bookdetails.dataValues.studentId,
                        teacherId: formData.teacherId,
                        companyId: req.parentCompany ? req.parentCompany : config.STATIC_COMPANYID,
                        bookingDate : Bookdetails.dataValues.bookingDate,
                        timeSlot: Bookdetails.dataValues.timeSlot,
                        subjectId: checkBokk.dataValues.subjectId,
                        credit: token,
                        channelName: channelName,
                        accessToken: tokenA
                    });
                    //Delete All notifications
                    await bookingNotification.destroy({
                        where: {
                            bookId: formData.bookingId,
                            teacherId: {
                               [Op.ne]:  formData.teacherId
                            }
                        }
                    })  
                    //subtractBookingsCount(slotdata,params.date,dayCount,params.teacherId,startDate);
                    return helpers.jsonResponse(res,true,{},"Request accepted successfully",200,200);
                }else{

                    //Get Studenr details
                    var studentuserdetails = await userDetail.findOne({
                        attributes: ['fName','lName','deviceToken'],
                        where :{
                            userId: Bookdetails.dataValues.studentId
                        }
                    })
                    var description = "Your booking has been rejected.";
                    if(studentuserdetails.dataValues.deviceToken != "")
                    {
                        var tokenstudent  = studentuserdetails.dataValues.deviceToken;
                        
                        var message = {
                            to: tokenstudent,
                            notification: { 
                                "title": "Booking Reject", 
                                "body": description
                            },
                            priority: "high",
                            data: { 
                                "title": "Booking Reject", 
                                "body": description
                            }
                        };
                        fcm.send(message, function (err, response) {
                            if (err) {
                                console.log(err);
                                console.log("Error >>>>>>>>>> " + err);
                            } else {
                                console.log("Success >>>>>>>>>> " + response);
                            }
                        });
                    }
                    let requestType = "Booking Reject";
                    await addNotification(formData.teacherId,Bookdetails.dataValues.studentId,description,requestType);
                    // await bookingNotification.destroy({
                    //     where: {
                    //         bookId: formData.bookingId,
                    //         teacherId: formData.teacherId
                    //     }
                    // })  
                    return helpers.jsonResponse(res,true,{},"Request rejected successfully",200,200);
                }
                
            }
            else{
                return helpers.jsonResponse(res,true,{},"This Booking is already accepted",200,200);
            }
            
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },
    /////////////////////////////////////////////////////////////////
    /////////////////////////Teacher Accept/Reject API//////////////////
    //////////////////////////////////////////////////////////////////
  

    /////////////////////////////////////////////////////////////////
    /////////////////////////Create Channel//////////////////
    //////////////////////////////////////////////////////////////////
    getRequestlist:  async function (req, res) {
        try {
            const id = req.id;
 		const unseen = await bookingNotification.update({seen:1},{where:
                {
                    teacherId: id
            }})
 		
		const slotFormat = await common.changeHourFormat(new Date().toLocaleTimeString('it-IT'))

            const usr = await bookingNotification.findAll({
                attributes: ['bookId','teacherId','description','status','subjectId','subCategoryId','createdAt'],
                  where: {
                    teacherId: id,
                    [Op.or]:[{
                        status:{[Op.ne]:0}
                    },
                   {
                        status:0,
                        '$bookingDetail.bookingDate$':{
                            [Op.gt]: new Date().toISOString().slice(0, 10)
                        },
                       
                    },
                    {
                        status:0,
                        '$bookingDetail.bookingDate$':{
                            [Op.eq]: new Date().toISOString().slice(0, 10)
                        },
                        '$bookingDetail.slot$':{
                                [Op.gte]: slotFormat
                        },
                    }
                 ]
                },
                include: [{
                    model: bookingDetail,
                    attributes: ['id','studentId','bookingDate','timeSlot','slot'],
			where:{
                        
                    },
                    include: [{
                        model: userDetail,
                        attributes: ['fName','lName','image']
                    }]
                }],
                order: [
                    ['createdAt','DESC']
                ]
            });
            for (var i = 0; i < usr.length; i++) {
                var subCateId = usr[i].subjectId               
                let subDetails = await subjectDetail.findOne({
                    attributes: ['id','name'],
                    where: {
                        id: subCateId
                    }
                });
                usr[i].dataValues.subjectsDetail = subDetails;

                //Sub Selected
                var subSubject = usr[i].subCategoryId;
                let selectedSubDetails = await SubCategory.findOne({
                    attributes: ['id','name'],
                    where: {
                        id: subSubject
                    }
                });
                usr[i].dataValues.subSubjectDetails = selectedSubDetails;

            }
            //console.log(usr);
            return helpers.jsonResponse(res,true,usr,"Success",200,200);
            
            
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    ////////////////////////////////////////////////////////////
    /////////////////////////Get Teacher Complete list//////////////////
    ////////////////////////////////////////////////////////////
    getCompleteClass:  async function (req, res) {
        try {
            const id = req.id;
		 const totalRequests =  await bookingNotification.count({
                where: {
                    seen: {  [Op.eq]: 0 },
                    teacherId:id
                  }
            })
            const topic = await TeacherBooking.findAll({
                attributes: ['id','bookingDate','teacherId','userId','packageId','timeSlot','subjectId','subCategoryId','credit','channelName','accessToken','status','createdAt','modifiedAt'],
                where: {
                    teacherId:id,
                    status: ['2','3'],
  			
                },
order:[['modifiedAt','Desc']]
            });

            var mainArray  = [];
            for (var i = 0; i < topic.length; i++) {
                var array       = {};
                var bookingDate = topic[i].bookingDate;
                var userId      = topic[i].userId;
                var timeSlot    = topic[i].timeSlot;
                var userdetails = await userDetail.findOne({
                    attributes: ['fName','lName','image'],
                    where :{
                        userId: userId
                    }
                })

                //Get Subject Details
                if( topic[i].subjectId != null)
                {
                    var subjectdetails = await subjectDetail.findOne({
                        where :{
                            id: topic[i].subjectId
                        }
                    })
                    var subName = subjectdetails.dataValues.name;
                }else{
                    var subName = "";
                }

                //Sub Selected
                var subSubject = topic[i].subCategoryId;
                let selectedSubDetails = await SubCategory.findOne({
                    attributes: ['id','name'],
                    where: {
                        id: subSubject
                    }
                });
                var subSubject = selectedSubDetails.dataValues.name;

                array.id          = topic[i].id;
                array.bookingDate = bookingDate;
                array.studentId   = userId;
                array.timeSlot    = timeSlot;
                array.fName       = userdetails.dataValues.fName;
                array.lName       = userdetails.dataValues.lName;
                array.image       = userdetails.image;
                array.subjectName = subName;
                array.SubsubjectName = subSubject;
		array.lastModify = topic[i].modifiedAt;
                mainArray.push(array);
            }
           return helpers.jsonResponseWithCount(res,true,mainArray, totalRequests,"Success",200,200);
        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /////////////////////////////////////////////////////////////////
    /////////////////////////Create Channel//////////////////
    //////////////////////////////////////////////////////////////////
    sendNotification:  async function (req, res) {
        try {
            const params = req.body;
            var token = params.deviceToken;
            var description = "You have been recieved booking request";
            var bookingId = "123456";
            var teacherId ="123456";
            var message = {
                to: token,
                notification: { 
                    "title": "Booking Request", 
                    "body": description,
                    "sound": 'default'
                },
                priority: "high",
                data: { 
                    "title": "Booking Request", 
                    "body": description,
                    "sound": 'default'
                }
            };
            fcm.send(message, function (err, response) {
                if (err) {
                    console.log(err);
                    console.log("Error >>>>>>>>>> " + err);
                } else {
                    console.log("Success >>>>>>>>>> " + response);
                }
            });
            return helpers.jsonResponse(res,true,{},"Success",200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /////////////////////////////////////////////////////////////////
    /////////////////////////Add Payout//////////////////
    //////////////////////////////////////////////////////////////////
    addPayouts:  async function (req, res) {
        try {
            const data = req.body;
            const users = await userRedeemption.create({
                userId: req.id,
                tokenAmount: data.tokenAmount,
                token: data.token
            });
            return helpers.jsonResponse(res,true,{},"Success",200,200);
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    testMailfunction: async  function (req, res) {
        //Send Mail
        var htmldata =
        '<p>Hi Name</p>' +
        '<p>You account has been created successfully. Please wait for verification for starting with K12 Superhero. Below are the login Credentails:- </p>' +
        '<p>Email Id:  testmail@yopmail.com</p>  ' +
        '<p>Password:  mind@123 </p>' +
        '<p>Thanks,</p>' +
        '<p>Team k12superhero</p>' +
        '<p>--------</p>' +
        '<p>This is an automated email. Please do not reply to it.</p>' +
        '<p>In case of any help, kindly reach us at - please reach us at info@k12superhero.com" for any help" etc.</p>';
        var subject = "k12superhero Signup Successfully!";
        var mailOptions = {
            from: "info@k12superhero.com",
            to: "testmail@yopmail.com",
            subject: subject,
            html: htmldata
        };
        transporter.sendMail(mailOptions, function(error, info){
         if (error) {
            console.log(error);
            return false;
          }
            return true;
        });
    },

    /*********** View Rating*****************/
    viewRating: async function (req, res) {
        try {

            const data = await ratingProfessional.findAll({
                where: {
                   teacherId: req.params.id
                },
                include: [{
                    model: userDetail,
                    attributes: ['fName','lName','image']
                }],
 order:[['createdAt','DESC']]
            })
            return helpers.jsonResponse(
                res,
                true,
                data,
                "Success", 
                200,
                200
            );
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    ////////////////////////////////////////////////////////////
    /////////////////////////Get Teacher Accepted list//////////////////
    ////////////////////////////////////////////////////////////
    getAcceptedClass:  async function (req, res) {
        try {

            const validations = {
                date: "required"
            };
            const formData = req.body;
            // Call Translate
            const matched = await helpers.validate(formData, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }

            
            var newDate = formData.date;
            var id = req.id;

            const topic = await TeacherBooking.findAll({
                attributes: ['id','bookingDate','teacherId','userId','timeSlot'],
                where: {
                    teacherId:id,
                    bookingDate: newDate,
                    status: 1
                }
            });
            var mainArray  = [];
            for (var i = 0; i < topic.length; i++) {
                var array       = {};
                var bookingDate = topic[i].bookingDate;
                var userId      = topic[i].userId;
                var timeSlot    = topic[i].timeSlot;
                var userdetails = await userDetail.findOne({
                    attributes: ['fName','lName','image'],
                    where :{
                        userId: userId
                    }
                })
                array.id          = topic[i].id;
                array.bookingDate = bookingDate;
                array.studentId   = userId;
                array.timeSlot    = timeSlot;
                array.fName       = userdetails.dataValues.fName;
                array.lName       = userdetails.dataValues.lName;
                array.image       = userdetails.dataValues.image;
                mainArray.push(array);
            }
            return helpers.jsonResponse(res,true,mainArray,"Success",200,200);

        } catch (e) {
            console.log(e)
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /////////////////////////////////////////////////////////////////
    /////////////////////////Get Pending Request List////////////////
    /////////////////////////////////////////////////////////////////
    getPendinglist:  async function (req, res) {
        try {
            const id = req.params.id;
            const usr = await bookingNotification.findAll({
                attributes: ['bookId','teacherId','description','status'],
                where: {
                    teacherId: id,
                    status: '0'
                },
                include: [{
                    model: bookingDetail,
                    attributes: ['id','studentId','bookingDate','timeSlot'],
                    include: [{
                        model: userDetail,
                        attributes: ['fName','lName','image']
                    }]
                }]
            });
            return helpers.jsonResponse(res,true,usr,"Success",200,200);
            
            
        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },


    transferCredit:  async function (req, res) {
        try {
            const params = req.body;
            var teacherId=params.teacherId
            var amount=params.amount


            const validations = {     amount: "required"};
            const matched = await helpers.validate(params, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }

            const data = await userTokenHistory.findOne({
              where:{senderId:teacherId},
              order:[['createdAt','DESC']]

            });


            if(data)
            {



            var tokenBalance=data.dataValues.tokenBalance?parseFloat(data.dataValues.tokenBalance):"0"
         
            if(tokenBalance<amount)
            return helpers.jsonResponse(res, false, {}, "Insufficient Balance", 200, 400);

         
         
            tokenBalance=tokenBalance-amount
            const usr = await userTokenHistory.create({
                senderId: teacherId,
                receiverId: teacherId,
                token : amount,
                type: "Transferred",
                tokenBalance: tokenBalance,
                status: 1,
                createdAt: Math.floor(new Date().getTime() / 1000)
        
            });
            return helpers.jsonResponse(res,true,usr,"Success",200,200);
            
        }

        return helpers.jsonResponse(res, false, {}, "Balance is not available", 200, 400);


        } catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    },

    /*
    *@role Create Time Slots
    *@author Raghav
    */
    getTimeSlots: async function(req,res)
    {   
        try{        
            const data = req.body;
            const validations = { 
                start: "required",
                end: "required",
                slot: "required"
            };
            const matched = await helpers.validate(data, validations);
            if (!matched.status) {
                throw new handleError("Fields Required", 400);
            }

            //Get Schudle API
            const pro  = await scheduleSetting.findOne({
                where: {
                    professionalId: req.id,
                }
            });

            let start       = data.start;
            let end         = data.end;
            let slot        = data.slot;
            var result      = await common.getTimeStops(start,end,slot);
            const d = new Date();
            const todayDate = moment(d).format('YYYY-MM-DD');
            let selectslot = pro ? pro.dataValues.slotTime : '0';
            if(slot == selectslot)
            {
                const users = await SCHEDULE.findOne({
                    where: {
                        userId : req.id
                    } 
                });

                if(users)
                {   
                    var slotdata = JSON.parse(users.dataValues.slots);
                    let checkSlot = slotdata.map(({ slot }) => slot);
                    for(let i=0;i<result.length;i++)
                    {
                        let slotti = result[i].slot;
                        if(checkSlot.indexOf(slotti) > -1)
                        {
                            result[i].status = '1';
                        }

                        //Get Booking Status
                        var bookingstatus = await TeacherBooking.findOne({
                            where :{
                                teacherId: req.id,
                                bookingDate:todayDate,
                                timeSlot: slotti
                            }
                        });
                        if(bookingstatus) 
                        {
                            result[i].bookingStatus = '1';
                        }

                    }
                }
            }
            
            
            let timeslots   = {};
            timeslots.slots = result;
            timeslots.professionalSetting = pro ? pro : {};
            return helpers.jsonResponse(res,true,timeslots,appstrings.success,200,200);
        }catch (e) {
            return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);
        }
    }
};

const updateWorkinghours = async function (hours,userId){
    await userDetail.update({
        hours:hours
    },{
        where: {
            userId:userId
        }
    })
} 

const addupate = async function (dayParts,data,slots,slotsRemaining,req,res) 
{
  try{
    const user = await scheduleSetting.findOne({
      where: {
        professionalId: req.id,
      }
    });
    if(user)
    {
        await scheduleSetting.update({
            slotTime: data.timeInterval,
            startTime: data.startTime,
            endTime: data.endTime
        },{
            where: {
                professionalId:req.id
            }
        })
    }else{
        await scheduleSetting.create({
            slotTime: data.timeInterval,
            startTime: data.startTime,
            endTime: data.endTime,
             professionalId: req.id
        });
    }
    const users = await SCHEDULE.create({
        fromDate: data.fromDate,
        toDate: data.toDate,
        timeInterval: data.timeInterval,
        slots: JSON.stringify(slotsRemaining),
        permanentSlots: JSON.stringify(slots),
        dayParts:dayParts,
        userId: req.id
    });
  }
  catch(e)
  {
   return helpers.jsonResponse(res, false, {}, e.message, e.code, 400);

  }

}
const deduceTokenHistory = async function (userId,teacherId,status,token,tokenBalance,type)
{
    
    const usr = await userTokenHistory.create({
        senderId: userId,
        receiverId: teacherId,
        token : token,
        type: type,
        tokenBalance: tokenBalance,
        status: status,
        createdAt: Math.floor(new Date().getTime() / 1000)

    });

}
const addTokenHistory = async function (userId,teacherId,status,token,tokenBalance,type)
{
    console.log("....",userId,teacherId,status,token,tokenBalance,type)



    const usr = await userTokenHistory.create({
        senderId: teacherId,
        receiverId: userId,
        token : token,
        type: type,
        tokenBalance: tokenBalance,
        status: status,
	    modifiedAt:new Date(),
        createdAt: Math.floor(new Date().getTime() / 1000)
    });

}


const addCreditToAdmin = async function (bookingId,customerId,professionalId,categoryId,credit,creditBalance,companyId)
{
    const cls = await Setting.findOne();   

   	var Payablecredit = (parseFloat(credit) * parseFloat(cls.dataValues.commission))/100;
	 const usr = await adminCreditHistory.create({
        bookingId: bookingId,
        companyId: companyId,
        customerId: customerId,
        professionalId : professionalId,
        categoryId: categoryId,
        credit: credit,
        commission: cls.dataValues.commission,
        payableCredit: Payablecredit.toFixed(1),
        creditBalance: creditBalance,
        status: '0'
    });

   

}

const addNotification = async function (senderId,receiverId,message,requestType)
{
    
    const usr = await Notification.create({
        senderId: senderId,
        reciverId: receiverId,
        message : message,
        requestType:requestType,
		createdAt: Math.floor(new Date().getTime() / 1000)

    });

}

const cancelOtherSlotRequest = async function (teacherId,bookingDate,slot,teacher,subject,exceptBooking){
    var description = teacher+" has rejected appointment request for "+subject;
    var requestType = "Session Reject";
    let results = await bookingNotification.findAll({
        where: {
            teacherId : teacherId
        },
        include: [{
            model: bookingDetail,
            where: {
                 bookingDate: bookingDate,
                 timeSlot:slot,
                  id:{[Op.ne]:exceptBooking}
            },
            include: [{
                model: userDetail,
                attributes: ['fName','lName','userId','deviceToken']
            }]
        }]
    })

    if(results){
        for(let i=0;i<results.length;i++){
                await bookingNotification.destroy({
                    where: {
                        bookId: results[i].bookId,
                    }
                })
                // console.log(
                //     description,
                //     requestType,
                //     results[i].bookingDetail.userDetail.deviceToken,
                //     teacherId,results[i].bookingDetail.userDetail.userId
                //     )
                if(results[i].bookingDetail.userDetail.deviceToken)
                {
                    common.sendNotification([results[i].bookingDetail.userDetail.deviceToken],description,requestType);  
                }
                await addNotification(teacherId,results[i].bookingDetail.userDetail.userId,description,requestType);
        }
        }
   
}

async function multipleFileupload(ImageFile4){
    let io=0;
    let images=[];
    // let changedname = '';
    // await ImageFile4.forEach( async function (file) {
    //     let timestampnew = Math.round(new Date().getTime()/1000);
    //     io = io + 1;
    //     //images.push(timestampnew+io+'docpdf.pdf');
    //     await file.mv('public/document/'+timestampnew+io+'docpdf.pdf', async function (err) {
    //         if(!err) {
    //             timestampnew = Math.round(new Date().getTime()/1000);
    //             images.push(timestampnew+io+'docpdf.pdf');
    //         } else {
    //             docstatus = 1;
    //         }
    //         console.log('io',io);
    //         console.log('imagesfinaleeee',images);
    //     });
        
    // })

    const timestamp = Math.round(new Date().getTime()/1000);
    //var ImageFile1  = file;
    await ImageFile4.mv('public/document/'+timestamp + 'docpdf.pdf', async function (err) {
        if (err){
            var imagename = timestamp + 'docpdf.pdf';
            docstatus = 1;
            return imagename;
        }
        else {
            var imagename = timestamp + 'docpdf.pdf';
            images.push(timestamp+'docpdf.pdf');
            return imagename;
        }
    });
   
    //return images;
}

async function uploadFile(file){
        

    const timestamp = Math.round(new Date().getTime()/1000);
    var ImageFile1  = file;
    await ImageFile1.mv('public/document/'+timestamp + '.jpg', async function (err) {
        if (err){
            console.log(err);
            let repnse = {status:'error',error:err,image:''};
            let imagename='error';
            return imagename;
        }
        else {
            let imagename = timestamp + '.jpg';
            let repnse = {status:'success',error:'',image:imagename};
            return imagename;
        }
    });

    //return helpers.jsonResponse(res, true, {}, "Success", 200, 200);
}