const mongoose = require("mongoose");


const Project = mongoose.Schema({
  project_name: {
    type: String,
    required: [true, "Please provide Project name"],
  },
  domain: {
    type: [String],
    required: [true, "Please provide Domain"],
  },

  cost_type: {
    type: String,
    required: [true, "Please provide Costing Type"],
  },
  billing: {
    type: String,
    // required:[true,'Please provide Email']
  },
  hour: {
    type: String,
  },
  project_desc: {
    type: String,
    // required:[true,'Please provide Mobile No']
  },
  client_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "clients",
    // required:[true,'Please provide client ID']
  },
  client_advocate_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "users",
  },
  account_manager_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "users",
  },

  documents: [
    {
      doc_name: {
        type: String,
      },
      doc_path: {
        type: String,
      },
    },
  ],

  // mail_status: {
  //   type: Boolean,
  //   required: [true, "Please provide mail status"],
  // },

  // created_at: {
  //   type: String,
  // },

  milestones: [
    {
      milestone_name: {
        type: String,
      },
      milestone_cost: {
        type: String,
      },
      milestone_status: {
        type: String,
        // default: 6
        //0, Milestone Started (admin)
        //1, Development Completed (Mobile App),
        //2, On Hold (Admin/App), 
        //3, Send Invoice will change status to Payment Pending (Admin)
        //4, After 5 days of sending mail will change to (4 code) Payment Followup (Admin), 
        //5, Button will be there Payment Received,
        //6, Milestone Pending (For other milestones).  
      },
      milestone_number : {
        type : Number
      }
    }
  ],

  total_cost: {
    type: String,
  },

  links: [
    {
      link_name: {
        type: String,
      },
      link_title: {
        type: String,
      },
    },
  ],

  delete_project: {
    type: String,
    default: "N",
  },
  status: {
    type: Number,
    default: 3
    //0, Started (admin)
    //1, Development Completed (Mobile App),
    //2, On Hold (Admin/App), 
    //3, Pending (For other milestones).  
  }
},
{ timestamps: true }
);

const projects = mongoose.model("projects", Project);
module.exports = projects;
