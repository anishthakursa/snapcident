const mongoose= require('mongoose');


const Country=mongoose.Schema({
   
    Name:{
        type:String,
       
       
    },
    Code:{
        type:String,
        
    }
    

   
});





const countries= mongoose.model('countries',Country);
module.exports=countries;