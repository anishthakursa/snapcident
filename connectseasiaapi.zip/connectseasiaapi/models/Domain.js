const mongoose= require('mongoose');


const Domain=mongoose.Schema({
   
    domain_name:{
        type:String,
       
       
    }

   
});





const domains= mongoose.model('domains',Domain);
module.exports=domains;