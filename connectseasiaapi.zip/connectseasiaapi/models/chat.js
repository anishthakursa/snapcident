const mongoose = require("mongoose");
const Schema = mongoose.Schema

const chatSchema = new Schema({
    senderId: { type: String, required: true },
    receiverId: { type: String, required: true },
    message: { type: String, required: true },
    date: { type: String, required: true }, //yyyy-MM-dd, UTC format will be shared by Frontend Team.
    time: { type: String, required: true} //HH:mm:ss, UTC format will be shared by Frontend Team.
}, { timestamps: true })

module.exports = mongoose.model('Chat', chatSchema)