const mongoose= require('mongoose');


const Designation=mongoose.Schema({
   
    name:{
        type:String,
       
       
    }

   
});





const designations= mongoose.model('designations',Designation);
module.exports=designations;