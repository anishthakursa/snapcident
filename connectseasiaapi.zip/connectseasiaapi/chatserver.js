const express = require("express");
const app = express();
const mongoose = require("mongoose");
const cors = require("cors");
const fs = require("fs");
require("dotenv-flow").config();
const Chat = require("./models/chat");
const Client = require('./models/Clients');
const User = require('./models/User');
const Notification = require("./customFunctions/fcm");
//Creating Https server
const https = require("https");
const privateKey = fs.readFileSync("./SSL/privkey.pem", "utf8");
const certificate = fs.readFileSync("./SSL/cert.pem", "utf8");
var credentials = { key: privateKey, cert: certificate };
const server = https.createServer(credentials, app);


// This array will contains the entries for socket
global.socket_array = [];

mongoose.connect(
  "mongodb://seasiaconnect:CTUZkwB94$2YzP@10.8.14.92:29083/seasiaconnect",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
  },
  function (error) {
    if (error) {
      console.log(error);
    } else {
      console.log("Connected TO Mongo database Cloud from Socket Server");
    }
  }
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(cors());

const SOCKET_PORT = process.env.SOCKET_PORT || 5035;

 server.listen(5035, () => {
  console.log(`Listening on Socket port ${SOCKET_PORT}`);
});

//TODO: Isn't it possible that we move socket functionality to another file to follow "S" of SOLID principles.
// socket implementation
var io = require("socket.io")(server);

// const socket = require("socket.io-client")("http://stgn.appsndevs.com:5035/");

// socket.on("connect_error", (res,err) => {
//   console.log(res);
//   console.log(err);
// });

// Connection to Socket
io.on("connection",  (socket) =>{
  try {
    console.log("User Connected with SocketId >>> ", socket.id);
    if (
      socket.handshake &&
      socket.handshake.query &&
      socket.handshake.query.user_id
    ) {
      let user_id = socket.handshake.query.user_id;
      console.log("User ID from Client Side >> ", user_id);
      for (let i = 0; i < socket_array.length; i++) {
        if (
          socket_array[i].user_id == user_id ||
          socket_array[i].user_id == undefined
        ) {
          socket_array.splice(i, 1);
        }
      }
      let arr = {
        socket_id: socket.id,
        user_id: user_id,
        is_online: true,
      };
      socket_array.push(arr);

      console.log("socket_array Value >> ", socket_array);

      //UserTyping Incoming Event Logic
      socket.on("isTyping", async (data) => {
        try{
          console.log('isTyoing data>>',data)
          //Checking that only receiver should receive this not any other user.
          let toUserInfo = socket_array.find(
            (x) => x.user_id == data.receiverId
          );
          console.log("I am userInfo of isTyping>>", toUserInfo);

          let socket_id = toUserInfo && toUserInfo.socket_id ? toUserInfo.socket_id : "";
            if (socket_id) {
              // Emit to User
              console.log("isTyping>>>", data);
              io.to(socket_id).emit("isTyping", data);
            } 
        }catch(err){
          console.log("error onisTyping>>>", err);
        }
      })

      // Incoming message event from  ClientSide
      socket.on("clientMessage", async (data) => {
        try {
          console.log("Data From ClientSide>> ", data);
          //Save the Chat in Mongoose
          const chat = new Chat({
            senderId: data.senderId,
            receiverId: data.receiverId,
            message: data.message,
            date: data.date,
            time: data.time,
          });

          chat.save().then((chat) => {
              console.log("Chat Saved successfully");
            }).catch((err) => {
              console.log("Error is>> ", err);
            });

          // Need to send Notification to receiver User
          var registrationToken = [];
          var title = 'Notification';
          var body = data.message;
          //Checking if receiverId is of client
          await Client.findOne({ _id : data.receiverId }, async (err, client)=>{
              if(err){
                console.log('Catching error>>',err);
              }
              if(!client){
                //If not then check receiverId is of user
              await User.findOne({_id : data.receiverId}, async (err, user)=>{ 
                registrationToken.push(user.device_token)
                Notification(registrationToken, title, body);
              })
              }else{
                registrationToken.push(client.device_token)
                Notification(registrationToken, title, body);
              }
          })
          

          //Checking that only receiver should receive this message not any other user.
          let toUserInfo = socket_array.find(
            (x) => x.user_id == data.receiverId
          );
          console.log("I am userInfo", toUserInfo);
          let socket_id =
            toUserInfo && toUserInfo.socket_id ? toUserInfo.socket_id : "";
          console.log("I am socket_id", socket_id);
          if (socket_id) {
            // Emit Incoming message to User
            console.log("serverMessage>>>>", data);
            io.to(socket_id).emit("serverMessage", data);
          } else {
            console.log(
              "Message - send to receiver socket info not found, now in temp chat"
            );
          }
        } catch (ex) {
          console.log("error @ message socket ", ex);
        }
      });

      // Disconnect Event listener
      socket.on("disconnect", async (data) => {
        try {
          let socketId = socket.id;
          let userObj = "";
          for (let i = 0; i < socket_array.length; i++) {
            if (socket_array[i].socket_id == socketId) {
              userObj = socket_array.splice(i, 1)[0];
            }
          }
        } catch (ex) {
          console.log("error @ socket disconnect ", ex);
        }
      });
    }
  } catch (ex) {
    console.log("error @ Push on socket # The Saviour ", ex);
  }
});
