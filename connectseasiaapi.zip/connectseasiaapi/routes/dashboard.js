const express = require("express");
const router = express.Router();
const { getcheck } = require("../middleware/auth");
const Users = require("../models/User");
const Clients = require("../models/Clients");
const Projects = require("../models/Project");

let userCount = "";
let clientCount = "";
let projectCount = "";

router.get("/dashboard", getcheck, async (req, res) => {

        
        await Users.countDocuments({delete_user: "N"}, function (err, uCount) {
        if (err){
            res.send({ data: "error" });
        }else{
             userCount = uCount;
        }
    }); 
     await Clients.countDocuments({delete_client :"N"}, function (err, cCount) {
        if (err){
            res.send({ data: "error" });
        }else{
            clientCount = cCount;
        }
    }); 
     await Projects.countDocuments({delete_project : "N"}, function (err, pCount) {
        if (err){
            res.send({ data: "error" });
        }else{
            projectCount = pCount;
        }
    }); 

    res.send({userCount, clientCount, projectCount});

  });

  module.exports = router;