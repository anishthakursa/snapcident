const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { getcheck } = require("../middleware/auth");
let multer = require("multer");
let upload = multer();

const Admin = require("../models/Admin");

router.get("/hehe", (req, res) => {
  res.render('client');
});

router.get("/api", (req, res) => {
  res.send({ message: "API server is running" });
});

router.post("/login", upload.array(), async function (req, res) {
  //for entering my password into DB for Login
  // const hashedPassword = await bcrypt.hash(req.body.password, 10);
  // console.log(hashedPassword);

  // res.send({msg:req.body.email});

  let error = {
    email: "",
    password: "",
  };
  if (req.body.email == "" || req.body.password == "") {
    if (req.body.email == "") {
      error.email = "Email Required";
    }
    if (req.body.password == "") {
      error.password = "Password Required";
    }

    res.send({ error });
  }
  try {
    const admin = await Admin.findByCredential(
      req.body.email,
      req.body.password
    );

    const token = await admin.generateAuthToken();

    //  res.cookie('jwt',token,{
    //     maxAge:1000*60*60*24,
    //     httpOnly:true,
    //  })

    res.send({ status: "ok", admin, token });
  } catch (error) {
    if (error.message == "AAA") {
      console.log(`I am error message: ${error.message}`);
      res.send({ errorLogin: "Login Failed" });
    }
  }
});

router.get("/logout", getcheck, async function (req, res) {
  //    await res.clearCookie('jwt');
  return res.send({ status: "ok", code: "200", logout: "success" });
});

module.exports = router;
