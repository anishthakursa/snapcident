const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const multer = require("multer");
const { getcheck } = require("../middleware/auth");
const Notification = require("../customFunctions/fcm");

const Client = require("../models/Clients");
const User = require("../models/User");
const Project = require("../models/Project");

let storage = multer.diskStorage({
  destination: "./public/uploads/documents",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

let uploads = multer({
  storage: storage,
});

router.post("/checkemail", async (req, res) => {
  const user_id = req.body.email_id;

  let client = await Client.findOne(
    { email_id: user_id, delete_client: "N" },
    { __v: 0 }
  );
  if (client == null) {
    let user = await User.findOne(
      { email_id: user_id, delete_user: "N" },
      { __v: 0 }
    );
    if (user == null) {
      res.status(202).send({ code: "202", data: "no record found" });
    } else {
      res.status(200).send({ code: "200", data: user, user_type: "user" });
    }
  } else {
    res.status(200).send({ code: "200", data: client, user_type: "client" });
  }
});

router.post("/createpassword", async (req, res) => {
  const user_id = req.body.email_id;
  const user_type = req.body.user_type;
  const passwor = await bcrypt.hash(req.body.password, 10);

  if (user_type == "client") {
    Client.findOne({ email_id: user_id, delete_client: "N" }, (err, docs) => {
      if (err) {
        res.send({ error: err });
      }

      if (docs == null) {
        res.status(202).send({ code: "202", data: "no user found" });
      } else {
        docs.password = passwor;
        docs.password_status = "Y";
        docs.save();
        res.status(200).send({
          code: "200",
          message: "Password created",
          user_type: "client",
          data: docs,
        });
      }
    });
  } else if (user_type == "user") {
    User.findOne({ email_id: user_id, delete_user: "N" }, (err, docs) => {
      if (err) {
        res.send({ error: err });
      }

      if (docs == null) {
        res.status(202).send({ code: "202", data: "no user found" });
      } else {
        docs.password = passwor;
        docs.password_status = "Y";
        docs.save();
        res.status(200).send({
          code: "200",
          message: "Password created",
          user_type: "user",
          data: docs,
        });
      }
    });
  } else {
    res.status(400).send({ code: "400", data: "error" });
  }
});

router.post("/applogin", async (req, res) => {
  let error = {
    email: "",
    password: "",
  };
  if (req.body.email == "" || req.body.password == "") {
    if (req.body.email == "") {
      error = { ...error, email: "Email Required" };
    }
    if (req.body.password == "") {
      error = { ...error, password: "Password Required" };
    }
    if(!req.body.device_token || !req.body.device_type){
      return res.status(202).json({code : "202", error : "deviceToken and deviceType required"});
    }
    return res.status(202).send({ code: "202", error });
    
  }
  try {
    let client = await Client.findOne(
      { email_id: req.body.email, delete_client: "N" },
      { __v: 0 }
    
    );
    if (client == null) {
      let user = await User.findOne(
        { email_id: req.body.email, delete_user: "N" },
        { __v: 0 }
      );
      if (user == null) {
        return res.status(202).send({ code: "202", data: "no record found" });
      } else {
        const user = await User.findByCredential(
          req.body.email,
          req.body.password
        );
        const token = await user.generateAuthToken();

        //  res.cookie('jwt',token,{
        //     maxAge:1000*60*60*24,
        //     httpOnly:true,
        //  })
        //First Delete earlier Token for user
        user.device_token = "";
        user.device_type = "";
        await user.save();

        //Now save new Token for user
        user.device_token = req.body.device_token;
        user.device_type = req.body.device_type;
        await user.save();
        return res.status(200).send({
          code: "200",
          status: "ok",
          data: user,
          token,
          user_type: "user",
        });
      }
    } else {
      const client = await Client.findByCredential(
        req.body.email,
        req.body.password
      );
      const token = await client.generateAuthToken();

      // res.cookie('jwt',token,{
      //     maxAge:1000*60*60*24,
      //     httpOnly:true,
      // })
     
        //First Delete earlier Token
        client.device_token = "";
        client.device_type = "";
        await client.save();

        //Now save new Token
        client.device_token = req.body.device_token;
        client.device_type = req.body.device_type;
        await client.save();

      //Below was for Array of objects of Tokens
      // req.body.device_tokens.map((ele) => {
      //   client.device_tokens = client.device_tokens.concat({
      //     device_token : ele.device_token,
      //     device_type: ele.device_type,
      //   });
      // });
        // const result  = await client.save();
        // console.log(result);
      return res.status(200).send({code: "200",status: "ok",data: client,token,user_type: "client",});
      // res.send({data:user,user_type:'user'});
      // res.send({data:client,user_type:'client'});
    }
  } catch (error) {
    if (error.message == "AAA") {
      console.log(error.message);
      res.status(203).send({ code: "203", errorLogin: "Login Failed" });
    }
  }
});

router.post("/relatedprojects", getcheck, (req, res) => {
  const user_id = req.body.user_id;
  const user_type = req.body.user_type;
  if (user_type == "client") {
    Project.find({ client_id: user_id, delete_project: "N" })
      .populate("client_id")
      .populate("client_advocate_id")
      .populate("account_manager_id")
      .exec((err, docs) => {
        if (err) {
          console.log(err);
        }
        if (docs == null) {
          res
            .status(202)
            .send({ code: "202", status: "fail", message: "No data found" });
        }

        //Empty array for assigning data in docs
        alldata = [];
        docs.map((ele) => {
          //Counting how much are in Progress i.e status = 0
          let milestoneProgress = 0;
          ele.milestones.forEach((array)=>{
            if(array.milestone_status == "0"){
              milestoneProgress += 1;
              return milestoneProgress; 
            }
          })
          
          //Counting how much are Completed i.e status = 5
          let milestoneCompleted = 0;
          ele.milestones.forEach((array)=>{
            if(array.milestone_status == "5"){
              milestoneCompleted += 1;
              return milestoneCompleted; 
            }
          }) 
          
          //Counting how much are in pending i.e status = 6
          let milestonePending = 0;
          ele.milestones.forEach((array)=>{
            if(array.milestone_status == "6"){
              milestonePending += 1;
              return milestonePending; 
            }
          })
          
          //Counting TotalCost only for Fixed
          let totalCost = 0; 
          if(ele.cost_type == "Fixed cost"){
            ele.milestones.forEach((array)=>{
              totalCost+= parseInt(array.milestone_cost);
                return totalCost; 
            })
          }
          //Assigning counts and totalCost to doc result
          ele._doc.totalMilestones = ele.milestones.length;
          ele._doc.milestoneProgress = milestoneProgress;
          ele._doc.milestoneCompleted = milestoneCompleted;
          ele._doc.milestonePending = milestonePending;
          ele._doc.totalCost = totalCost;
          ele._doc.role = "client"
          alldata.push(ele);
        });
        
        res.status(200).send({ code: "200", status: "ok", data: docs });
      });
  } else if (user_type == "user") {
    Project.find({
      delete_project: "N",
      $or: [{ client_advocate_id: user_id }, { account_manager_id: user_id }],
    })
      .populate("client_id")
      .populate("client_advocate_id")
      .populate("account_manager_id")
      .exec((err, docs) => {
        if (err) {
          console.log(err);
        }
        if (docs == null) {
          res
            .status(202)
            .send({ code: "202", status: "fail", message: "No data found" });
        }
        
        alldata = [];
        docs.map((ele) => {
           
          //Counting how much are in Progress i.e status = 0
          let milestoneProgress = 0;
          ele.milestones.forEach((array)=>{
            if(array.milestone_status == "0"){
              milestoneProgress += 1;
              return milestoneProgress; 
            }
          })
          
          //Counting how much are Completed i.e status = 5
          let milestoneCompleted = 0;
          ele.milestones.forEach((array)=>{
            if(array.milestone_status == "5"){
              milestoneCompleted += 1;
              return milestoneCompleted; 
            }
          }) 
          
          //Counting how much are in pending i.e status = 6
          let milestonePending = 0;
          ele.milestones.forEach((array)=>{
            if(array.milestone_status == "6"){
              milestonePending += 1;
              return milestonePending; 
            }
          })

            //Counting TotalCost only for Fixed
            let totalCost = 0; 
            if(ele.cost_type == "Fixed cost"){
              ele.milestones.forEach((array)=>{
                totalCost+= parseInt(array.milestone_cost);
                  return totalCost; 
              })
            }
          
          //Assigning counts to doc result
          ele._doc.totalMilestones = ele.milestones.length;
          ele._doc.milestoneProgress = milestoneProgress;
          ele._doc.milestoneCompleted = milestoneCompleted;
          ele._doc.milestonePending = milestonePending;
          ele._doc.totalCost = totalCost;


          if (ele.client_advocate_id._id == user_id) {
            ele._doc.role = "client_advocate";
            alldata.push(ele);
          } else {
            ele._doc.role = "account_manager";
            alldata.push(ele);
          }
        });
        // console.log(alldata);
        res.status(200).send({ code: "200", status: "ok", data: alldata });
      });
  }
});

router.post("/appgetmilestone", getcheck, (req, res) => {
  // console.log(`I am client : ${req.client.device_tokens[0].device_token}`);
  const id = req.body.project_id;

  Project.findOne({ _id: id, delete_project: "N" })
    .populate("client_id")
    .populate("client_advocate_id")
    .populate("account_manager_id")

    .exec((err, doc) => {
      if (err) {
        //res.status(202).send({code:"202",status:"fail",message:"No data found"})
        console.log(err);
      }
      if (doc == null) {
        res
          .status(202)
          .send({ code: "202", status: "fail", message: "No data found" });
      }
      res.status(200).send({ code: "200", status: "ok", data: doc.milestones });
    });
});

router.post("/createlink", getcheck, async (req, res) => {
  const project_id = req.body.project_id;

  await Project.findOne(
    { _id: project_id, delete_project: "N" },
    (err, proj) => {
      if (err) {
        return res.send({ error: err });
      }
      if (proj == null) {
        return res
          .status(202)
          .send({ code: "202", status: "fail", message: "No data found" });
      }
      if (proj) {
        proj.links = proj.links.concat({
          link_name: req.body.link_name,
          link_title: req.body.link_title,
        });

        proj.save();
        res.status(200).send({ code: "200", status: "ok", data: proj.links });
      }
    }
  );
});

router.post("/viewlinks", getcheck, (req, res) => {
  const id = req.body.project_id;

  Project.findOne({ _id: id, delete_project: "N" })
    .populate("client_id")
    .populate("client_advocate_id")
    .populate("account_manager_id")

    .exec((err, doc) => {
      if (err) {
        return res.send({ error: err });
      }
      //    res.status(200).send({code:"200",status:"ok",data:"hello"});
      res.status(200).send({ code: "200", status: "ok", data: doc.links });
    });
});

router.post("/deletelink", getcheck, (req, res) => {
  const id = req.body.project_id;
  // const link_id=req.body.link_id;
  Project.findOneAndUpdate(
    { _id: id, delete_project: "N" },
    { $pull: { links: { _id: req.body.link_id } } },
    {
      useFindAndModify: false,
    },
    (err, data) => {
      if (err) {
        return res.status(500).send({ error: "error in deleting link" });
      }

      res.status(200).send({ code: "200", status: "ok", data: data.links });
    }
  );
});

router.post("/mobiledocupload",getcheck,uploads.array("file_upload"),async (req, res) => {
    const files = req.files;
    var docarray = new Array();
    var domainarray = new Array();

    files.forEach(async (file) => {
      try {
        docarray.push({
          doc_name: file.filename,
          doc_title: req.body.doc_title,
        });
      } catch (error) { }
    });

    Project.findOne({ _id: req.body.project_id }, (err, docs) => {
      if (err) {
        return res.send({ error: err });
      }

      if (docs == null) {
        return res
          .status(202)
          .send({ code: "202", status: "fail", message: "No data found" });
      } else {
        docs.documents = docs.documents.concat(docarray);
        docs.save({ validateBeforeSave: false });
        res
          .status(200)
          .send({ code: "200", status: "ok", message: "document uploaded" });
      }
    });
  }
);

router.post("/viewdocs", getcheck, async (req, res) => {
  const id = req.body.project_id;
  try {
    await Project.findOne({ _id: id, delete_project: "N" }).populate("client_id")
      .populate("client_advocate_id")
      .populate("account_manager_id")
      .exec((err, doc) => {
        if (err) {
          console.log(`i am the error ${err}`);
          return res.send({ error: err });
        }
        
        if (doc == null || doc == "") {
          return res.status(400).send({ code: "400", status: "Bad Request", data: "No Record Found" });
        }

        return res.status(200).send({ code: "200", status: "ok", data: doc.documents });
      });
  } catch (err) {
    console.log(`I am catch err ${err}`);
  }

});

router.get("/applogout", getcheck, async function (req, res) {
  //  res.clearCookie('jwt');
  return res.send({ status: "ok", code: "200", logout: "success" });
});

module.exports = router;
