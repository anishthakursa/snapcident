const express= require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const {getcheck}= require('../middleware/auth');
const User = require('../models/User');
const Password = require("../customFunctions/passwordGenerator");
const sendMailer = require("../customFunctions/sendMailer");

router.post('/adduser',getcheck, async (req,res)=>{

    //Create random password here
    let password = Password ();
    console.log(password);
    //Encrypt the password here
    hashedPassword = await bcrypt.hash(password, 10);
    
    let newUser={
        first_name:req.body.first_name,
        last_name:req.body.last_name,
        employee_id:req.body.employee_id,
        email_id:req.body.email_id,
        password : hashedPassword,
        password_status:'N',
        skype_id:req.body.skype_id,
        mobile_no:req.body.mobile_no,
        other_contact:req.body.other_contact,
        designation:req.body.designation,
        report_to_id:req.body.report_to_id, 
    }
    
    await User.create(newUser).then(user=>{
        res.status(201).send({status:"success",data:user});

        //Send Email for password
        console.log(password);
        let to = req.body.email_id;
        let subject = 'Account Created Successfully';
        let template = 'password';
        let context = {
            password : password
        }
        sendMailer(to,subject,template,context)

            
        }).catch(err=>{
            if (err.message.includes('users validation failed')) {
                let error={};
                Object.values(err.errors).forEach((properties)=>{
                        error[properties.path]=properties.message;
                });
                res.send({error});
            }
        }); 
});

router.get('/viewusers',getcheck,(req,res)=>{

    User.find({delete_user:'N'}).sort({_id:-1})
        .populate('report_to_id',`first_name last_name email_id skype_id`)
        .exec((err, doc)=> {
           if(err){
               res.send({error:err});
           }
            res.send({data:doc});
            
          });

    // User.find({})
    // .then(users=>{
    //     res.send({data:users});
    // })
    // .catch((err)=>res.send({data:'error'}));

});


router.post('/viewoneuser',getcheck,(req,res)=>{

    const id=req.body.user_id;
    User.findOne({_id:id,delete_user:'N'})
        .populate('report_to_id',`first_name last_name email_id skype_id`)
        .exec((err, doc)=> {
           if(err){
               res.send({error:err});
           }
            res.send({data:doc});
            
          });
    
    // User.findOne({_id:id})
    // .then(user=>{
    //     res.send({data:user});
    // })
    // .catch((err)=>res.send({data:err})); 

});

router.post('/deleteuser',getcheck,(req,res)=>{
    let searchQuery = {_id:req.body.user_id};
    
    User.updateOne(searchQuery,{$set:{
       delete_user:'Y' 
    }})
    .then(user=>{
        res.send({data:user});

    })
    .catch(err=>{
        res.send({error:err});
    })
});


router.post('/updateuser',getcheck,(req,res)=>{
    let searchQuery = {_id:req.body.user_id};
    
    User.updateOne(searchQuery,{$set:req.body})
    .then(user=>{
        res.send({status:"ok",data:user});

    })
    .catch(err=>{
        res.send({error:err});
    })
});

module.exports=router;
