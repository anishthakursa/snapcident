const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const moment = require("moment");
const { getcheck } = require("../middleware/auth");
const Project = require("../models/Project");
const Country = require("../models/Country");
const Domain = require("../models/Domain");
const Designation = require("../models/Designation");
const sendMailer = require("../customFunctions/sendMailer");

const appRoot = "https://stgn.appsndevs.com"

// const memorystorage=multer.memoryStorage();
// const uploads =multer({
//     storage:memorystorage,

// })
let storage = multer.diskStorage({
  destination: "./public/uploads/documents",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

let uploads = multer({
  storage: storage,
});

router.post("/projectupload", getcheck, uploads.array("file_upload"), async (req, res) => {
    const files = req.files;
    var docarray = new Array();
    var domainarray = new Array();
    
    files.forEach(async (file) => {
      try {
        let fileUrl = file.path.replace(/\\/g, "/").substring("public".length);
        docarray.push({ doc_name: file.filename, doc_path :fileUrl});
      } catch (error) {}
    });
   
    var newproject = {
      project_name: req.body.project_name,
      domain: req.body.domain,
      cost_type: req.body.cost_type,
      billing: req.body.billing,
      hour: req.body.hour,
      project_desc: req.body.project_desc,
      client_id: req.body.client_id,
      client_advocate_id: req.body.client_advocate_id,
      account_manager_id: req.body.account_manager_id,
      documents: docarray,
      // mail_status: req.body.mail_status,
      // created_at: new Date(),
    };
    try{
      Project.create(newproject).then(async (project) => {
        //To find email ids of users and client
        await Project.findOne({ _id: project._id }).populate("client_id")
          .populate("client_advocate_id")
          .populate("account_manager_id").exec(async (err, docs) => {
  
               // Step 1 Mail will be Shoot to client
            let to = docs.client_id.email_id;;
            let subject = 'Project Created Successfully';
            let template = 'projectCreated';
            let createdDate = moment(docs.createdAt).format('DD MMMM YYYY');
            let context = {
                userName : docs.client_id.first_name,
                projectName : docs.project_name,
                createdDate: createdDate,
                userRole : 'Client'
            }
  
            await sendMailer(to,subject,template,context)
  
            // Step 2 Mail will be Shoot to client advocate
            to = docs.client_advocate_id.email_id;;
            context = {
                userName : docs.client_advocate_id.first_name,
                projectName : docs.project_name,
                createdDate: createdDate,
                userRole : 'Client Advocate'
            }
         
            await sendMailer(to,subject,template,context)
  
            // Step 3 Mail will be Shoot to Account Manager
            to = docs.account_manager_id.email_id;;
            context = {
              userName : docs.account_manager_id.first_name,
              projectName : docs.project_name,
              createdDate: createdDate,
              userRole : 'Account Manager'
            }
          
            await sendMailer(to,subject,template,context)
  
            return res.status(201).send({ success: docs });
  
          }) 
        })
        .catch((err) => {
          if (err.message.includes("projects validation failed")){
            let error = {};
            Object.values(err.errors).forEach((properties) => {
              error[properties.path] = properties.message;
            });
            return res.send({ error });
           }
        });

    }catch(err){
      console.log(err);
      return res.status(500).send({ error: { "message": "Internal Server Error" } });
    }
  }
);

router.post("/projectupdate",getcheck,uploads.array("file_upload"),
  async (req, res) => {
    const files = req.files;
    var docarray = new Array();
    var domainarray = new Array();

    files.forEach(async (file) => {
      try {
        let fileUrl = file.path.replace(/\\/g, "/").substring("public".length);
        docarray.push({ doc_name: file.filename, doc_path :fileUrl});
      } catch (error) {}
    });

    Project.findOne({ _id: req.body.project_id }, (err, docs) => {
      if (err) {
        return res.send({ error: err });
      }

      if (docs == null) {
        return res.send({ status: "ok", data: null });
      } else {
        (docs.project_name = req.body.project_name),
        (docs.domain = req.body.domain),
          (docs.cost_type = req.body.cost_type),
          (docs.billing = req.body.billing),
          (docs.hour = req.body.hour),
          (docs.project_desc = req.body.project_desc),
          (docs.client_id = req.body.client_id),
          (docs.client_advocate_id = req.body.client_advocate_id),
          (docs.account_manager_id = req.body.account_manager_id),
          (docs.documents = docs.documents.concat(docarray));
        docs.save((err, docus) => {
          if (err) {
            if (err.message.includes("projects validation failed")) {
              let error = {};
              Object.values(err.errors).forEach((properties) => {
                error[properties.path] = properties.message;
              });
              return res.send({ error });
            }
          } else {
            return res.send({ status: "ok", message: "Project Updated" });
          }
        });
      }
    });
  }
);

router.get("/viewprojects", getcheck, async (req, res) => {
  await Project.find({ delete_project: "N" })
    .sort({ _id: -1 })
    .populate("client_id")
    .populate("client_advocate_id")
    .populate("account_manager_id")

    .exec((err, doc) => {
      if (err) {
       return res.send({ error: err });
      }
     return res.send({ data: doc });
    });
});

router.post("/createmilestones", getcheck, async (req, res) => {
  try {
    // console.log(req.body);
    if (!req.body.project_id) {
      return res
        .status("400")
        .json({ error: { message: "Project ID is required" } });
    }
    // This was done earlier but not required now
    //   if (!req.body.total_cost) {
    //   console.log("I am here");
    //   res.send({ error: { total_cost: "Total cost is required" } });
    // } else {

    const project_id = req.body.project_id;

    await Project.findOne(
      { _id: project_id, delete_project: "N" },
      (err, proj) => {
        if (err) {
          return res.send({ error: err });
        }
        if (!proj) {
          return res
            .status("401")
            .send({ error: { message: "No such Project Found" } });
        } else {
          if (!req.body.mile_stones) {
            return res.send({ error: { message: "Milestone is required" } });
          }

          req.body.mile_stones.map((ele) => {
            proj.milestones = proj.milestones.concat({
              milestone_name: ele.milestone_name,
              milestone_cost: ele.milestone_cost,
              milestone_status: ele.milestone_status,
            });
          });

          // console.log(req.client.device_token);
          // proj.total_cost = req.body.total_cost;
          proj.save();
          // res.send({ data: proj.milestones, total_cost: proj.total_cost });
          return res.send({ data: proj.milestones, message: message });
        }
      }
    );
  } catch (err) {
    return res.send({ error: { message: "Internal Server Error" } });
  }
});

// router.post("/updatemilestones", getcheck, async (req, res) => {
//   let project_id = req.body.project_id;
//     //For Inserting the Milestones
//     await Project.findOne({ _id: project_id, delete_project: "N" }).populate("client_id").exec(async (err, proj) => {
//         if (err) {
//           return res.send({ error: err });
//         }
//         if (!proj) {
//           return res.status("401").send({ error: { message: "No such Project Found" } });
//         } else {
//           if (!req.body.mile_stones) {
//             return res.send({ error: { message: "Milestone is required" } });
//           }
//           try{
//           //Deleting full array of milestones before saving
//           proj.milestones = [];
//           await proj.save();
        
//           //Inserting new Parameters
//           req.body.mile_stones.map((ele) => {
//             proj.milestones = proj.milestones.concat({
//               milestone_name: ele.milestone_name,
//               milestone_cost: ele.milestone_cost,
//               milestone_status: ele.milestone_status,
//             });
//           });

//           // proj.total_cost = req.body.total_cost;
//           await proj.save();
//           // console.log(proj.milestones);
//           proj.milestones.forEach((array)=>{

//             console.log(array.milestone_status);

//           })
          
//           res.send({ data: proj.milestones});
//         }catch(err){
//           console.log(err);
//           res.send({message : "something went wrong"});
//         }
//         }
//       });
// });


router.post("/viewoneproject", getcheck, (req, res) => {
  const id = req.body.project_id;

  Project.findOne({ _id: id, delete_project: "N" })
    .populate("client_id")
    .populate("client_advocate_id")
    .populate("account_manager_id")

    .exec((err, doc) => {
      if (err) {
        return res.send({ error: err });
      }
      return res.send({ data: doc });
    });
});

router.post("/deleteproject", getcheck, (req, res) => {
  let searchQuery = { _id: req.body.project_id };

  Project.updateOne(searchQuery, {
    $set: {
      delete_project: "Y",
    },
  })
    .then((project) => {
      return res.send({ data: project });
    })
    .catch((err) => {
      return res.send({ error: err });
    });
});

router.get("/download/:f_name",(req, res) => {
  console.log(req.params.f_name);
  const file = `${__dirname}/../public/uploads/documents/${req.params.f_name}`;
  return res.download(file);
});
router.get("/display/:f_name", getcheck,(req, res) => {
  console.log(req.params.f_name);
  const file = `${__dirname}/../public/uploads/documents/${req.params.f_name}`;
  fs.readFile(file, function (err, data) {
    if (err) throw err;
    // Fail if the file can't be read.
    else {
      res.writeHead(200, { "Content-Type": "image/jpeg" });
      res.end(data); // Send the file data to the browser.
    }
  });
  //res.download(file);
});

router.delete("/deletefile", getcheck,async (req, res) => {
  if(!req.body.project_id || !req.body.doc_id){
    return res.status("400").json({ error: { message: "Project and Doc ID is required" } });
  }

  const project_id = req.body.project_id;
  const doc_id = req.body.doc_id;

  try{
  //Finding the document for given proj id and doc id
  const doc = await Project.findOne( {_id: project_id}, { documents : {$elemMatch : {_id : doc_id} } } );

  if(!doc){
    return res.status(202).send({ message : "No such Project" }); 
  }

  if(!doc.documents || doc.documents == ""){
    return res.status(202).send({ message : "No File Found" }); 
  }

  const filePath = doc.documents[0].doc_path;

  //Deleting the document file from Uploads
  fs.unlink(`${appRoot}/public/${filePath}`, (err) => {
    if (err) {
      console.log(err);
      return res.status("500").json( { error: "Internal Server Error" } );
    }
  });

 //Delete the document from Database
  await Project.updateOne( {_id: project_id}, { $pull: {documents : {_id : doc_id} } },
    async (err, proj) => {
   if(err){
       return res.send({ error: err });
   }
   if(!proj){
     return res.status("202").send({ error: { message: "No such Project Found" } });
   }else
   return res.status(200).send({code: "200",status: "ok",message: "Document Deleted"});

})
  }catch(err){
    console.log(err);
    return res.status("500").json( { error: "Internal Server Error" } );
  }
});

router.get("/getallcountry", getcheck, async (req, res) => {
  await Country.find({})
    .then((country) => {
      return res.send({ data: country });
    })
    .catch((err) => res.send({ data: "error" }));
});

router.get("/getalldomain", getcheck, async (req, res) => {
  await Domain.find({})
    .then((domain) => {
      res.send({ data: domain });
    })
    .catch((err) => res.send({ data: "error" }));
});

router.get("/getalldesignation", getcheck, async (req, res) => {
  await Designation.find({})
    .then((designation) => {
      return res.send({ data: designation });
    })
    .catch((err) => res.send({ data: "error" }));
});

router.get("/getalldata", getcheck, async (req, res) => {
  const designation = await Designation.find({});
  const domain = await Domain.find({});
  const country = await Country.find({});

  try {
    return res.send({ country, domain, designation });
  } catch (error) {
    return res.send({ error });
  }
});

module.exports = router;
