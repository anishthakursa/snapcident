const express= require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const {getcheck}= require('../middleware/auth');
const Password = require("../customFunctions/passwordGenerator");
const sendMailer = require("../customFunctions/sendMailer");
const Client = require('../models/Clients');

router.post('/addclient',getcheck,async (req,res)=>{

     //Create random password here
     let password = Password ();
     console.log(password);
     //Encrypt the password here
     hashedPassword = await bcrypt.hash(password, 10);

    let newClient={
        first_name:req.body.first_name,
        last_name:req.body.last_name,
        email_id:req.body.email_id,
        password : hashedPassword,
        password_status:'N',
        mobile_no:req.body.mobile_no,
        skype_id:req.body.skype_id,
        other_contact:req.body.other_contact,
        address_l1:req.body.address_l1,
        address_l2:req.body.address_l2,
        country:req.body.country,
        state:req.body.state,
        city:req.body.city,
        pincode:req.body.pincode
    }
    
    Client.create(newClient)
            .then(client=>{
             res.status(201).send({status:"success",data:client});
            
                //Send Welcome and embed password
            console.log(password);
            let to = req.body.email_id;
            let subject = 'Welcome email';
            let template = 'welcomeClient';  
            let context = {
                password : password
            }
            sendMailer(to,subject,template,context)

                
            })
            .catch(err=>{
                if (err.message.includes('clients validation failed')) {
                    let error={};
                    Object.values(err.errors).forEach((properties)=>{
                        
                         error[properties.path]=properties.message;
                    
                    });
                    res.send({error});
                    
                }
            });

    
});

//fOR TESTING REMOVED getcheck
// router.get('/viewclients',getcheck,(req,res)=>{

    router.get('/viewclients',(req,res)=>{

    Client.find({delete_client:"N"})
    .then(client=>{
        res.send({data:client});
    })
    .catch((err)=>res.send({data:'error'}));

});

router.post('/viewoneclient',getcheck,(req,res)=>{

    const id=req.body.client_id;
    
    Client.findOne({_id:id,delete_client:"N"})
    .then(client=>{
        res.send({data:client});
    })
    .catch((err)=>res.send({data:err})); 

});

router.post('/deleteclient',getcheck,(req,res)=>{
    let searchQuery = {_id:req.body.client_id};
    
    Client.updateOne(searchQuery,{$set:{
       delete_client:'Y' 
    }})
    .then(client=>{
        res.send({data:client});

    })
    .catch(err=>{
        res.send({error:err});
    })
});

router.post('/updateclient',getcheck,(req,res)=>{
    let searchQuery = {_id:req.body.client_id};
    
    Client.updateOne(searchQuery,{$set:req.body})
    .then(client=>{
        res.send({status:"ok",data:client});

    })
    .catch(err=>{
        res.send({error:err});
    })
});

module.exports=router;
