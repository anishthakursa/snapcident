const express= require('express');
const router = express.Router();
const {getcheck}= require('../middleware/auth');
const Chat = require('../models/chat')


  //API for Mobile APP, Will get chat history of two users
  router.post('/chats',getcheck, async (req,res)=>{
        // try{
        //     if(!req.body.senderId || !req.body.receiverId || !req.body.skip || ! req.body.limit){
        //         return res.status("401").json("Bad Request");
        //     }
        //           let senderId = req.body.senderId;
        //           let receiverId = req.body.receiverId;
        //           let limit = parseInt(req.body.limit);
        //           let skip = parseInt(req.body.skip);

        //           const chatsCollection = await Chat.find( { $and: [ { senderId: senderId },
        //             { receiverId : receiverId} ] }).sort({ _id: -1 }).skip(skip).limit(limit);
                    
        //             console.log(chatsCollection);

        //           const chatsCollectionCount = await Chat.countDocuments({ $and: [ { senderId: senderId },
        //             { receiverId : receiverId} ] });

        //             console.log(chatsCollectionCount);

        //           let totalPages = Math.ceil(chatsCollectionCount / limit)
        //           let currentPage = Math.ceil(chatsCollectionCount % skip)
        //           if(currentPage = "NaN"){
        //               currentPage = 1;
        //           }

        //           console.log(totalPages);
        //           console.log(currentPage);

        //           return res.status(200).send({
        //             data: chatsCollection,
        //             paging: {
        //               totalDocs: chatsCollectionCount,
        //               currentPage: currentPage,
        //               totalPages: totalPages,
        //             },
        //           })
              
        // }
        try{
          //Validating Request
          console.log("hi")
          if(!req.body.senderId || !req.body.receiverId || !req.body.limit || !req.body.page){
              return res.status("401").json( { message: "Bad Request" } );
          }
          if(req.body.page < 0 || req.body.page == 0) {
              return res.status("401").json({message : "invalid page number, should start with 1"});
          }
                let senderId = req.body.senderId;
                let receiverId = req.body.receiverId;
                let limit = parseInt(req.body.limit);
                let page = parseInt(req.body.page);

                let skip = (page - 1) * limit;

                const chatsCollection = await Chat.find( { $and : [ { senderId: {$in : [senderId, receiverId]} },
                  { receiverId : {$in : [senderId, receiverId]} } ] }).sort({ _id: -1 }).skip(skip).limit(limit);
                  
                const chatsCollectionCount = await Chat.countDocuments({ $and : [ { senderId: {$in : [senderId, receiverId]} },
                  { receiverId : {$in : [senderId, receiverId]} } ] });

                  //Incase no record is there
                  if(!chatsCollectionCount){
                      return res.json({message : "No Record Found"});
                  }
                let totalPages = Math.ceil(chatsCollectionCount / limit);
                  
                //Validating where request of pages is greater than totalpages
                if(page > totalPages){
                    return res.json({message : "Invalid page number"})
                }

                return res.status(200).json({
                  data: chatsCollection,
                  paging: {
                    totalDocs: chatsCollectionCount,
                    totalPages: totalPages
                  },
                })
                  
            }
        catch(err){
                console.log(err);
                return res.json({ error: "Internal Server Error" });
        }
});

//Deleting Chat for Mobile APP
router.delete("/chats", getcheck, async (req, res) => {
  try {
    if (!req.body.id) {
      return res.status("401").json({message: "ID is required"});
    }
    const chatId = req.body.id;
   
    Chat.deleteOne({ _id : chatId}, function (err, chat) {
      if (err){
        console.log(err);
      return res.status("500").json({ error: "Internal Server Error" });
      }
      console.log(chat);
      if(chat.deletedCount <= 0){
        return res.status("202").json({ message: "No chat message found for this id" });
      }

      return res.status("200").json({message : "Chat deleted"});
      
    });
    
  
  } catch (err) {
    console.log(err);
    return res.status("500").json({ error: "Internal Server Error" });
  }
});


module.exports=router;