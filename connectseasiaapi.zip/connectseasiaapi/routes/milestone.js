const express = require("express");
const router = express.Router();
const moment = require("moment");
const { getcheck } = require("../middleware/auth");
const Project = require("../models/Project");
const Admin = require("../models/Admin")
const Activity = require("../models/activity");
const Notification = require("../customFunctions/fcm");
const deviceToken = require("../customFunctions/deviceToken");
const projectResult = require("../customFunctions/projectResult");
const sendMailer = require("../customFunctions/sendMailer");

//For Adding Milestone
router.post("/milestones", getcheck, async (req, res) => {
  try {
    if (!req.body.project_id) {
      return res.status("400").json({ error: { message: "Project ID is required" } });
    }

    const project_id = req.body.project_id;

    await Project.findOne({ _id: project_id, delete_project: "N" }).populate("client_id")
    .populate("client_advocate_id")
    .populate("account_manager_id").exec(async (err, proj) => {
        if (err) {
          return res.send({ error: err });
        }
        if (!proj) {
          return res.status("401").send({ error: { message: "No such Project Found" } });
        } else {
          if (!req.body.mile_stones) {
            return res.send({ error: { message: "Milestone is required" } });
          }
          if(req.body.mile_stones[0].milestone_status == ""){
            req.body.mile_stones[0].milestone_status = "6";
          }
        
          //concating the array of Milestones
          req.body.mile_stones.map((ele) => {
            proj.milestones = proj.milestones.concat({
              milestone_name: ele.milestone_name,
              milestone_cost: ele.milestone_cost,
              milestone_status: ele.milestone_status,
            });
          });

          await proj.save();

           //Save the Milestone_Added Activity in Table 
            const activity = new Activity({
             activityType : 'Milestone_Added',
             createdById: req.admin._id,
              modelNameOfcreatedById: 'admins',
              activityTitle : `${proj.milestones[(proj.milestones.length) - 1].milestone_name} was Added`,
              milestoneId: proj.milestones[(proj.milestones.length) - 1]._id //Will give id of latest one added
                                        })
                 activity.save().then((activity) => {
                        console.log('Activity saved>');
                               }).catch(err => {
                               console.log('Activity Failed>>',err);
                                          })
          
          //Calling function for Registration Token Array
          let registrationToken = deviceToken(proj);
          
          //Shoot Notification for Milestone Creation
          const title = "Milestone Created";
          const body = `${req.body.mile_stones[0].milestone_name} has been created successfully`;

          Notification(registrationToken, title, body);

          res.send({ data: proj.milestones, message: "Milestone Added" });

        }
      });
  } catch (err) {
    console.log(err);
    return res.send({ error: { "message": "Internal Server Error" } });
  }
});

//For Deleting Milestone
router.delete("/milestones", getcheck, async (req, res) => {
  try {
    if (!req.body.project_id || !req.body.milestone_id) {
      return res.status("400").json({ error: { message: "Project and milestone ID is required" } });
    }
    const project_id = req.body.project_id;
    const milestone_id = req.body.milestone_id;

    //Before Deleting required name of milestone 
    let result = await projectResult(project_id, milestone_id);

    Project.updateOne( {_id: project_id}, { $pull: {milestones : {_id : milestone_id} } },
         async (err, proj) => {
        if(err){
            return res.send({ error: err });
        }
        if(!proj){
          return res.status("401").send({ error: { message: "No such Project Found" } });
        }
        
        //Save the Milestone_Delete Activity in Table 
        const activity = new Activity({
          activityType : 'Milestone_Deleted',
          createdById: req.admin._id,
          modelNameOfcreatedById: 'admins',
          activityTitle : `${result.milestones[0].milestone_name} was Deleted`,
          milestoneId: milestone_id
                  })
          activity.save().then((activity) => {
               console.log('Activity saved>');
             }).catch(err => {
               console.log('Activity Failed>>',err);
                  })

        return res.status(200).send({code: "200",status: "ok",message: "Milestone Deleted"});

    } )
  } catch (err) {
    console.log(err);
    return res.status("500").json({ error: { message: "Internal Server Error" } });
  }
});

//For Getting Status of Milestone for Project
router.get("/milestones/:id", getcheck, async (req, res) => {
  try {
    const project_id = req.params.id;

    Project.findOne({ _id: project_id, delete_project: "N" })
      .populate("client_id")
      .populate("client_advocate_id")
      .populate("account_manager_id")
      .exec((err, doc) => {
        if (err) {
          return res.send({ error: err });
        }
        if (!doc) {
          res.status(202).send({ code: "202", status: "fail", message: "No data found" });
        }
        res.status(200).send({ code: "200", status: "ok", data: doc.milestones });
      });
  } catch (err) {
    console.log(err);
    return res.status("500").json({ error: { message: "Internal Server Error" } });

  }
});

//For Updating Full Milestone
router.put("/milestones", getcheck, async (req, res) => {
  try{
      if (!req.body.project_id || !req.body.milestone_id) {
          return res.status("400").json({ error: { message: "Project and milestone ID is required" } });
        }
        if(!req.body.milestone_name || !req.body.milestone_cost || !req.body.milestone_status){
          return res.status("400").json({ error: { message: "Milestone is Required" } });
        }
        const project_id = req.body.project_id;
        const milestone_id = req.body.milestone_id
        //Get Old Status by calling projectResult Function, We will check what was the old Status for it
        let oldStatusResult = await projectResult(project_id, milestone_id);

        //Validation check for ProjectId is wrong and MilestoneId is wrong
        if(!oldStatusResult || oldStatusResult.milestones.length == "0"){
          return res.status("400").json({ error: { message: "No Record Found"} });
        }

        let oldStatus = oldStatusResult.milestones[0].milestone_status;

        //Updating Query
        const query = { _id : project_id, "milestones._id": milestone_id };
        const updateDocument = {
          $set: { 'milestones.$.milestone_name': req.body.milestone_name,
          'milestones.$.milestone_cost': req.body.milestone_cost,
                'milestones.$.milestone_status' : req.body.milestone_status  }
        };
        const result = await Project.updateOne(query, updateDocument);
       
        if(!result){
         return res.status(400).send({ message : "No Project or Milestone Found" });
        }

        //Get New Status by calling projectResult Function, We will check do we need to shoot Notification
        let newStatusResult = await projectResult(project_id, milestone_id);
        let newStatus = newStatusResult.milestones[0].milestone_status;

        //Save the Milestone_Update Activity in Table 
        const activity = new Activity({
          activityType : 'Milestone_Updated',
          createdById: req.admin._id,
          modelNameOfcreatedById: 'admins',
          activityTitle : `${ newStatusResult.milestones[0].milestone_name} was Updated`,
          milestoneId: milestone_id
      })
      activity.save().then((activity) => {
        console.log('Activity saved>');
      }).catch(err => {
        console.log('Activity Failed>>',err);
      })

      //Shoot Here Notification
      if(newStatus== "0"){
        //Calling function for Registration Token Array
      let registrationToken = deviceToken(oldStatusResult);

      //Shoot Notification for Milestone Started
      const title = "Milestone Started";
      const body = `${newStatusResult.milestones[0].milestone_name} has been started for development phase`;
    
      Notification(registrationToken, title, body);

      return res.status(200).send({ code: "200", status: "ok", message : "Milestone Updated" }); 

      }
       
        if(newStatus== "1"){
          //Calling function for Registration Token Array
        let registrationToken = deviceToken(oldStatusResult);

        //Shoot Notification for Milestone Completed
        const title = "Development Completed";
        const body = `${newStatusResult.milestones[0].milestone_name} has been completed successfully`;
      
        Notification(registrationToken, title, body);

        return res.status(200).send({ code: "200", status: "ok", message : "Milestone Updated" }); 

        }
        if(newStatus== "3"){
          //Due date will be for next 5 day for today's date
          let dueDate = new Date(new Date().getTime()+(5*24*60*60*1000));
          dueDate = moment(dueDate).format('DD MMMM YYYY');
          //Required project name
          let project = await Project.findOne({_id : project_id}, 'project_name');
          //For this status share Mail and Notification
            let to = newStatusResult.client_id.email_id; //Mail will be shared to Client only
            let subject = `invoice (xxx) for ${project.project_name} due ${dueDate}`;
            let template = 'inoviceEmail';  
            let context = {
                name : `${newStatusResult.client_id.first_name} ${newStatusResult.client_id.last_name}`,
                projectName : `${project.project_name}`,
                dueDate : `${dueDate}`
            }
             //Calling function from CustomFunctions
            sendMailer(to,subject,template,context)

            //Notification Logic
              //Calling function for Registration Token Array
          let registrationToken = deviceToken(oldStatusResult);

            //Shoot Notification for Sharing Invoice
          const title = "Invoice Shared";
          const body = `Invoice for ${newStatusResult.milestones[0].milestone_name} has been shared with client`;
          
          Notification(registrationToken, title, body);
          
          return res.status(200).send({ code: "200", status: "ok", message : "Milestone Updated" }); 
          }
          // if(newStatus== "4"){
              //Payment Followup Logic
          // }


        if(newStatus== "5"){
            //Notification Logic
             //Calling function for Registration Token Array
          let registrationToken = deviceToken(oldStatusResult);

          //Shoot Notification for Payment has been received
          const title = "Payment has been Received";
          const body = `Payment for ${newStatusResult.milestones[0].milestone_name} has been received`;
          
          Notification(registrationToken, title, body);

          return res.status(200).send({ code: "200", status: "ok", message : "Milestone Updated" }); 
          }

        return res.status(200).send({ code: "200", status: "ok", message : "Milestone Updated" }); 

  }catch(err){
    console.log(err);
      return res.status("500").json({ error: { message: "Internal Server Error" } }); 
  }

});

//For Updating Only Milestone Status for App users
router.patch("/milestones", getcheck, async (req, res) => {
  try{
    if (!req.body.project_id || !req.body.milestone_id) {
      return res.status("400").json({ error: { message: "Project and milestone ID is required" } });
    }
    if(!req.body.milestone_status){
      return res.status("400").json({ error: { message: "Milestone Status is Required" } });
    }
    
    await Project.findOne({ _id: req.body.project_id },
      { milestones: { $elemMatch: { _id: req.body.milestone_id } } }).populate("client_id")
      .populate("client_advocate_id")
      .populate("account_manager_id").exec(async (err, docs) => {
        if (err) {
          return res.send({ error: err });
        }
  
        if (!docs) {
          return res.status(202).send({ code: "202", status: "fail", message: "No data found" });
        }
        else {
        
          let milestone_id = req.body.milestone_id;
            //Save the Milestone_Update Activity For App user in Table 
              const activity = new Activity({
                      activityType : 'Milestone_Updated',
                     createdById: req.user._id,
                    //  createdById: "60ee8f181c8a8a3663ab513b",
                    modelNameOfcreatedById: 'users',
                    activityTitle : `${docs.milestones[0].milestone_name} Status was Updated`,
                   milestoneId: milestone_id
                     })
                       activity.save().then((activity) => {
                  console.log('Activity saved>');
                 }).catch(err => {
                    console.log('Activity Failed>>',err);
                        })
  
            //Shoot Notification if status is 1 which means Development Completed.
            if(req.body.milestone_status == "1"){
  
            //Calling function for Registration Token Array
            let registrationToken = deviceToken(docs);
            
            //Step 1 : Shoot Notification for Milestone Development Completed
            const title = "Development Completed";
            const body = `${docs.milestones[0].milestone_name} has been completed successfully`;
              Notification(registrationToken, title, body);
  
            //Step 2 : Shoot Mail to admin when Milestone Development Completed
           
            //Require query for only project as eleMatch will return single milestone object from array of object 
            // Also docs doesn't return full Project document
            let projectResult = await Project.findOne({ "_id" :  req.body.project_id }).select("project_name");
           
            let adminResult = await Admin.findOne({});
  
              let to = adminResult.email;
              let subject = `${projectResult.project_name} - Development Completed (${docs.milestones[0].milestone_name})`;
              let template = 'milestoneDevelopmentCompleted';
              let context = {
                clientName : docs.client_id.first_name,
                projectName : projectResult.project_name,
                milestoneName: docs.milestones[0].milestone_name,
                milestoneCost : docs.milestones[0].milestone_cost,
                accountManagerName : docs.account_manager_id.first_name
              }
    
              await sendMailer(to,subject,template,context)
  
            }
  
          (docs.milestones[0].milestone_status = req.body.milestone_status),
            docs.save((err, docus) => {
              if (err) {
                return res.send({ error: err });
              } else {
                res.status(200).send({
                  code: "200",
                  status: "ok",
                  message: "Milestone Updated",
                  new_milestone_status : docus.milestones[0].milestone_status
                });
              }
            });
        }
      });
  
  }catch(err){
    console.log(err);
    return res.send({ error: "Something Went wrong" });
  }
  
  });



module.exports = router;

