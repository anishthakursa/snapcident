const jwt =require('jsonwebtoken');
const Admin = require('../models/Admin');
const Client = require('../models/Clients');
const User = require('../models/User');

const getcheck = async (req,res,next)=>{
    
    const token = req.headers.authorization;
   // const cookie_token = req.cookies.jwt;
    // if (!cookie_token) {
    //  return   res.status(203).send({status:"failed",code:"203",message:"Login Required"})
    //  // next();
    // }else if(token !== cookie_token ){
        
    //     return   res.status(203).send({status:"failed",code:"203",message:"Authentication Failed"})
    // }
    // console.log(cookie_token);
    if (token) {
        try {
        var decode =  jwt.verify(token,'saha_token_2055');
            
        } catch (error) {
        return res.send({
            status:'failed',
            message:'error in token'
        })
            
        }
      
    // const admin = await Admin.findOne({_id:decode?._id});
    // const client = await Client.findOne({_id:decode?._id});
    // const user = await User.findOne({_id:decode?._id});
      
    const admin = await Admin.findOne({_id:decode._id});
    const client = await Client.findOne({_id:decode._id});
    const user = await User.findOne({_id:decode._id});
    
    if(!admin && !client && !user){
        
        return res.send({
            status:'failed',
            message:'not a valid user'
        })

    }else{
        // res.locals.user=user
        // res.locals.token=token
        req.admin=admin;
        req.client=client;
        req.user=user;
        req.token=token;
        // console.log(req.token);
        // console.log(req.client);
        next();
        // res.redirect('/dashboard');

    }
    
    
}else{
    return res.send({
        status:'failed',
        message:'not a valid token'
    })
}
}

module.exports = {getcheck}